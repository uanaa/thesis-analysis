# Checks performed for this prepared release

Checks were completed on 25 October 2026.

| Check | Result |
|---|---|
| Python and shell syntax | 23 Python sources parsed; 8 shell scripts passed `bash -n` |
| Packaging | 57 copied-file provenance hashes checked; no workstation home paths or recognizable credential patterns found |
| HASH matching | Rerun against the thesis HASH snapshot; summary and included reference tables agree |
| ChanPlaNS cohort | Rebuilt 59-object cohort agrees with the included reference table |
| ChanPlaNS statistics | Contingency, paired, balance and conditional outputs agree with the reference tables |
| Paired Crab calculations | Recomputed from the existing generated event/footprint caches; main, radius and rotated results agree |
| ObsID 100018 preprocessing | Reread the raw and old-screen FITS and applied the new mask; counts agree: 67,046 raw, 11,614 quality-selected, 1,026 old and 1,078 new |
| GRB aperture calculator | 220408A upper count bound 53.719195; 220714B net estimate −20.677345 |

The PN checks used NumPy 2.3.5, SciPy 1.17.1 and pandas 2.2.3. The LE01
packaging checks used NumPy 2.1.2, SciPy 1.14.1, Astropy 6.1.7 and Matplotlib
3.10.0; these LE01 routines do not require the newer Monte Carlo interface used
by the PN matching script. `requirements.txt` selects a common minimum that
also supports the PN workflow.

This release check reused the existing Crab coordinate/footprint cache, rather
than rebuilding that computationally expensive step. The newly packaged
IC1297 scripts received syntax/path checks; FXTDAS/XSPEC reduction was not
rerun for this packaging task. The retained fit transcripts identify the
calculations supporting the thesis values.
