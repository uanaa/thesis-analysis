# Planetary-nebula analyses

## ChanPlaNS statistics: included cohort

From the repository root:

```bash
python pn/analyse_chanplans_controls.py
```

The input defaults to `reference/pn/chanplans/chanplans_observed_cohort_59.csv`.
If a newly rebuilt cohort exists in `outputs/pn/chanplans/`, that file is used
instead. Results include contingency tests, matched pairs, balance measurements
and conditional paired tests. Reference outputs are provided alongside the
included cohort.

The sample contains 59 observed nebulae: 32 detections and 27 non-detections.
Point-source and diffuse outcomes overlap and are analysed separately. Lo 16's
tentative point-source flag is retained. These results describe this observed
cohort; matching does not fully balance all observing conditions.

## HASH matching

Place the thesis catalogue snapshot at `$PN_DATA_DIR/TruePNe.csv`:

```bash
export PN_DATA_DIR="/path/to/hash-inputs"
python pn/matched_morphology.py
```

The included `reference/pn/xpn_morphology_41.csv` supplies the XPN census.
The script normalises PNG identifiers and removes duplicate catalogue rows.
Outputs are written to `outputs/pn/matched/`. The principal comparisons are
41 XPNe against 82 controls and, with an additional H-alpha restriction,
31 XPNe against 31 controls. Random seeds and resampling counts remain in the
script. Reference results include the overall probabilities 0.000210 and
0.453213, respectively.

To rebuild the ChanPlaNS input table with the same HASH snapshot:

```bash
python pn/build_chanplans_cohort.py
python pn/analyse_chanplans_controls.py
```

The builder first uses the included HI4PI cache. An uncached coordinate causes
a request to the official HEASARC nH service.

## Optical-file inventory

```bash
python pn/inventory_optical_spectra.py --help
```

Supply the archive, census and output paths explicitly. This script records file
availability; spectral calibration and line-ratio suitability are assessed in
the thesis catalogue and optical-provenance appendix.
