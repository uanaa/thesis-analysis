# Thesis analysis code

Analysis scripts supporting Haoyang Yuan's doctoral thesis on X-ray-emitting
planetary nebulae and the LE01 telescope. The repository follows the thesis
revision of 24 October 2026.

| Directory | Analysis | Thesis |
|---|---|---|
| `pn/` | HASH morphology matching, ChanPlaNS controls, optical-file inventory | Chapter 4 |
| `ic1297/` | EP/FXT reduction, joint spectral fits and image diagnostics | Chapter 5 |
| `le01/` | Hot-pixel screening, paired Crab statistics, GRB count constraints | Chapters 2–3 |
| `reference/` | Selected numerical outputs and literature-based cohort tables | Comparison with reported results |
| `docs/` | Input descriptions, commands and source provenance | Reproduction guide |

## Start here

Use Python 3.11 or later in a separate environment:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python tools/check_release.py
python pn/analyse_chanplans_controls.py
```

The ChanPlaNS statistics run from the included 59-object cohort. Other workflows
need the input files described in [Data and software](docs/data_and_software.md).
Generated results go in `outputs/`, separate from the reference results.

Follow the workflow-specific instructions:

- [Planetary-nebula analysis](docs/pn.md)
- [LE01 analysis](docs/le01.md)
- [IC1297 / EP analysis](docs/ic1297.md)
- [Checks performed for this release](docs/validation.md)

The eRASS1 workflow is described in the thesis and its cited publication. The
4XMM search retains a reconstructed pair list in the thesis. A standalone
executable for either historical search is not included here.

## Code and data record

The scientific selections and statistical calculations are retained from the
thesis scripts. Packaging changes make paths configurable, resolve local
imports, and separate outputs from inputs. The small GRB aperture calculator
reproduces the equations and count tables directly.
[The source manifest](docs/source_manifest.json) records the origin, file hashes
and changes for copied files. The original local source files remain unchanged.

The repository contains no raw mission event files, calibration database, thesis
PDF, examiner correspondence, credentials or complete HASH export. Its tables
and transcripts are selected reference products, not a substitute for the full
observing data.

## Citation and version

Author: Haoyang Yuan. Release: `v0.1.0`, 25 October 2026.
Use `CITATION.cff` for the code citation and cite the scientific sources listed
in the thesis and workflow documentation. Cite a fixed release or commit when
linking this code from the thesis.

No open-source licence has been selected for this version.
