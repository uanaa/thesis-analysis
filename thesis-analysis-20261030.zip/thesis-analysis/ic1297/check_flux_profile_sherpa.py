"""Recheck the archived joint fit; no figures or thesis files are modified."""
from pathlib import Path
import json, argparse
import numpy as np
from scipy.optimize import brentq
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--workspace',type=Path,required=True,help='Workspace containing spectrum/A and spectrum/B')
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'outputs/ic1297')
args=parser.parse_args()
from sherpa.astro import ui
from sherpa.astro import xspec

out = args.output.expanduser().resolve()
out.mkdir(parents=True,exist_ok=True)
workspace=args.workspace.expanduser().resolve()
ui.clean()
xspec.set_xsabund('wilm')
xspec.set_xsxsect('vern')
for i, ab in enumerate('AB', 1):
    folder=workspace/'spectrum'/ab
    ui.load_pha(i, str(folder/f'source_{ab}_min8.pi'))
    # Explicit paths replace machine-specific PHA header links.
    ui.load_bkg(i, str(folder/'back.pha'))
    ui.load_rmf(i, str(folder/'source.rmf'))
    ui.load_arf(i, str(folder/'source.arf'))
    ui.ignore_bad(i)
    ui.ignore_id(i, None, 0.3)
    ui.ignore_id(i, 2.0, None)
ui.set_stat('wstat')
ui.set_method('neldermead')
ui.set_method_opt('maxfev', 10000)
ui.set_method_opt('ftol', 1e-9)
absorb = ui.create_model_component('xstbabs', 'absorb')
plasma = ui.create_model_component('xsapec', 'plasma')
conv = ui.create_model_component('xscflux', 'flux')
conv.Emin = .3
conv.Emax = 2.
conv.lg10Flux = -12.8
plasma.norm = 1.
plasma.norm.freeze()
plasma.kT.min = .08
plasma.kT.max = .6
plasma.kT = .086
absorb.nH.min = .01
absorb.nH.max = 10.
absorb.nH = .029
for i in (1, 2):
    ui.set_source(i, absorb * conv(plasma))
results = {'xspec_version': xspec.get_xsversion(), 'statistic': 'Sherpa WStat',
           'abundance': 'wilm', 'cross_sections': 'vern', 'fits': []}
for fixed in (False, True):
    conv.lg10Flux.thaw()
    if fixed:
        absorb.nH = .028
        absorb.nH.freeze()
    else:
        absorb.nH.thaw()
    ui.fit(1, 2)
    fit = ui.get_fit_results()
    best = {'nh_1e22': float(absorb.nH.val), 'kt_keV': float(plasma.kT.val),
            'log_flux': float(conv.lg10Flux.val)}
    base = float(fit.statval)
    def profile(logf):
        conv.lg10Flux = float(logf)
        conv.lg10Flux.freeze()
        plasma.kT = best['kt_keV']
        absorb.nH = best['nh_1e22']
        ui.fit(1, 2)
        return float(ui.get_fit_results().statval) - base - 1.
    lower = brentq(profile, best['log_flux'] - 1., best['log_flux'], xtol=1e-5)
    upper = brentq(profile, best['log_flux'], best['log_flux'] + 1., xtol=1e-5)
    conv.lg10Flux = best['log_flux']
    plasma.kT = best['kt_keV']
    absorb.nH = best['nh_1e22']
    res = dict(fixed_nh=fixed, **best, statistic=base, dof=int(fit.dof),
               numpoints=int(fit.numpoints), log_flux_bounds=[lower, upper],
               flux=float(10**best['log_flux']), flux_bounds=[10**lower, 10**upper],
               absorbed_flux=float(ui.calc_energy_flux(.3, 2., id=1)))
    results['fits'].append(res)
    (out/'ic1297_sherpa_check.json').write_text(json.dumps(results, indent=2))
    print('RESULT', json.dumps(res), flush=True)
