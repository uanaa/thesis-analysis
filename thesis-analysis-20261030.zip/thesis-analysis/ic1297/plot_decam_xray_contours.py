"""
plot_decam_xray_contours.py
────────────────────────────
DECam g-band image (reprojected to rectilinear RA/Dec grid, North-up East-left)
with X-ray R-band contours overlaid.

Outputs:
  decam_g_xray_contours.png / .pdf
"""

import os, re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.lines import Line2D
from astropy.io import fits
from astropy.wcs import WCS
from astropy.visualization import ImageNormalize, AsinhStretch
from scipy.ndimage import gaussian_filter, map_coordinates
from scipy.ndimage import gaussian_filter

# ── Config ────────────────────────────────────────────────────────────────────
FITS_G   = 'image-decam-314291-N28-g.fits'
REG_FILE = 'xray_rgb_contours_wcs.reg'

# X-ray event files (to recompute contours fresh)
FITS_R   = 'R_band_evt.fits'

RA_TARGET  = 289.3478
DEC_TARGET = -39.6129

# ── display scale: change VIEW_ARCMIN_WD to zoom in/out ──────────────────────
VIEW_ARCMIN    = 0.55    # tight nebula view (unused in this script)
VIEW_ARCMIN_WD = 4.0     # half-width of the output image (arcmin) ← adjust here

# ── DECam halo stretch (from gplot.py halo section) ──────────────────────────
# vmax set just above halo signal; clip=False keeps core dark-grey not pure black
HALO_VMIN = 505.0
HALO_VMAX = 800.0
HALO_A    = 0.3
N_REPROJ       = 600     # output grid pixels
CUTOUT_PX      = 1000     # DECam cutout half-size in pixels

NEBULA_DIAM = 10.8       # arcsec
HALO_DIAM   = 38.0       # arcsec

# X-ray contour params (must match what generated the .reg file)
IMG_SIZE          = 601
SMOOTH_SIGMA_PIX  = 0.7
N_CONTOUR_LEVELS  = 4
CTR_PERCENTILE_LO = 94
CTR_PERCENTILE_HI = 100

OUT_DIR = ''
DPI     = 300

# ── rcParams ──────────────────────────────────────────────────────────────────
plt.rcParams.update({
    'font.family':'serif','font.size':10,
    'axes.labelsize':11,'axes.titlesize':11,
    'xtick.labelsize':9,'ytick.labelsize':9,
    'xtick.direction':'in','ytick.direction':'in',
    'xtick.top':True,'ytick.right':True,
    'xtick.minor.visible':True,'ytick.minor.visible':True,
    'figure.facecolor':'white','axes.facecolor':'white',
})

cos_dec = np.cos(np.deg2rad(DEC_TARGET))

# ── 1. Reproject DECam onto rectilinear RA/Dec grid ───────────────────────────
def reproject_decam(fpath, ra, dec, half_px, n, view_am):
    with fits.open(fpath) as hdul:
        h    = hdul[1].header
        data = hdul[1].data
        wcs  = WCS(h)
    px0, py0 = wcs.all_world2pix(ra, dec, 0)
    cx, cy   = int(float(px0)), int(float(py0))
    y1 = max(0, cy-half_px); y2 = min(data.shape[0], cy+half_px)
    x1 = max(0, cx-half_px); x2 = min(data.shape[1], cx+half_px)
    cutout = data[y1:y2, x1:x2].copy().astype(float)
    cutout = np.nan_to_num(cutout, nan=np.nanmedian(cutout))

    # East-left output grid
    #dRA_arr  = np.linspace( view_am, -view_am, n)
    dRA_arr = np.linspace(-view_am, view_am, n)
    dDec_arr = np.linspace(-view_am,  view_am, n)
    dRA_2d, dDec_2d = np.meshgrid(dRA_arr, dDec_arr)
    #RA_want  = dRA_2d  / (cos_dec * 60.0) + ra
    RA_want = -dRA_2d / (cos_dec * 60.0) + ra
    Dec_want = dDec_2d / 60.0 + dec
    px_w, py_w = wcs.all_world2pix(RA_want.ravel(), Dec_want.ravel(), 0)
    px_w = px_w.reshape(n, n) - x1
    py_w = py_w.reshape(n, n) - y1
    reproj = map_coordinates(cutout, [py_w, px_w], order=1,
                             mode='constant', cval=np.nanmedian(cutout))
    return reproj, dRA_arr, dDec_arr

print("Reprojecting DECam g-band…")
reproj, dRA_arr, dDec_arr = reproject_decam(
    FITS_G, RA_TARGET, DEC_TARGET, CUTOUT_PX, N_REPROJ, VIEW_ARCMIN_WD)
extent = [dRA_arr[0], dRA_arr[-1], dDec_arr[0], dDec_arr[-1]]

# ── 2. Recompute X-ray R-band contours in RA/Dec space ────────────────────────
print("Building X-ray contours…")

def load_evt(path):
    with fits.open(path) as hdul:
        h = hdul[1].header; d = hdul[1].data
        meta = dict(crpx=h['TCRPX7'],crpy=h['TCRPX8'],
                    ra0=h['TCRVL7'],dec0=h['TCRVL8'],
                    dra=h['TCDLT7'],ddec=h['TCDLT8'])
        return d['X'].copy(), d['Y'].copy(), meta

xp, yp, m = load_evt(FITS_R)
img,_,_ = np.histogram2d(yp, xp, bins=IMG_SIZE,
    range=[[0.5,IMG_SIZE+0.5],[0.5,IMG_SIZE+0.5]])
img = img.astype(float)

src_x = m['crpx'] + (RA_TARGET  - m['ra0'])  / m['dra']
src_y = m['crpy'] + (DEC_TARGET - m['dec0']) / m['ddec']
ps_xray = abs(m['ddec']) * 3600
#ZOOM_HALF = int(np.ceil(VIEW_ARCMIN_WD * 60.0 / ps_xray)) + 5
ZOOM_HALF = int(np.ceil(420.0 / ps_xray))   # 和X射线脚本保持一致，固定±420"

x0 = max(0,int(src_x)-ZOOM_HALF); x1_ = min(IMG_SIZE,int(src_x)+ZOOM_HALF)
y0 = max(0,int(src_y)-ZOOM_HALF); y1_ = min(IMG_SIZE,int(src_y)+ZOOM_HALF)
crop_r = img[y0:y1_, x0:x1_]

r_sm = gaussian_filter(crop_r, sigma=SMOOTH_SIGMA_PIX)
nz   = r_sm[r_sm>0]
c_lo = np.percentile(nz, CTR_PERCENTILE_LO)
c_hi = np.percentile(nz, CTR_PERCENTILE_HI)
levels = np.logspace(np.log10(max(c_lo,0.01)), np.log10(c_hi), N_CONTOUR_LEVELS)
print(f"  Contour levels: {levels.round(3)}")

# Pixel → RA/Dec conversion for this crop
def pix_to_radec(col_crop, row_crop):
    px  = col_crop + x0 + 1.0
    py  = row_crop + y0 + 1.0
    ra  = m['ra0']  + (px - m['crpx']) * m['dra']
    dec = m['dec0'] + (py - m['crpy']) * m['ddec']
    return ra, dec

# RA/Dec → DECam arcmin offset (East-left)
def radec_to_am(ra, dec):
    dra_am  =  -(ra  - RA_TARGET)  * 60.0    # 去掉 cos_dec * cos_dec * 60.0   # East = positive = left side
    ddec_am =  (dec - DEC_TARGET) * 60.0
    return dra_am, ddec_am

# Extract contour paths
fig_tmp, ax_tmp = plt.subplots()
cs = ax_tmp.contour(r_sm, levels=levels)
plt.close(fig_tmp)

# Convert each segment to arcmin offsets
contour_am = []   # list of (level_idx, x_am_array, y_am_array)
for i, (lv, segs) in enumerate(zip(cs.levels, cs.allsegs)):
    for seg in segs:
        if len(seg) < 2:
            continue
        ra_s, dec_s = pix_to_radec(seg[:,0], seg[:,1])
        x_am, y_am  = radec_to_am(ra_s, dec_s)
        contour_am.append((i, x_am, y_am))

print(f"  Total contour segments: {len(contour_am)}")

# ── 3. Parse region files for overlay ─────────────────────────────────────────
SRC_REG  = dict(ra=289.3478079, dec=-39.6128933, r_as=40.0)
BACK_REG = dict(ra=289.3478,    dec=-39.6129,    r_in_as=120.0, r_out_as=240.0)
EXCL_REG = dict(ra=289.382,     dec=-39.585,     r_as=28.8)

def sky_to_am(ra, dec):
	return (-(ra - RA_TARGET) * 60.0,      # 去掉 cos_dec
             (dec-DEC_TARGET)*60.0)

# ── 4. Plot ───────────────────────────────────────────────────────────────────
# Normalise DECam image
norm = ImageNormalize(vmin=HALO_VMIN, vmax=HALO_VMAX,
                      stretch=AsinhStretch(a=HALO_A), clip=False)

# Contour colour map: 4 levels, light→dark blue
ctr_colors = ['#00BFFF','#1E90FF','#0000CD','#00008B']

fig, ax = plt.subplots(figsize=(6.5, 6.5), facecolor='white')
fig.subplots_adjust(left=0.12, right=0.97, top=0.97, bottom=0.12)

ax.imshow(reproj, cmap='gray_r', norm=norm, origin='lower',
          interpolation='nearest', extent=extent, aspect='equal')

# X-ray contours
for (i, x_am, y_am) in contour_am:
    ax.plot(x_am, y_am, color=ctr_colors[i % len(ctr_colors)],
            lw=0.9, alpha=0.9)

# Optical circles
nebula_r_am = (NEBULA_DIAM/2)/60.
halo_r_am   = (HALO_DIAM  /2)/60.
#ax.add_patch(patches.Circle((0,0), nebula_r_am,
  #  lw=1.5, edgecolor='royalblue', facecolor='none', ls='-'))
ax.add_patch(patches.Circle((0,0), halo_r_am,
    lw=1.5, edgecolor='crimson',   facecolor='none', ls='--'))

# X-ray source region
cx,cy = sky_to_am(SRC_REG['ra'], SRC_REG['dec'])
ax.add_patch(patches.Circle((cx,cy), SRC_REG['r_as']/60.,
    lw=1.0, edgecolor='green', facecolor='none', ls='-'))

# X-ray background annulus
bx,by = sky_to_am(BACK_REG['ra'], BACK_REG['dec'])
for r in [BACK_REG['r_in_as'], BACK_REG['r_out_as']]:
    ax.add_patch(patches.Circle((bx,by), r/60.,
        lw=0.8, edgecolor='green', facecolor='none', ls='--'))

# Excluded region
ex,ey = sky_to_am(EXCL_REG['ra'], EXCL_REG['dec'])
ax.add_patch(patches.Circle((ex,ey), EXCL_REG['r_as']/60.,
    fill=True, facecolor='none', edgecolor='purple',
    hatch='///', lw=1.0, ls='-'))

#ax.plot(0, 0, '+', color='royalblue', ms=8, mew=1.5, zorder=10)

# Compass
W = extent[1]-extent[0]; H = extent[3]-extent[2]
arw = dict(arrowstyle='->', color='black', lw=1.1, mutation_scale=10)
cx_c=extent[1]-W*0.08; cy_c=extent[3]-H*0.08; d=H*0.06
ax.annotate('',xy=(cx_c,cy_c+d),xytext=(cx_c,cy_c),arrowprops=arw)
ax.annotate('', xy=(cx_c-d, cy_c), xytext=(cx_c, cy_c), arrowprops=arw)  # East 指左
ax.text(cx_c-d-0.04, cy_c, 'E', color='black', fontsize=8, ha='right', va='center')
#ax.annotate('',xy=(cx_c+d,cy_c),xytext=(cx_c,cy_c),arrowprops=arw)  # +x = left = East
ax.text(cx_c,cy_c+d-0.02,'N',color='black',fontsize=8,ha='center',va='bottom')
#ax.text(cx_c+d+0.04,cy_c,'E',color='black',fontsize=8,ha='left',va='center')

# Legend
leg = [
    #Line2D([0],[0], color='gray',      lw=2,   label='DECam $g$-band'),
    Line2D([0],[0], color='#1E90FF',   lw=0.9, label='X-ray contours (R: 0.3–1.5 keV)'),
    #Line2D([0],[0], color='royalblue', lw=1.5, ls='-',  label=f'Nebula Ø={NEBULA_DIAM}″'),
    Line2D([0],[0], color='crimson',   lw=1.5, ls='--', label=f'Halo Ø={HALO_DIAM}″'),
    Line2D([0],[0], color='green',     lw=1.0, ls='-',  label='X-ray src region (40″)'),
    Line2D([0],[0], color='green',     lw=0.8, ls='--', label='Background annulus'),
    Line2D([0],[0], color='purple',    lw=1.0, ls='-',  label='Excluded region (28.8″)'),
]
ax.legend(handles=leg, fontsize=7.5, loc='upper left',
          framealpha=0.88, edgecolor='#aaaaaa',
          facecolor='white', labelcolor='black')

ax.set_xlabel(r'$\Delta$R.A. (arcmin)', fontsize=11)
ax.set_ylabel(r'$\Delta$Dec. (arcmin)', fontsize=11)
ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])

out_png = os.path.join(OUT_DIR, 'decam_g_xray_contours.png')
out_pdf = os.path.join(OUT_DIR, 'decam_g_xray_contours.pdf')
fig.savefig(out_png, dpi=DPI, bbox_inches='tight', facecolor='white')
fig.savefig(out_pdf, dpi=DPI, bbox_inches='tight', facecolor='white')
plt.close(fig)
print(f"Saved: {out_png}")
print(f"Saved: {out_pdf}")
print(f"dra={m['dra']:.8f} deg/pix")
print(f"ddec={m['ddec']:.8f} deg/pix")
print(f"ratio dra/ddec = {m['dra']/m['ddec']:.4f}  (should be ~-1 if already cos-corrected)")
