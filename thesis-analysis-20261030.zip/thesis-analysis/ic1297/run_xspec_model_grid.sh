#!/bin/bash

A_PATH="./spectrum/A"
B_PATH="./spectrum/B"

models=("apec" "2apec" "tbabs_apec" "tbabs_2apec")
stats=("chi" "cstat")
min_values=(2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20)

LO_ENERGY=0.3
HI_ENERGY=2.0

OUT_DIR="./spec_resultsNH001tbabs_apec"
mkdir -p "$OUT_DIR/logs" "$OUT_DIR/plots" "$OUT_DIR/xcm"

summary="${OUT_DIR}/fit_summary.txt"
echo "model stat min chi2 dof NH kT1 kT2 norm1 norm2 flux chi2_dof" > "$summary"

MAX_JOBS=4

wait_for_slot() {
    while [ "$(jobs -r | wc -l)" -ge "$MAX_JOBS" ]; do
        sleep 1
    done
}

get_model_expr() {
    case $1 in
        apec)         echo "apec" ;;
        2apec)        echo "apec+apec" ;;
        tbabs_apec)   echo "tbabs*apec" ;;
        tbabs_2apec)  echo "tbabs*(apec+apec)" ;;
    esac
}

get_indices() {
    case $1 in
        apec)
            echo "NH_idx='' kT1_idx=1 norm1_idx=4 kT2_idx='' norm2_idx=''"
            ;;
        2apec)
            echo "NH_idx='' kT1_idx=1 norm1_idx=4 kT2_idx=5 norm2_idx=8"
            ;;
        tbabs_apec)
            echo "NH_idx=1 kT1_idx=2 norm1_idx=5 kT2_idx='' norm2_idx=''"
            ;;
        tbabs_2apec)
            echo "NH_idx=1 kT1_idx=2 norm1_idx=5 kT2_idx=6 norm2_idx=9"
            ;;
    esac
}

# 生成模型专属参数初始化命令（直接输出到 xcm，不含 Tcl 判断）
# kT 范围依据行星状星云物理：
#   冷成分（热气泡主体）：初值 0.20 keV，范围 0.08–0.60 keV
#   热成分（激波/CSPN周围）：初值 0.50 keV，范围 0.30–1.50 keV
#   NH 下限提高至 0.01（银河系前景消光合理下限）
init_params() {
    case $1 in
        apec)
            cat <<'INNER'
# apec: single temperature, no absorption
# kT: 0.08-0.60 keV (diffuse hot bubble in PN)
newpar 1 0.20 0.01 0.08 0.08 0.60 0.60
newpar 4 1e-3 1e-6 1e-6 1e-6 1e-1 1e-1
INNER
            ;;
        2apec)
            cat <<'INNER'
# 2apec: two temperatures, no absorption
# kT1 (cool, hot bubble):  0.08-0.35 keV
# kT2 (hot, shock/CSPN):   0.30-1.50 keV
newpar 1 0.15 0.01 0.08 0.08 0.35 0.35
newpar 4 1e-3 1e-6 1e-6 1e-6 1e-1 1e-1
newpar 5 0.50 0.05 0.30 0.30 1.50 1.50
newpar 8 5e-5 1e-6 1e-6 1e-6 1e-1 1e-1
INNER
            ;;
        tbabs_apec)
            cat <<'INNER'
# tbabs_apec: NH free, single temperature
# NH: >= 0.01 (Galactic foreground floor)
# kT: 0.08-0.60 keV (diffuse hot bubble in PN)
newpar 1 0.10 0.01 0.01 0.01 10.0 10.0
newpar 2 0.20 0.01 0.08 0.08 0.60 0.60
newpar 5 1e-3 1e-6 1e-6 1e-6 1e-1 1e-1
INNER
            ;;
        tbabs_2apec)
            cat <<'INNER'
# tbabs_2apec: NH free, two temperatures
# NH: >= 0.01 (Galactic foreground floor)
# kT1 (cool, hot bubble):  0.08-0.35 keV
# kT2 (hot, shock/CSPN):   0.30-1.50 keV
newpar 1 0.10 0.01 0.01 0.01 10.0 10.0
newpar 2 0.15 0.01 0.08 0.08 0.35 0.35
newpar 5 1e-3 1e-6 1e-6 1e-6 1e-1 1e-1
newpar 6 0.50 0.05 0.30 0.30 1.50 1.50
newpar 9 5e-5 1e-6 1e-6 1e-6 1e-1 1e-1
INNER
            ;;
    esac
}

for model in "${models[@]}"; do
for stat in "${stats[@]}"; do
for min in "${min_values[@]}"; do

    wait_for_slot

    (
        echo "Running $model $stat min=$min"

        specA="${A_PATH}/source_A_min${min}.pi"
        specB="${B_PATH}/source_B_min${min}.pi"
        xcm="${OUT_DIR}/xcm/tmp_${model}_${stat}_${min}.xcm"
        log="${OUT_DIR}/logs/log_${model}_${stat}_${min}.txt"
        plot="${OUT_DIR}/plots/${model}_${stat}_${min}.ps"

        MODEL_EXPR=$(get_model_expr "$model")
        eval "$(get_indices "$model")"

        # ================= 生成 XSPEC 脚本 =================
        cat > "$xcm" <<EOF
query yes

data 1 $specA
data 2 $specB

ignore bad
ignore 1:**-$LO_ENERGY $HI_ENERGY-**
ignore 2:**-$LO_ENERGY $HI_ENERGY-**

abund wilm
xsect vern

model $MODEL_EXPR

EOF
        init_params "$model" >> "$xcm"

        cat >> "$xcm" <<EOF

statistic $stat

fit 500
fit 500

# 提取统计量和自由度
tclout stat
set chi2 [lindex \$xspec_tclout 0]
tclout dof
set dof [lindex \$xspec_tclout 0]

# 默认值
set nh -1
set kT2 -1
set norm2 -1
EOF

        # NH 提取（仅 tbabs 模型）
        if [ -n "$NH_idx" ]; then
            cat >> "$xcm" <<EOF
tclout param $NH_idx
set nh [lindex \$xspec_tclout 0]
EOF
        fi

        # kT1, norm1（所有模型）
        cat >> "$xcm" <<EOF
tclout param $kT1_idx
set kT1 [lindex \$xspec_tclout 0]
tclout param $norm1_idx
set norm1 [lindex \$xspec_tclout 0]
EOF

        # 第二成分（仅 2apec / tbabs_2apec）
        if [ -n "$kT2_idx" ]; then
            cat >> "$xcm" <<EOF
tclout param $kT2_idx
set kT2 [lindex \$xspec_tclout 0]
tclout param $norm2_idx
set norm2 [lindex \$xspec_tclout 0]
EOF
        fi

        cat >> "$xcm" <<EOF

flux $LO_ENERGY $HI_ENERGY
tclout flux 1
set flux [lindex \$xspec_tclout 0]

catch {
    setplot energy
    setplot ylog on
    setplot command "rescale y 1e-5 1e-1"
    plot data model
    hardcopy $plot cps
}

puts "$model $stat $min \$chi2 \$dof \$nh \$kT1 \$kT2 \$norm1 \$norm2 \$flux"

quit
EOF

        # ================= 运行 XSPEC =================
        xspec - <<RUN > "$log" 2>&1
@$xcm
RUN

        # ================= 提取结果 =================
        line=$(grep "^$model $stat $min" "$log" | tail -n 1)

        if [ -z "$line" ]; then
            echo "$model $stat $min FAIL FAIL FAIL FAIL FAIL FAIL FAIL FAIL FAIL" >> "$summary"
            exit 0
        fi

        chi2=$(echo "$line" | awk '{print $4}')
        dof=$(echo "$line"  | awk '{print $5}')

        if [[ "$dof" =~ ^[0-9]+$ ]] && [ "$dof" -gt 0 ]; then
            chi2dof=$(awk "BEGIN {print $chi2/$dof}")
        else
            chi2dof="NaN"
        fi

        echo "$line $chi2dof" >> "$summary"

    ) &

done
done
done

wait
echo "All jobs finished! Results in $OUT_DIR"