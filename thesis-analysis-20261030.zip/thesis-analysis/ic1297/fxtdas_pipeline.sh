#!/bin/bash

############################################
# USER SETUP (FILLED)
############################################

OBSID=11900356352

# Base paths
BASE_DIR="${IC1297_PIPELINE_ROOT:?Set IC1297_PIPELINE_ROOT to a copy of the FXT data working directory}"
DATA_DIR=${BASE_DIR}/ep_fxt_11900356352_FXTB_22_20260411_125820

EVENT_DIR=${DATA_DIR}/fxt/event
HK_DIR=${DATA_DIR}/fxt/hk
AUX_DIR=${DATA_DIR}/auxil

REG_DIR=${BASE_DIR}

# Region files
SRC_REG1=${REG_DIR}/source40.reg
SRC_REG2=${REG_DIR}/source60.reg

BKG_REG1=${REG_DIR}/back40.reg
BKG_REG2=${REG_DIR}/back60.reg
BKG_REG3=${REG_DIR}/back80.reg

# Output directory
OUTDIR=${DATA_DIR}/analysis_${OBSID}

############################################
# CREATE OUTPUT STRUCTURE
############################################

mkdir -p ${OUTDIR}
mkdir -p ${OUTDIR}/logs

mkdir -p ${OUTDIR}/src40
mkdir -p ${OUTDIR}/src60

mkdir -p ${OUTDIR}/bkg40
mkdir -p ${OUTDIR}/bkg60
mkdir -p ${OUTDIR}/bkg80

############################################
# GO TO EVENT DIRECTORY
############################################

cd ${EVENT_DIR}

############################################
# LINK FILES
############################################

#ln -s fxt_a_11900356352_ff_01_po_uf_evt_6ua.fits fxta-ori.fits
#ln -s fxt_b_11900356352_ff_01_po_uf_evt_6ta.fits fxtb-ori.fits

#cd ${HK_DIR}
#ln -s *hk* hk.fits
#ln -s *mkf* mkf.fits

#cd ${AUX_DIR}
#ln -s *orb* orb.fits
#ln -s *att* att.fits

#cd ${EVENT_DIR}

############################################
# STEP 1: CALIBRATION (FF MODE)
############################################

echo "Running calibration..."

fxtcoord evtfile=fxtb-ori.fits \
         attfile=${AUX_DIR}/att.fits \
         outfile=fxtb-coord.fits

fxtpical evtfile=fxtb-coord.fits \
         outfile=fxtb-pi.fits

fxtparticleidentify evtfile=fxtb-pi.fits \
                    outfile=fxtb-rp.fits \
                    xlength=11 ylength=11

fxtbadpix evtfile=fxtb-rp.fits \
          outfile=fxtb-badpix.fits

fxthotpix evtfile=fxtb-badpix.fits \
          outfile=fxtb-hotpix.fits

fxtgrade evtfile=fxtb-hotpix.fits \
         outfile=fxtb-grade.fits

fxtgtigen mkffile=${HK_DIR}/mkf.fits \
          module=fxtb \
          outfile=fxtb.gti \
          expr=DEFAULT

############################################
# STEP 2: CLEAN EVENTS
############################################

ftselect "fxtb-grade.fits[events]" fxtb-clean.fits \
"grade >= 0 && grade <=12 && status==b0 && gtifilter('fxtb.gti')" \
copyall=yes clobber=yes

############################################
# STEP 3: EXPOSURE MAP
############################################

fxtexpogen mkffile=${HK_DIR}/mkf.fits \
           evtfile=fxtb-clean.fits \
           outfile=fxtb-expo.fits

############################################
# FUNCTION: XSELECT
############################################

run_xselect () {

REG=$1
OUT=$2

rm -f ${OUT}.pha ${OUT}.lc   # avoid overwrite prompt

xselect << EOF
xsel
no
read event fxtb-clean.fits
./
yes
filter region ${REG}
extract spectrum
save spectrum ${OUT}.pha
yes
clear region
filter region ${REG}
filter pha_cutoff 274 925
extract curve
save curve ${OUT}.lc
yes
exit
no
EOF

}



############################################
# RUN SOURCES
############################################

echo "Processing sources..."

run_xselect ${SRC_REG1} ${OUTDIR}/src40/source40
run_xselect "${SRC_REG2}" ${OUTDIR}/src60/source60

############################################
# RUN BACKGROUNDS
############################################

echo "Processing backgrounds..."

run_xselect ${BKG_REG1} ${OUTDIR}/bkg40/back40
run_xselect ${BKG_REG2} ${OUTDIR}/bkg60/back60
run_xselect ${BKG_REG3} ${OUTDIR}/bkg80/back80

############################################
# RESPONSE FILE (EXAMPLE FOR ONE SOURCE)
############################################

echo "Generating response for source40..."

fxtarfgen specfile=${OUTDIR}/src40/source40.pha \
          expfile=fxtb-expo-without_vign.fits \
          psfcor=0 \
          outfile=${OUTDIR}/src40/source40.arf

fxtrmfgen specfile=${OUTDIR}/src40/source40.pha \
          outfile=${OUTDIR}/src40/source40.rmf

############################################
# DONE
############################################

echo "All done!"
