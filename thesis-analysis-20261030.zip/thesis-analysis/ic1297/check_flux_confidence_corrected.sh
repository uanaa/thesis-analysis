OUT_DIR="."
QDP="/tmp/ic1297_corrected_spec8.qdp"
STEPPAR_QDP="/tmp/ic1297_corrected_steppar_flux.qdp"
OUTPDF="${OUT_DIR}/ic1297_corrected_cflux_spectrum.pdf"
OUTEPS="${OUT_DIR}/ic1297_corrected_cflux_spectrum.eps"
log="${OUT_DIR}/logs/replot_tbabs_apec_cstat_8.txt"

mkdir -p "${OUT_DIR}/logs"
rm -f "$QDP" "$STEPPAR_QDP"        # ← 加这个，两个输出文件运行前都清掉


# ---- 写 xcm 文件 ----
cat > /tmp/ic1297_corrected_replot8.xcm << 'EOF'
query yes
data 1 ./spectrum/A/source_A_min8.pi
data 2 ./spectrum/B/source_B_min8.pi
ignore bad
ignore 1:**-0.3 2.0-**
ignore 2:**-0.3 2.0-**
abund wilm
xsect vern
statistic cstat

# ---- 用 cflux 卷积模型包住 apec，能直接对 flux 本身做 error 命令 ----
# 模型顺序变为: tbabs * cflux * apec
model tbabs*cflux*apec
/*
newpar 1 0.02903 0.001 0.01 0.01 10.0 10.0

# cflux 参数: Emin Emax lg10Flux (0.3-2.0 keV, 与 ignore 范围一致)
newpar 2 0.3 -1
newpar 3 2.0 -1
newpar 4 -12.0 0.01 -20.0 -20.0 -8.0 -8.0

newpar 5 0.08560 0.001 0.08 0.08 0.60 0.60
# Freeze the additive apec normalisation; cflux supplies the scale.
newpar 8 1.0 -1

fit 500

# ---------- 验证 cflux ----------
flux 0.3 2.0

tclout flux 1
set modelFlux [lindex $xspec_tclout 0]

tclout param 4
set lgFlux [lindex $xspec_tclout 0]

puts "MODEL_FLUX=$modelFlux"
puts "LOG10FLUX=$lgFlux"



tclout stat
set s [lindex $xspec_tclout 0]
tclout dof
set d [lindex $xspec_tclout 0]
puts "CSTAT=$s DOF=$d"

tclout param 1
puts "NH=[lindex $xspec_tclout 0]"
tclout param 5
puts "KT=[lindex $xspec_tclout 0]"

# ---- 关键：对 cflux 的第4个参数(lg10Flux)做 error 命令 ----
# 1.0 = delta-cstat=1.0 (68%/1-sigma) 非线性搜索置信区间
# 若想要 90% 置信区间，改成 error 2.706 4
error 1.0 4
tclout param 4
puts "LOG10FLUX=[lindex $xspec_tclout 0]"
tclout error 4
puts "LOG10FLUX_ERR=[lindex $xspec_tclout 0] [lindex $xspec_tclout 1]"

# ---- steppar 核实 error 命令给出的置信区间是否可靠 ----
# 注意：不冻结 nH/kT，让 steppar 在每一步都重新拟合其余自由参数
# （跟 error 命令默认行为一致，这样两者的置信区间才可比）
# 在 best-fit lg10Flux 附近扫描 40 步，检查 C-stat 曲线
# 是否在 delta-C=1 处只有一个干净的交点（而不是 error 命令警告的那种局部抖动/非单调性）
tclout param 4
set lgf [lindex $xspec_tclout 0]

set lo [expr {$lgf-0.5}]
set hi [expr {$lgf+0.5}]

steppar 4 $lo $hi 60

iplot contour
wdata /tmp/ic1297_corrected_steppar_flux.qdp
quit

setplot energy
iplot ldata delchi
wdata /tmp/ic1297_corrected_spec8.qdp
quit
EOF

echo "Step 1: XSPEC 拟合 + flux 误差计算中..."
xspec - < /tmp/ic1297_corrected_replot8.xcm > "$log" 2>&1

echo "--- log tail ---"
tail -40 "$log"
echo "----------------"
grep -E "^CSTAT=|^NH=|^KT=|^LOG10FLUX" "$log" | tail -5

if [ ! -f "$QDP" ]; then
    echo "✗ QDP 未生成，查看完整日志："
    cat "$log"
    exit 1
fi
echo "✓ QDP 生成 ($(wc -l < $QDP | tr -d ' ') 行)"

# ============================================================
# Step 1b: 把 log10(Flux) 及其误差换算成线性 flux（含不对称误差）
# ============================================================
python3 << 'PYEOF'
import re

log = "logs/replot_tbabs_apec_cstat_8.txt"
try:
    with open(log) as f:
        text = f.read()
except FileNotFoundError:
    print("找不到 log 文件，跳过 flux 换算")
    raise SystemExit

# LOG10FLUX=-12.xxxx
m_val = re.search(r"LOG10FLUX=(-?\d+\.?\d*)", text)
# tclout error 4 输出格式一般是: "lo hi errFlag"，例如 "-12.5 -11.9 FFFFFFFFF"
m_err = re.search(r"LOG10FLUX_ERR=(-?\d+\.?\d*)\s+(-?\d+\.?\d*)", text)

if m_val and m_err:
    logf = float(m_val.group(1))
    lo = float(m_err.group(1))
    hi = float(m_err.group(2))

    F = 10**logf
    F_lo = 10**lo
    F_hi = 10**hi
    err_plus = F_hi - F
    err_minus = F - F_lo

    print(f"log10(Flux) = {logf:.4f}  [{lo:.4f}, {hi:.4f}]  (68% CI, non-linear)")
    print(f"F_X = {F:.3e}  +{err_plus:.3e} / -{err_minus:.3e}  erg cm^-2 s^-1")
    print(f"相对误差: +{100*err_plus/F:.1f}% / -{100*err_minus/F:.1f}%")
else:
    print("未能从 log 中解析出 LOG10FLUX / LOG10FLUX_ERR，请检查 error 命令是否成功收敛")
    print("（若 error 命令报 'parameter confidence interval failed', 需要放宽 fit 范围或增大 error 搜索步数）")
PYEOF

# ============================================================
# Step 1c: 画出 steppar 的 delta-Cstat vs log10(Flux) 曲线
# 用来肉眼核实 error 命令给出的置信区间是否只有一个干净的交点
# （而不是 XSPEC 警告的那种局部抖动/非单调性）
# ============================================================
python3 << 'PYEOF'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

qdp_file = "/tmp/ic1297_corrected_steppar_flux.qdp"
out_pdf = "./ic1297_corrected_steppar_check.pdf"

try:
    rows = []
    with open(qdp_file) as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith('!') or s.startswith('@') or s.upper().startswith(('READ', 'NO')):
                continue
            nums = []
            for tok in s.split():
                try:
                    nums.append(float(tok))
                except ValueError:
                    pass
            if len(nums) >= 2:
                rows.append(nums)
    if not rows:
        raise FileNotFoundError

    arr = np.array(rows)
    # steppar "plot chisq" 输出通常是: par_value, delta_stat (有时还有误差列)
    x = arr[:, 0]
    y = arr[:, 1]

    best_idx = np.argmin(y)
    best_x = x[best_idx]
    y_shift = y - y.min()   # 相对最小值的 delta-Cstat

    fig, ax = plt.subplots(figsize=(4.5, 3.5))
    ax.plot(x, y_shift, 'o-', ms=3, color='black')
    ax.axhline(1.0, color='red', ls='--', lw=1, label=r'$\Delta C = 1$ (68%)')
    ax.axvline(best_x, color='blue', ls=':', lw=1, label=f'best-fit = {best_x:.4f}')
    ax.set_xlabel(r'$\log_{10} F_X$')
    ax.set_ylabel(r'$\Delta C$-statistic')
    ax.set_title('IC 1297: steppar check for flux confidence interval')
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_pdf, dpi=200)
    print(f"steppar 曲线已保存: {out_pdf}")
    print("请肉眼检查：曲线是否是单一、光滑的碗形，且只在两侧各与 delta-C=1 交一次。")
    print("如果出现多个局部凹陷/非单调抖动，说明 error 命令给出的区间不可靠，需要人工从图上读取交点。")
except FileNotFoundError:
    print(f"未找到 {qdp_file}，可能 steppar 没有成功输出 plot chisq 数据，请检查 log。")
PYEOF

# ============================================================
# Step 2: Python 画图（与原脚本一致，未改动）
# ============================================================
echo "Step 2: Python 画图..."

python3 << 'PYEOF'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

qdp_file = "/tmp/ic1297_corrected_spec8.qdp"
out_pdf  = "./ic1297_corrected_cflux_spectrum.pdf"
out_eps  = "./ic1297_corrected_cflux_spectrum.eps"

blocks = []
current = []
with open(qdp_file) as f:
    for line in f:
        s = line.strip()
        if not s or s.startswith('!') or s.startswith('@') or s.upper().startswith('READ'):
            continue
        if s.upper().startswith('NO'):
            if current:
                blocks.append(current)
                current = []
        else:
            nums = []
            for tok in s.split():
                try:
                    nums.append(float(tok))
                except ValueError:
                    pass
            if len(nums) >= 3:
                current.append(nums)
if current:
    blocks.append(current)

print(f"QDP blocks: {len(blocks)}")
for i, b in enumerate(blocks):
    print(f"  block {i}: {len(b)} rows x {len(b[0])} cols")

def arr(b): return np.array(b, dtype=float)
b0 = arr(blocks[0])
b1 = arr(blocks[1])
b2 = arr(blocks[2])
b3 = arr(blocks[3])

eA,  deA,  rA,  reA,  mA  = b0[:,0], b0[:,1], b0[:,2], b0[:,3], b0[:,4]
eB,  deB,  rB,  reB,  mB  = b1[:,0], b1[:,1], b1[:,2], b1[:,3], b1[:,4]
eAr, deAr, chiA            = b2[:,0], b2[:,1], b2[:,2]
eBr, deBr, chiB            = b3[:,0], b3[:,1], b3[:,2]

fig, (ax1, ax2) = plt.subplots(
    2, 1, figsize=(3.5, 4.2), sharex=True,
    gridspec_kw={'height_ratios': [3, 1], 'hspace': 0.0}
)

ax1.errorbar(eA, rA, xerr=deA, yerr=reA, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='black', label='EP/FXT-A', zorder=3)
ax1.errorbar(eB, rB, xerr=deB, yerr=reB, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='red', label='EP/FXT-B', zorder=3)
ax1.step(np.append(eA-deA, eA[-1]+deA[-1]), np.append(mA, mA[-1]),
         where='post', color='black', lw=1.0, zorder=2)
ax1.step(np.append(eB-deB, eB[-1]+deB[-1]), np.append(mB, mB[-1]),
         where='post', color='red', lw=1.0, zorder=2)

ax1.set_yscale('log')
ax1.set_xscale('log')
ax1.set_ylim(1e-5, 1)
ax1.set_xlim(0.28, 2.1)
ax1.set_ylabel(r'Counts s$^{-1}$ keV$^{-1}$', fontsize=8)
ax1.legend(fontsize=7, frameon=False, loc='upper right',
           handlelength=1.2, handletextpad=0.4)
ax1.tick_params(axis='both', which='both', direction='in',
                top=True, right=True, labelsize=7.5)
ax1.tick_params(labelbottom=False)

ax2.errorbar(eAr, chiA, xerr=deAr, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='black', zorder=3)
ax2.errorbar(eBr, chiB, xerr=deBr, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='red', zorder=3)
ax2.axhline(0, color='black', lw=0.8, ls='--', zorder=2)
ax2.set_ylim(-5, 5)
ax2.set_yticks([-4, -2, 0, 2, 4])
ax2.set_ylabel(r'$(d-m)/\sigma$', fontsize=8)
ax2.set_xlabel('Energy (keV)', fontsize=8)
ax2.tick_params(axis='both', which='both', direction='in',
                top=True, right=True, labelsize=7.5)

ax2.set_xticks([0.3, 0.5, 1.0, 2.0])
ax2.xaxis.set_major_formatter(mticker.FixedFormatter(['0.3', '0.5', '1', '2']))
ax2.xaxis.set_minor_locator(mticker.NullLocator())

for ax in [ax1, ax2]:
    for spine in ax.spines.values():
        spine.set_linewidth(0.8)

fig.savefig(out_pdf, bbox_inches='tight', dpi=300)
fig.savefig(out_eps, bbox_inches='tight')
print(f"Saved: {out_pdf}")
PYEOF

[ $? -eq 0 ] && echo "✓ 完成！PDF: $OUTPDF" || echo "✗ Python 失败"