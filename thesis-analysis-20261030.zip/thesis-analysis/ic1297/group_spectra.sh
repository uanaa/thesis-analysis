#!/bin/bash

# 定义两个模块的路径
A_PATH="./spectrum/A"
B_PATH="./spectrum/B"

# 定义分组阈值（最小计数）
min_values=(11 12 13 14 15 16 17 18 19 20)

# 处理 A 模块
cd "$A_PATH"
for min in "${min_values[@]}"; do
    outfile="source_A_min${min}.pi"
    echo "Processing A: group min $min -> $outfile"
    grppha infile=source.pha outfile="$outfile" \
        comm="group min ${min} & chkey RESPFILE source.rmf & chkey ANCRFILE source.arf & chkey BACKFILE back.pha & exit" \
        clobber=yes
done

# 处理 B 模块
cd "$B_PATH"
for min in "${min_values[@]}"; do
    outfile="source_B_min${min}.pi"
    echo "Processing B: group min $min -> $outfile"
    grppha infile=source.pha outfile="$outfile" \
        comm="group min ${min} & chkey RESPFILE source.rmf & chkey ANCRFILE source.arf & chkey BACKFILE back.pha & exit" \
        clobber=yes
done

echo "All done. Generated 10 files for each module."
