"""
plot_xray_rgb_v2.py
────────────────────
X-ray RGB composite, publication-ready:
  • White background, correct RGB colours (CMY method)
  • No title, no Source/HPD/Halo circles
  • Contours from R-band only
  • source.reg  → solid black circle (r = 40")
  • back.reg    → black dashed annulus (120"–240") + red dotted exclusion (r = 28.8")
  • .ctr file saved (DS9-compatible, R-band contours)
"""

import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Circle
from astropy.io import fits
from scipy.ndimage import gaussian_filter
import warnings
warnings.filterwarnings('ignore')

# ── Configuration ─────────────────────────────────────────────────────────────
FITS_PATHS = {
    'R': 'R_band_evt.fits',
    'G': 'G_band_evt.fits',
    'B': 'B_band_evt.fits',
}
BAND_LABELS = {'R':'0.3–1.5 keV', 'G':'1.5–4.5 keV', 'B':'4.5–9.0 keV'}

SRC_RA,  SRC_DEC  = 289.3478, -39.6129
IMG_SIZE           = 601
ZOOM_AS            = 420.0
SMOOTH_SIGMA_PIX   = 0.7#2.0
N_CONTOUR_LEVELS   = 4#6
CTR_PERCENTILE_LO  = 94
CTR_PERCENTILE_HI  = 100

OUT_DIR = '.'
OUT_PNG = os.path.join(OUT_DIR, 'xray_rgb_composite.png')
OUT_PDF = os.path.join(OUT_DIR, 'xray_rgb_composite.pdf')
OUT_CTR = os.path.join(OUT_DIR, 'xray_rgb_contours.ctr')
DPI     = 300

# ── Region definitions (parsed from .reg files) ───────────────────────────────
# source.reg : circle(289.3478079,-39.6128933,40.000")
SRC_REG  = dict(ra=289.3478079, dec=-39.6128933, r_as=40.0)
# back.reg   : annulus(289.3478,-39.6129,120",240")
BACK_REG = dict(ra=289.3478,    dec=-39.6129,    r_in_as=120.0, r_out_as=240.0)
# back.reg   : -circle(289.382,-39.585,28.8")   [excluded]
EXCL_REG = dict(ra=289.382,     dec=-39.585,     r_as=28.8)

# ── rcParams ──────────────────────────────────────────────────────────────────
plt.rcParams.update({
    'font.family':'serif', 'font.size':10,
    'axes.labelsize':11,   'axes.titlesize':11,
    'xtick.labelsize':9,   'ytick.labelsize':9,
    'xtick.direction':'in','ytick.direction':'in',
    'xtick.top':True,      'ytick.right':True,
    'xtick.minor.visible':True, 'ytick.minor.visible':True,
    'figure.facecolor':'white', 'axes.facecolor':'white',
})

# ── I/O helpers ───────────────────────────────────────────────────────────────
def load(path):
    with fits.open(path) as hdul:
        h = hdul[1].header; d = hdul[1].data
        meta = dict(crpx=h['TCRPX7'], crpy=h['TCRPX8'],
                    ra0=h['TCRVL7'],   dec0=h['TCRVL8'],
                    dra=h['TCDLT7'],   ddec=h['TCDLT8'])
        return d['X'].copy(), d['Y'].copy(), meta

def make_img(x, y, size=IMG_SIZE):
    img,_,_ = np.histogram2d(y, x, bins=size,
        range=[[0.5,size+0.5],[0.5,size+0.5]])
    return img.astype(float)

def crop(arr, cx, cy, half, size=IMG_SIZE):
    x0=max(0,int(cx)-half); x1=min(size,int(cx)+half)
    y0=max(0,int(cy)-half); y1=min(size,int(cy)+half)
    return arr[y0:y1, x0:x1]

def norm_channel(img, gamma=0.45, plo=1, phi=99.5):
    v = img[img>0]
    if len(v)==0: return np.zeros_like(img)
    vmin = max(np.percentile(v,plo), 0.01)
    vmax = np.percentile(v,phi)
    return np.clip((img-vmin)/(vmax-vmin), 0, 1)**gamma

# ── Load & histogram ──────────────────────────────────────────────────────────
data = {}
for band, path in FITS_PATHS.items():
    xp, yp, meta = load(path)
    data[band] = dict(x=xp, y=yp, meta=meta, img=make_img(xp,yp))

m     = data['R']['meta']
src_x = m['crpx'] + (SRC_RA  - m['ra0'])  / m['dra']
src_y = m['crpy'] + (SRC_DEC - m['dec0']) / m['ddec']
ps    = abs(m['ddec']) * 3600           # arcsec/pix
ZOOM_HALF = int(np.ceil(ZOOM_AS / ps))
cos_dec   = np.cos(np.deg2rad(SRC_DEC))
print(f"Source pixel: ({src_x:.2f}, {src_y:.2f})  ps={ps:.4f}\"/pix")

# Extent in arcmin (source = origin)
dx0 = -(src_x-(int(src_x)-ZOOM_HALF))*ps;  dx1 = (int(src_x)+ZOOM_HALF-src_x)*ps
dy0 = -(src_y-(int(src_y)-ZOOM_HALF))*ps;  dy1 = (int(src_y)+ZOOM_HALF-src_y)*ps
ext = [dx0/60., dx1/60., dy0/60., dy1/60.]
W, H = ext[1]-ext[0], ext[3]-ext[2]

# ── Build RGB with white background (CMY method) ──────────────────────────────
# Each normalised channel acts as "ink" subtracted from white.
# R signal removes Green+Blue  →  red on white
# G signal removes Red+Blue    →  green on white
# B signal removes Red+Green   →  blue on white
crops = {b: crop(data[b]['img'], src_x, src_y, ZOOM_HALF) for b in ['R','G','B']}
ch    = {b: norm_channel(crops[b]) for b in ['R','G','B']}

out_R = np.clip(1.0 - ch['G'] - ch['B'], 0, 1)
out_G = np.clip(1.0 - ch['R'] - ch['B'], 0, 1)
out_B = np.clip(1.0 - ch['R'] - ch['G'], 0, 1)
rgb_white = np.stack([out_R, out_G, out_B], axis=-1)

# ── Contours from R-band only ─────────────────────────────────────────────────
r_sm   = gaussian_filter(crops['R'], sigma=SMOOTH_SIGMA_PIX)
nz     = r_sm[r_sm>0]
c_lo   = np.percentile(nz, CTR_PERCENTILE_LO)
c_hi   = np.percentile(nz, CTR_PERCENTILE_HI)
levels = np.logspace(np.log10(max(c_lo,0.01)), np.log10(c_hi), N_CONTOUR_LEVELS)
print(f"R-band contour levels: {levels.round(3)}")

# ── Save .ctr (DS9 format) ────────────────────────────────────────────────────
fig_tmp, ax_tmp = plt.subplots()
cs_tmp = ax_tmp.contour(r_sm, levels=levels)
plt.close(fig_tmp)

x0_off = int(src_x)-ZOOM_HALF;  y0_off = int(src_y)-ZOOM_HALF
with open(OUT_CTR,'w') as f:
    f.write("# DS9 contour file (R-band only)\n")
    f.write(f"# Source RA={SRC_RA}  Dec={SRC_DEC}\n")
    f.write(f"# Smooth sigma={SMOOTH_SIGMA_PIX} pix\n")
    f.write(f"# Levels: {' '.join(f'{lv:.6f}' for lv in levels)}\n")
    f.write("# X Y  (1-based FITS pixel coords)\n#\n")
    for i,(lv,segs) in enumerate(zip(cs_tmp.levels, cs_tmp.allsegs)):
        for j,seg in enumerate(segs):
            img_x = seg[:,0]+x0_off+1.0
            img_y = seg[:,1]+y0_off+1.0
            f.write(f"# level={lv:.6f}  segment={j+1}/{len(segs)}\n")
            f.write(f"{len(img_x)}\n")
            for xi,yi in zip(img_x,img_y):
                f.write(f"{xi:.3f} {yi:.3f}\n")
print(f"Saved: {OUT_CTR}")

# ── Sky offset → arcmin helper ────────────────────────────────────────────────
def sky_to_arcmin(ra, dec):
    # East on LEFT: pixel x increases → RA decreases (dra<0), so negate ΔRA
    dra_am  = -(ra  - SRC_RA)  * cos_dec * 60.0
    ddec_am =  (dec - SRC_DEC) * 60.0
    return dra_am, ddec_am

# ── Region overlays ───────────────────────────────────────────────────────────
def add_regions(ax):
    # Source region: solid black circle
    cx,cy = sky_to_arcmin(SRC_REG['ra'], SRC_REG['dec'])
    ax.add_patch(Circle((cx,cy), SRC_REG['r_as']/60.,
        fill=False, edgecolor='black', lw=1.0, ls='-', zorder=5))
    #ax.plot(cx, cy, '+', color='black', ms=7, mew=1.5, zorder=6)

    # Background annulus: black dashed (inner + outer edge)
    bx,by = sky_to_arcmin(BACK_REG['ra'], BACK_REG['dec'])
    for r_as in [BACK_REG['r_in_as'], BACK_REG['r_out_as']]:
        ax.add_patch(Circle((bx,by), r_as/60.,
            fill=False, edgecolor='black', lw=1.1, ls='--', zorder=5))

    # Excluded circle: 
   # ex,ey = sky_to_arcmin(EXCL_REG['ra'], EXCL_REG['dec'])
    #ax.add_patch(Circle((ex,ey), EXCL_REG['r_as']/60.,
      #  fill=False, edgecolor='purple', lw=1.1, ls='-', zorder=10))
    # Excluded circle: edge + diagonal hatch in purple
    ex, ey = sky_to_arcmin(EXCL_REG['ra'], EXCL_REG['dec'])
    ax.add_patch(Circle((ex, ey), EXCL_REG['r_as']/60.,
        fill=True, facecolor='none', edgecolor='purple',
        hatch='///', lw=1.1, ls='-', zorder=10))

def add_compass(ax):
    arw = dict(arrowstyle='->', color='black', lw=1.1, mutation_scale=10)
    cx_c=ext[1]-W*0.10; cy_c=ext[3]-H*0.10; d=H*0.07
    ax.annotate('',xy=(cx_c,cy_c+d),xytext=(cx_c,cy_c),arrowprops=arw)
    ax.annotate('',xy=(cx_c-d,cy_c),xytext=(cx_c,cy_c),arrowprops=arw)
    ax.text(cx_c+0.08,cy_c+d+0.03,'N',color='black',fontsize=8,va='bottom')
    ax.text(cx_c-d-0.08,cy_c+0.03,'E',color='black',fontsize=8,ha='right')

def add_scalebar(ax):
    sb_len=2.0; x0s=ext[0]+W*0.05; y0s=ext[2]+H*0.05
    ax.plot([x0s,x0s+sb_len],[y0s,y0s],'-',color='black',lw=2.2,solid_capstyle='butt')
    ax.text(x0s+sb_len/2, y0s+H*0.03, r"$2'$",
            color='black', ha='center', fontsize=9)

# ── Figure ────────────────────────────────────────────────────────────────────
COL2 = 7.28
fig, ax = plt.subplots(figsize=(COL2*0.85, COL2*0.75), facecolor='white')
fig.subplots_adjust(left=0.12, right=0.97, top=0.97, bottom=0.12)

ax.imshow(rgb_white, origin='lower', extent=ext,
          interpolation='nearest', aspect='equal')

# Contours in dark grey (visible on white background)
ax.contour(r_sm, levels=levels, extent=ext, origin='lower',
           colors='cyan', linewidths=1.2, alpha=0.9)

add_regions(ax)
#add_scalebar(ax)
add_compass(ax)

ax.set_xlabel(r'$\Delta$R.A. (arcmin)', fontsize=11)
ax.set_ylabel(r'$\Delta$Dec. (arcmin)', fontsize=11)
ax.set_xlim(ext[0], ext[1])
ax.set_ylim(ext[2], ext[3])

leg_handles = [
    Line2D([0],[0], color='red',     lw=2.5, label=f'R: {BAND_LABELS["R"]}'),
    Line2D([0],[0], color='lime',    lw=2.5, label=f'G: {BAND_LABELS["G"]}'),
    Line2D([0],[0], color='#4466ff', lw=2.5, label=f'B: {BAND_LABELS["B"]}'),
    Line2D([0],[0], color='cyan', lw=0.7, label='Contours (R-band)'),
    Line2D([0],[0], color='black',   lw=1.0, ls='-',  label='Source region(40")'),
    #Line2D([0], [0], color='black', marker='+', markersize=5, lw=0, label='Source center'),
    Line2D([0],[0], color='black', lw=1.1, ls='--', label='Background annulus (120″–240″)'),
    Line2D([0],[0], color='purple',     lw=1.1, ls='-',  label='Excluded region (28.8″)'),
]
ax.legend(handles=leg_handles, fontsize=8, loc='upper left',
          framealpha=0.85, edgecolor='#aaaaaa',
          facecolor='white', labelcolor='black')

fig.savefig(OUT_PNG, dpi=DPI, bbox_inches='tight', facecolor='white')
fig.savefig(OUT_PDF, dpi=DPI, bbox_inches='tight', facecolor='white')
plt.close(fig)
print(f"Saved: {OUT_PNG}")
print(f"Saved: {OUT_PDF}")
print("Done.")