"""
IC 1297 X-ray Symmetry Analysis — ApJL Submission Style
========================================================
Two-panel figure (PDF + PNG):
  (a) Octant polar diagram  — E left, N up, W right (astronomical E/W flip)
  (b) Background-subtracted radial surface-brightness profile

Also writes: asymmetry_table.tex (LaTeX table of symmetry statistics)

Input files:
  merged_events_ds9.fits  – merged EP/FXT event list

Dependencies:
  pip install astropy matplotlib numpy scipy
"""

from astropy.io import fits
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from scipy.stats import chisquare

# ── Parameters ───────────────────────────────────────────────────────
SRC_RA    = 289.3478; SRC_DEC = -39.6129
R_OPTICAL = 5.4; R_HALO = 19.0; R_HPD = 12.0
EVENTS_FILE = "merged_events_ds9.fits"
OUT_PDF = "xray_symmetry_apjl.pdf"
OUT_PNG = "xray_symmetry_apjl.png"
OUT_TEX = "asymmetry_table.tex"

# ── ApJL style ────────────────────────────────────────────────────────
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
    "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 9,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.top": True, "ytick.right": True,
    "xtick.minor.visible": True, "ytick.minor.visible": True,
    "xtick.major.width": 0.8, "ytick.major.width": 0.8,
    "xtick.minor.width": 0.5, "ytick.minor.width": 0.5,
    "axes.linewidth": 0.8, "lines.linewidth": 1.0, "patch.linewidth": 0.8,
    "legend.fontsize": 7.5, "legend.framealpha": 0.85, "legend.edgecolor": "0.7",
    "axes.facecolor": "white", "figure.facecolor": "white",
    "axes.edgecolor": "black", "axes.labelcolor": "black",
    "xtick.color": "black", "ytick.color": "black", "text.color": "black",
    "figure.dpi": 300, "savefig.dpi": 300,
})

# ── Load events ───────────────────────────────────────────────────────
print("Loading X-ray events …")
with fits.open(EVENTS_FILE) as hdul:
    evdata = hdul[1].data; hdr1 = hdul[1].header
x_ev = evdata["X"]; y_ev = evdata["Y"]
print(f"  Total events: {len(x_ev):,}")

CRPX7=hdr1["TCRPX7"]; CRVL7=hdr1["TCRVL7"]; CDLT7=hdr1["TCDLT7"]
CRPX8=hdr1["TCRPX8"]; CRVL8=hdr1["TCRVL8"]; CDLT8=hdr1["TCDLT8"]
PIXEL_SCALE = abs(CDLT7) * 3600
SRC_X = CRPX7 + (SRC_RA  - CRVL7) / CDLT7
SRC_Y = CRPX8 + (SRC_DEC - CRVL8) / CDLT8

dx  = (x_ev - SRC_X) * PIXEL_SCALE   # +dx = East
dy  = (y_ev - SRC_Y) * PIXEL_SCALE   # +dy = North
r   = np.sqrt(dx**2 + dy**2)
phi = np.degrees(np.arctan2(dy, dx))  # 0°=E, 90°=N

# ── Background ───────────────────────────────────────────────────────
BG_RATE = ((r >= 100) & (r < 150)).sum() / (np.pi * (150**2 - 100**2))
print(f"  Background rate: {BG_RATE:.5f} ct arcsec⁻²")

# ── Radial profile ────────────────────────────────────────────────────
r_edges = np.array([0, 4, 8, 12, 16, 19, 24, 30, 38, 50])
r_mid   = 0.5 * (r_edges[:-1] + r_edges[1:])
counts_r=[]; sb_net=[]; sb_err=[]
for r1, r2 in zip(r_edges[:-1], r_edges[1:]):
    cnt  = ((r >= r1) & (r < r2)).sum()
    area = np.pi * (r2**2 - r1**2)
    counts_r.append(cnt); sb_net.append(cnt/area - BG_RATE); sb_err.append(np.sqrt(cnt)/area)
counts_r=np.array(counts_r); sb_net=np.array(sb_net); sb_err=np.array(sb_err)

# ── Symmetry tests ────────────────────────────────────────────────────
mask = r < 24
E_cnt=((dx>0)&mask).sum(); W_cnt=((dx<0)&mask).sum()
N_cnt=((dy>0)&mask).sum(); S_cnt=((dy<0)&mask).sum()
chi2_EW,p_EW=chisquare([E_cnt,W_cnt]); chi2_NS,p_NS=chisquare([N_cnt,S_cnt])

def in_sec(p,a1,a2): return (p>=a1)&(p<a2)
sector_names = ["E","NE","N","NW","W","SW","S","SE"]
sector_vals  = np.array([
    (mask&in_sec(phi,-22.5, 22.5)).sum(),
    (mask&in_sec(phi, 22.5, 67.5)).sum(),
    (mask&in_sec(phi, 67.5,112.5)).sum(),
    (mask&in_sec(phi,112.5,157.5)).sum(),
    (mask&((phi>=157.5)|(phi<-157.5))).sum(),
    (mask&in_sec(phi,-157.5,-112.5)).sum(),
    (mask&in_sec(phi,-112.5, -67.5)).sum(),
    (mask&in_sec(phi, -67.5, -22.5)).sum(),
])
exp_sec = sector_vals.mean()
chi2_oct, p_oct = chisquare(sector_vals)
print(f"  E/W: {E_cnt/W_cnt:.3f}  p={p_EW:.4f}")
print(f"  N/S: {N_cnt/S_cnt:.3f}  p={p_NS:.4f}")
print(f"  Oct: chi2={chi2_oct:.2f}, chi2/nu={chi2_oct/7:.2f}, p={p_oct:.4f}")

# ── Figure A only ─────────────────────────────────────────────
fig = plt.figure(figsize=(3.6, 3.4))

ax_p = fig.add_subplot(111, projection="polar")

# Astronomical E/W flip
ax_p.set_theta_zero_location("W")
ax_p.set_theta_direction(-1)

angs_math = np.radians([0, 45, 90, 135, 180, 225, 270, 315])

bar_colors = [
    "#d62728" if v > 1.25 * exp_sec else
    ("#1f77b4" if v < 0.75 * exp_sec else "#7f7f7f")
    for v in sector_vals
]

ax_p.bar(
    angs_math,
    sector_vals,
    width=np.radians(44),
    color=bar_colors,
    alpha=0.85,
    edgecolor="black",
    lw=0.5,
)

theta_c = np.linspace(0, 2*np.pi, 200)
ax_p.plot(theta_c, np.full_like(theta_c, exp_sec), "k--", lw=0.9)

ax_p.set_xticks(angs_math)
ax_p.set_xticklabels(sector_names, fontsize=8)

ax_p.tick_params(colors="black", labelsize=7)
ax_p.set_rlabel_position(45)

title_a = (
    r"Octant Distribution ($r<24^{\prime\prime}$)" "\n"
    + r"$\chi^2_{\nu}$"
    + f" = {chi2_oct/7:.2f}, "
    + r"$p$"
    + f" = {p_oct:.3f}"
)

ax_p.set_title(title_a, fontsize=9, y=1.08)

ax_p.spines["polar"].set_color("black")
ax_p.spines["polar"].set_linewidth(0.7)
ax_p.grid(color="gray", lw=0.4, alpha=0.5)

legend_handle = mlines.Line2D(
    [], [], color="black", ls="--", lw=0.9,
    label=f"Expected ({exp_sec:.0f})"
)

ax_p.legend(
    handles=[legend_handle],
    loc="upper center",
    bbox_to_anchor=(0.5, -0.08),
    fontsize=7.5,
    framealpha=0.85
)

fig.savefig("octant_distribution.pdf",
            bbox_inches="tight",
            facecolor="white")

fig.savefig("octant_distribution.png",
            dpi=300,
            bbox_inches="tight",
            facecolor="white")

plt.close(fig)




