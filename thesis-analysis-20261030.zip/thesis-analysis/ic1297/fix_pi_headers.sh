#!/bin/bash

A_PATH="./spectrum/A"
B_PATH="./spectrum/B"

# 绝对路径
RMF_A_ABS="${A_PATH}/source.rmf"
ARF_A_ABS="${A_PATH}/source.arf"
BACK_A_ABS="${A_PATH}/back.pha"

RMF_B_ABS="${B_PATH}/source.rmf"
ARF_B_ABS="${B_PATH}/source.arf"
BACK_B_ABS="${B_PATH}/back.pha"

# 修改 A 模块所有 source_A_min*.pi 文件
for pi in ${A_PATH}/source_A_min*.pi; do
    echo "Fixing $pi"
    grppha infile="$pi" outfile="$pi" \
        comm="chkey RESPFILE ${RMF_A_ABS} & chkey ANCRFILE ${ARF_A_ABS} & chkey BACKFILE ${BACK_A_ABS} & exit" \
        clobber=yes
done

# 修改 B 模块所有 source_B_min*.pi 文件
for pi in ${B_PATH}/source_B_min*.pi; do
    echo "Fixing $pi"
    grppha infile="$pi" outfile="$pi" \
        comm="chkey RESPFILE ${RMF_B_ABS} & chkey ANCRFILE ${ARF_B_ABS} & chkey BACKFILE ${BACK_B_ABS} & exit" \
        clobber=yes
done

echo "Done."
