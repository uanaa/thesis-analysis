#!/bin/bash
#==========================================================================
# 从 fit_summary.txt 提取有效字段并绘图（适配新列顺序）
# 列顺序：model stat min chi2 dof kT1 kT2 norm1 norm2 flux chi2_dof
#==========================================================================

SUMMARY="spec_resultsNH001tbabs_apec/fit_summary.txt"
OUTDIR="analysis_resultsNH001tbabs_apec"
PLOTDIR="$OUTDIR/plots"
TABLEDIR="$OUTDIR/tables"
CLEAN="$OUTDIR/clean_summary.dat"

if [ ! -f "$SUMMARY" ]; then
    echo "Error: $SUMMARY not found."
    exit 1
fi

mkdir -p "$PLOTDIR" "$TABLEDIR"

echo "--> Parsing $SUMMARY ..."

# 提取字段并按原 clean_summary.dat 顺序输出
awk 'NF>=10 {
    if (NR==1 && $1 ~ /^[A-Za-z]/ && $2 ~ /^[A-Za-z]/) next;
    model=$1; stat=$2; min=$3; chi2=$4; dof=$5;
    nh=$6; kT1=$7; kT2=$8; norm1=$9; norm2=$10; flux=$11;

    # 正确判断 chi2_dof
    if (NF >= 12 && $12 ~ /^[0-9.+-eE]+$/) {
        chi2_dof = $12;
    } else if (dof ~ /^[0-9]+$/ && dof > 0 && chi2 ~ /^[0-9.+-eE]+$/) {
        chi2_dof = chi2 / dof;
    } else {
        chi2_dof = "NaN";
    }

    if (dof ~ /^[0-9]+$/ && dof > 0 && chi2 ~ /^[0-9.+-eE]+$/) {
        printf "%-10s %-6s %3s %10s %4s %10.4f %12s %12s %12s %12s %12s\n",
               model, stat, min, chi2, dof, chi2_dof,
               kT1, kT2, norm1, norm2, flux;
    }
}' "$SUMMARY" > "$CLEAN"

nlines=$(wc -l < "$CLEAN" | tr -d ' ')
echo "Extracted $nlines valid fits into $CLEAN"

if [ "$nlines" -eq 0 ]; then
    echo "Error: no valid lines found. Check fit_summary.txt format."
    exit 1
fi

# 添加表头（兼容 macOS 与 Linux）
if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' '1s/^/model       stat    min       chi2  dof   chi2_dof       kT1          kT2          norm1        norm2        flux\n/' "$CLEAN"
else
    sed -i '1i\model       stat    min       chi2  dof   chi2_dof       kT1          kT2          norm1        norm2        flux' "$CLEAN"
fi

# 生成最佳拟合表（每个 model+stat 组合取 chi2/dof 最小的行）
best_table="$TABLEDIR/best_fits.txt"
printf "%-10s %-6s %4s %10s %4s %10s %12s %12s %12s %12s %12s\n" \
       model stat min chi2 dof chi2_dof kT1 kT2 norm1 norm2 flux > "$best_table"
tail -n +2 "$CLEAN" | sort -k1,1 -k2,2 -k6,6n | awk '!seen[$1,$2]++' >> "$best_table"
echo "--> Best fits table saved to $best_table"

# 检查 gnuplot
if ! command -v gnuplot &>/dev/null; then
    echo "WARNING: gnuplot not found. Skipping plots. Install with: brew install gnuplot"
    exit 0
fi

# 绘图（脚本内容与原完全一致，无需修改）
gnuplot_script="$OUTDIR/plot.gnu"

cat > "$gnuplot_script" << 'GNUEOF'
set terminal pdfcairo enhanced color solid font "Helvetica,10" size 7,5
set datafile missing "NaN"
set grid

set style line 1 lc rgb "red"     lw 1.5 pt 7 ps 0.8
set style line 2 lc rgb "blue"    lw 1.5 pt 5 ps 0.8

stats = "chi cstat"
clean = "./analysis_resultsNH001tbabs_apec/clean_summary.dat"

# 自动获得所有模型名（精确列表）
models = system("tail -n +2 ".clean." | awk '{print $1}' | sort -u | tr '\n' ' '")

set output "./analysis_resultsNH001tbabs_apec/plots/chi2dof_vs_min.pdf"
set xlabel "min counts"
set ylabel "χ² / dof"
set key outside
do for [m in models] {
    set title "Model: ".m
    plot for [i=1:words(stats)] \
         "< awk -v model='".m."' -v stat='".word(stats,i)."' '$1==model && $2==stat' ".clean." | sort -k3,3n" \
         using 3:6 with linespoints ls i title word(stats,i)
}

set output "./analysis_resultsNH001tbabs_apec/plots/kT1_vs_min.pdf"
set ylabel "kT₁ (keV)"
do for [m in models] {
    set title "Model: ".m
    plot for [i=1:words(stats)] \
         "< awk -v model='".m."' -v stat='".word(stats,i)."' '$1==model && $2==stat' ".clean." | sort -k3,3n" \
         using 3:7 with linespoints ls i title word(stats,i)
}

set output "./analysis_resultsNH001tbabs_apec/plots/kT2_vs_min.pdf"
set ylabel "kT₂ (keV)"
do for [m in models] {
    set title "Model: ".m
    plot for [i=1:words(stats)] \
         "< awk -v model='".m."' -v stat='".word(stats,i)."' '$1==model && $2==stat' ".clean." | sort -k3,3n" \
         using 3:8 with linespoints ls i title word(stats,i)
}

set output "./analysis_resultsNH001tbabs_apec/plots/flux_vs_min.pdf"
set ylabel "Flux (0.3-2.5 keV)"
do for [m in models] {
    set title "Model: ".m
    plot for [i=1:words(stats)] \
         "< awk -v model='".m."' -v stat='".word(stats,i)."' '$1==model && $2==stat' ".clean." | sort -k3,3n" \
         using 3:11 with linespoints ls i title word(stats,i)
}
GNUEOF

echo "--> Generating plots..."
gnuplot "$gnuplot_script"
echo "--> Plots saved in $PLOTDIR"
echo "All done."