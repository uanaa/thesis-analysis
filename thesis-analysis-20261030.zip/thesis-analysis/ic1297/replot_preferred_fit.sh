#!/bin/bash
# ============================================================
# Step 1: XSPEC 正常拟合（从好的初值出发）+ 导出 QDP
# Step 2: Python matplotlib 画图
# 在 spec_resultsNH001tbabs_apec 目录下运行
# ============================================================

OUT_DIR="."
QDP="/tmp/spec8.qdp"
OUTPDF="./tbabs_apec_cstat_8_apjl.pdf"
OUTEPS="./tbabs_apec_cstat_8_apjl.eps"
log="${OUT_DIR}/logs/replot_tbabs_apec_cstat_8.txt"

mkdir -p "${OUT_DIR}/logs"
rm -f "$QDP"

# ---- 写 xcm 文件（用文件而非管道，避免交互时序问题）----
cat > /tmp/replot8.xcm << 'EOF'
query yes
data 1 ./spectrum/A/source_A_min8.pi
data 2 ./spectrum/B/source_B_min8.pi
ignore bad
ignore 1:**-0.3 2.0-**
ignore 2:**-0.3 2.0-**
abund wilm
xsect vern
model tbabs*apec
/*
statistic cstat
newpar 1 0.02903 0.001 0.01 0.01 10.0 10.0
newpar 2 0.08560 0.001 0.08 0.08 0.60 0.60
newpar 5 6.507e-4 1e-6 1e-6 1e-6 1e-1 1e-1
fit 500
tclout stat
set s [lindex $xspec_tclout 0]
tclout dof
set d [lindex $xspec_tclout 0]
puts "CSTAT=$s DOF=$d"
tclout param 1
puts "NH=[lindex $xspec_tclout 0]"
tclout param 2
puts "KT=[lindex $xspec_tclout 0]"
setplot energy
iplot ldata delchi
wdata /tmp/spec8.qdp
quit
EOF

echo "Step 1: XSPEC 拟合中..."
xspec - < /tmp/replot8.xcm > "$log" 2>&1

echo "--- log tail ---"
tail -20 "$log"
echo "----------------"
grep -E "^CSTAT=|^NH=|^KT=" "$log" | tail -5

if [ ! -f "$QDP" ]; then
    echo "✗ QDP 未生成，查看完整日志："
    cat "$log"
    exit 1
fi
echo "✓ QDP 生成 ($(wc -l < $QDP | tr -d ' ') 行)"

# ============================================================
# Step 2: Python
# ============================================================
echo "Step 2: Python 画图..."

python3 << 'PYEOF'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

qdp_file = "/tmp/spec8.qdp"
out_pdf  = "./tbabs_apec_cstat_8_apjl.pdf"
out_eps  = "./tbabs_apec_cstat_8_apjl.eps"

blocks = []
current = []
with open(qdp_file) as f:
    for line in f:
        s = line.strip()
        if not s or s.startswith('!') or s.startswith('@') or s.upper().startswith('READ'):
            continue
        if s.upper().startswith('NO'):
            if current:
                blocks.append(current)
                current = []
        else:
            nums = []
            for tok in s.split():
                try:
                    nums.append(float(tok))
                except ValueError:
                    pass
            if len(nums) >= 3:
                current.append(nums)
if current:
    blocks.append(current)

print(f"QDP blocks: {len(blocks)}")
for i, b in enumerate(blocks):
    print(f"  block {i}: {len(b)} rows x {len(b[0])} cols")

def arr(b): return np.array(b, dtype=float)
b0 = arr(blocks[0])
b1 = arr(blocks[1])
b2 = arr(blocks[2])
b3 = arr(blocks[3])

eA,  deA,  rA,  reA,  mA  = b0[:,0], b0[:,1], b0[:,2], b0[:,3], b0[:,4]
eB,  deB,  rB,  reB,  mB  = b1[:,0], b1[:,1], b1[:,2], b1[:,3], b1[:,4]
eAr, deAr, chiA            = b2[:,0], b2[:,1], b2[:,2]
eBr, deBr, chiB            = b3[:,0], b3[:,1], b3[:,2]

print(f"mA range:  {mA.min():.2e} ~ {mA.max():.2e}")
print(f"chiA range: {chiA.min():.2f} ~ {chiA.max():.2f}")
print(f"chiB range: {chiB.min():.2f} ~ {chiB.max():.2f}")

fig, (ax1, ax2) = plt.subplots(
    2, 1, figsize=(3.5, 4.2), sharex=True,
    gridspec_kw={'height_ratios': [3, 1], 'hspace': 0.0}
)

# 上面板
ax1.errorbar(eA, rA, xerr=deA, yerr=reA, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='black', label='EP/FXT-A', zorder=3)
ax1.errorbar(eB, rB, xerr=deB, yerr=reB, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='red', label='EP/FXT-B', zorder=3)
ax1.step(np.append(eA-deA, eA[-1]+deA[-1]), np.append(mA, mA[-1]),
         where='post', color='black', lw=1.0, zorder=2)
ax1.step(np.append(eB-deB, eB[-1]+deB[-1]), np.append(mB, mB[-1]),
         where='post', color='red', lw=1.0, zorder=2)

ax1.set_yscale('log')
ax1.set_xscale('log')
ax1.set_ylim(1e-5, 1)
ax1.set_xlim(0.28, 2.1)
ax1.set_ylabel(r'Counts s$^{-1}$ keV$^{-1}$', fontsize=8)
ax1.legend(fontsize=7, frameon=False, loc='upper right',
           handlelength=1.2, handletextpad=0.4)
ax1.tick_params(axis='both', which='both', direction='in',
                top=True, right=True, labelsize=7.5)
ax1.tick_params(labelbottom=False)

# 下面板
ax2.errorbar(eAr, chiA, xerr=deAr, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='black', zorder=3)
ax2.errorbar(eBr, chiB, xerr=deBr, fmt='o', ms=2.5,
             lw=0.6, capsize=0, color='red', zorder=3)
ax2.axhline(0, color='black', lw=0.8, ls='--', zorder=2)
ax2.set_ylim(-5, 5)
ax2.set_yticks([-4, -2, 0, 2, 4])
ax2.set_ylabel(r'$(d-m)/\sigma$', fontsize=8)
ax2.set_xlabel('Energy (keV)', fontsize=8)
ax2.tick_params(axis='both', which='both', direction='in',
                top=True, right=True, labelsize=7.5)

ax2.set_xticks([0.3, 0.5, 1.0, 2.0])
ax2.xaxis.set_major_formatter(mticker.FixedFormatter(['0.3', '0.5', '1', '2']))
ax2.xaxis.set_minor_locator(mticker.NullLocator())

for ax in [ax1, ax2]:
    for spine in ax.spines.values():
        spine.set_linewidth(0.8)

fig.savefig(out_pdf, bbox_inches='tight', dpi=300)
fig.savefig(out_eps, bbox_inches='tight')
print(f"Saved: {out_pdf}")
PYEOF

[ $? -eq 0 ] && echo "✓ 完成！PDF: $OUTPDF" || echo "✗ Python 失败"