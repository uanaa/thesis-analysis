# Data and software

## Python

The requirements file lists the imported scientific libraries. SciPy 1.15 or
later is needed for the resampling interface in the morphology comparison.
Python 3.11 or later is the supported target for this package.

## Input files

| Workflow | Required external inputs | Configuration |
|---|---|---|
| HASH matching | `TruePNe.csv`, the 30 May 2024 export used in the thesis | `PN_DATA_DIR` |
| ChanPlaNS cohort rebuild | Same HASH export; the HI4PI cache is included | `PN_DATA_DIR` |
| Optical inventory | Optical archive and a census CSV | Explicit command-line arguments |
| LE01 | 104 paired raw/screened Crab FITS, matching aspect FITS | `LE01_DATA_ROOT` |
| LE01 screening | New-screen pixel catalogue and per-observation candidates, or raw data to rebuild them | `LE01_MASK_DIR` |
| GRB 220304A | Event FITS, observation-information CSV, new-screen catalogue | Explicit command-line arguments |
| IC1297 | ObsID 11900356352 FXT-A/B data, source/background regions, spectra, RMFs and ARFs | External working directory |
| IC1297 images | Merged event list, band event files and DECam image | External working directory |

The full HASH export and mission files are obtained through their respective
data services or original observing archive. They are not redistributed in this
code repository. A different catalogue snapshot or calibration version can
change the numerical results.

`reference/pn/chanplans/` includes the literature-based 59-object cohort and
the cached total Galactic HI4PI columns used in the comparison. Its original
sources are Kastner et al. (2012), AJ 144, 58, and Freeman et al. (2014), ApJ
794, 99. The HI4PI values are matching covariates, not fitted foreground
columns to individual nebulae.

## Mission software

The IC1297 workflow also requires the thesis versions of FXTDAS (1.3.0), its
calibration data, and HEASoft/XSPEC (`grppha`, `fparkey`, `xspec` and the FXT
tasks called by the pipeline). Initialise these tools in the shell before
running the scripts. The XSPEC scripts set Wilms abundances and Verner
cross-sections; retain the same APEC atomic database when comparing fits.

Raw/calibration FITS and generated binary caches are excluded by `.gitignore`.
Run reduction scripts in a copy of the observing workspace: some mission tasks
use `clobber=yes` for their derived products.
