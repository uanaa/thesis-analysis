# Planetary-nebula analyses

## ChanPlaNS statistics: included cohort

From the repository root:

```bash
python pn/analyse_chanplans_controls.py
```

The input defaults to `reference/pn/chanplans/chanplans_observed_cohort_59.csv`.
If a newly rebuilt cohort exists in `outputs/pn/chanplans/`, that file is used
instead. Results include contingency tests, matched pairs, balance measurements
and conditional paired tests. Reference outputs are provided alongside the
included cohort.

The sample contains 59 observed nebulae: 32 detections and 27 non-detections.
Point-source and diffuse outcomes overlap and are analysed separately. Lo 16's
tentative point-source flag is retained. These results describe this observed
cohort; matching does not fully balance all observing conditions.

## HASH matching

Place the thesis catalogue snapshot at `$PN_DATA_DIR/TruePNe.csv`:

```bash
export PN_DATA_DIR="/path/to/hash-inputs"
python pn/matched_morphology.py
```

The included `reference/pn/xpn_morphology_41.csv` supplies the XPN census.
The script normalises PNG identifiers and removes duplicate catalogue rows.
Outputs are written to `outputs/pn/matched/`. The principal comparisons are
41 XPNe against 82 controls and, with an additional H-alpha restriction,
31 XPNe against 31 controls. Random seeds and resampling counts remain in the
script. Reference results include the overall probabilities 0.000210 and
0.453213, respectively.

To rebuild the ChanPlaNS input table with the same HASH snapshot:

```bash
python pn/build_chanplans_cohort.py
python pn/analyse_chanplans_controls.py
```

The builder first uses the included HI4PI cache. An uncached coordinate causes
a request to the official HEASARC nH service.

## Optical-file inventory

```bash
python pn/inventory_optical_spectra.py --help
```

Supply the archive, census and output paths explicitly. This script records file
availability; spectral calibration and line-ratio suitability are assessed in
the thesis catalogue and optical-provenance appendix.

## Fixed-target matching sensitivity

```bash
python pn/matching_sensitivity.py
```

Use the same `PN_DATA_DIR/TruePNe.csv` snapshot as above. The script first
reproduces the 41-to-82 and 31-to-31 comparisons, then holds the 31 targets
and the flux-available control pool fixed. It compares one and two controls
per target under the same diameter and latitude limits. Adding the H-alpha
limit changes p from 0.153 to 0.453 in the one-to-one comparison. Both are
non-significant; the difference from the full sample cannot be attributed
to H-alpha alone. All counts, odds ratios, confidence intervals, selected
controls and seeds are written under `outputs/pn/matching_sensitivity/`.
One hundred alternative assignments within the three limits provide a
sensitivity check, not a population sampling distribution.

The updated 4XMM review is `Chapter5_4XMM_reviewed_pairs_73_20261030.csv`.
It preserves the reconstructed 73-pair columns and adds `review_class_20261030` and
`review_reason_20261030`. Of the 30 soft-selected pairs, K denotes 12 published
associations, C four preliminary candidates, S five rejected associations,
and U nine unresolved associations. Blank common names do not exclude a
pair; HASH IDs identify those entries. Two rejected wide-offset comparison
objects are outside the 20-arcsec parent search and are not in these totals.
