#!/usr/bin/env python3
"""Inventory the dedicated optical-source archive for the Chapter 4 XPN catalog."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


CENSUS_DIRECTORIES = {
    "A30": "a30",
    "A78": "a78",
    "BD+30 3639": "bd+30",
    "DS 1": "ds1",
    "Hb 5": "hb5",
    "HFG 1": "hfg1",
    "IC 418": "ic418",
    "IC 1297": "ic1297",
    "IC 4593": "ic4593",
    "K 1-16": "k116",
    "Lo 16": "lo16",
    "LoTr 5": "lotr5",
    "NGC 1360": "ngc1360",
    "NGC 1514": "ngc1514",
    "NGC 40": "ngc40",
    "NGC 2371": "ngc2371",
    "NGC 2392": "ngc2392",
    "NGC 246": "ngc246",
    "NGC 2867": "ngc2867",
    "NGC 3242": "ngc3242",
    "NGC 3918": "ngc3918",
    "NGC 4361": "ngc4361",
    "NGC 5189": "ngc5189",
    "NGC 5315": "ngc5315",
    "NGC 6153": "ngc6153",
    "NGC 6337": "ngc6337",
    "NGC 6369": "ngc6369",
    "NGC 6445": "ngc6445",
    "NGC 6543": "ngc6543",
    "NGC 6826": "ngc6826",
    "NGC 6853": "ngc6853",
    "NGC 7008": "ngc7008",
    "NGC 7009": "ngc7009",
    "NGC 7026": "ngc7026",
    "NGC 7027": "ngc7027",
    "NGC 7094": "ngc7094",
    "NGC 7293": "ngc7293",
    "NGC 7662": "ngc7662",
    "Sp 1": "sp1",
    "HbDs 1": "HbDs1",
    "Mz 3": "menzel3",
}


def spectrum_like_files(directory: Path) -> list[Path]:
    selected = []
    for path in sorted(directory.iterdir()):
        lower = path.name.lower()
        if path.is_file() and (
            lower.endswith((".fits", ".fit", ".fits.gz", ".fit.txt", ".csv"))
        ):
            selected.append(path)
    return selected


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--census", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    census = pd.read_csv(args.census)
    census_names = set(census["Name"].astype(str))
    if census_names != set(CENSUS_DIRECTORIES):
        missing = sorted(census_names - set(CENSUS_DIRECTORIES))
        extra = sorted(set(CENSUS_DIRECTORIES) - census_names)
        raise ValueError(f"Census mapping mismatch; missing={missing}, extra={extra}")

    rows = []
    for object_name, dirname in CENSUS_DIRECTORIES.items():
        directory = args.archive / dirname
        spectra = spectrum_like_files(directory)
        rows.append(
            {
                "object_name": object_name,
                "archive_directory": dirname,
                "census_status": "known XPN census member",
                "directory_present": directory.is_dir(),
                "local_spectrum_like_file_count": len(spectra),
                "local_spectrum_like_files": "; ".join(p.name for p in spectra),
                "catalog_use": (
                    "object-level catalog/provenance; not automatically added "
                    "to positive-only model training"
                ),
            }
        )

    control_dir = args.archive / "ngc2346"
    control_spectra = spectrum_like_files(control_dir)
    rows.append(
        {
            "object_name": "NGC 2346",
            "archive_directory": "ngc2346",
            "census_status": "X-ray-observed nondetection control; not in 41 XPN census",
            "directory_present": control_dir.is_dir(),
            "local_spectrum_like_file_count": len(control_spectra),
            "local_spectrum_like_files": "; ".join(
                p.name for p in control_spectra
            ),
            "catalog_use": "control-sample provenance",
        }
    )

    result = pd.DataFrame(rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False)


if __name__ == "__main__":
    main()
