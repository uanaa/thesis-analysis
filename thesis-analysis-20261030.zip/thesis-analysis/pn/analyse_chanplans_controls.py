#!/usr/bin/env python3
"""Statistical analysis of observed ChanPlaNS detections and non-detections."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from scipy.stats import beta, binomtest, chi2_contingency, fisher_exact
from scipy.stats.contingency import odds_ratio


REPO = Path(__file__).resolve().parents[1]
ROOT = REPO / "outputs/pn/chanplans"
ROOT.mkdir(parents=True, exist_ok=True)
INPUT = ROOT / "chanplans_observed_cohort_59.csv"
if not INPUT.exists():
    INPUT = REPO / "reference/pn/chanplans/chanplans_observed_cohort_59.csv"
OUTCOMES = ["detected_any", "detected_diffuse", "detected_point"]
COVARIATES = {
    "log_distance": lambda d: np.log10(d["distance_kpc"]),
    "log_exposure": lambda d: np.log10(d["exposure_ks"]),
    "log_nh": lambda d: d["log10_nh_hi4pi"],
    "log_angular_radius": lambda d: np.log10(d["angular_radius_arcsec"]),
    "optical_tier": lambda d: d["optical_tier"].astype(float),
}


def smd(x: pd.Series, y: pd.Series) -> float:
    vx, vy = x.var(ddof=1), y.var(ddof=1)
    pooled = math.sqrt((vx + vy) / 2.0)
    return float((x.mean() - y.mean()) / pooled) if pooled > 0 else 0.0


def contingency_result(df: pd.DataFrame, outcome: str, morph_col: str, positive: str) -> dict:
    exposed = df[morph_col].eq(positive)
    detected = df[outcome].eq(1)
    table = np.array(
        [
            [(exposed & detected).sum(), (exposed & ~detected).sum()],
            [(~exposed & detected).sum(), (~exposed & ~detected).sum()],
        ],
        dtype=int,
    )
    fish = fisher_exact(table, alternative="two-sided")
    chi = chi2_contingency(table, correction=False)
    exact_or = odds_ratio(table, kind="conditional")
    ci = exact_or.confidence_interval(0.95)
    expected = chi.expected_freq
    return {
        "outcome": outcome,
        "morphology": morph_col,
        "positive_class": positive,
        "subset": "full_59",
        "n": int(len(df)),
        "table_rows": f"{positive};other",
        "table_columns": "detected;not_detected",
        "table": json.dumps(table.tolist()),
        "odds_ratio_conditional": float(exact_or.statistic),
        "or_ci_low": float(ci.low),
        "or_ci_high": float(ci.high),
        "fisher_p": float(fish.pvalue),
        "chi2": float(chi.statistic),
        "chi2_p": float(chi.pvalue),
        "minimum_expected_count": float(expected.min()),
        "chi2_reliable_all_expected_ge5": bool((expected >= 5).all()),
    }


def optimal_pairs(
    df: pd.DataFrame,
    outcome: str,
    exact_optical_tier: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    work = df.copy()
    for name, function in COVARIATES.items():
        work[name] = function(work)
    z = work[list(COVARIATES)].copy()
    z = (z - z.mean()) / z.std(ddof=0)
    work[[f"z_{name}" for name in COVARIATES]] = z

    pair_rows = []
    pair_id = 0
    exact_columns = ["phase"] + (["optical_tier"] if exact_optical_tier else [])
    for key, stratum in work.groupby(exact_columns, dropna=False):
        cases = stratum[stratum[outcome].eq(1)]
        controls = stratum[stratum[outcome].eq(0)]
        if cases.empty or controls.empty:
            continue
        case_matrix = cases[[f"z_{name}" for name in COVARIATES]].to_numpy(float)
        control_matrix = controls[[f"z_{name}" for name in COVARIATES]].to_numpy(float)
        cost = np.sqrt(((case_matrix[:, None, :] - control_matrix[None, :, :]) ** 2).sum(axis=2))
        case_idx, control_idx = linear_sum_assignment(cost)
        for i, j in zip(case_idx, control_idx):
            pair_id += 1
            case = cases.iloc[i]
            control = controls.iloc[j]
            row = {
                "outcome": outcome,
                "match_design": "phase+optical_tier" if exact_optical_tier else "phase",
                "pair_id": pair_id,
                "phase": case["phase"],
                "case_name": case["name"],
                "case_png": case["png"],
                "control_name": control["name"],
                "control_png": control["png"],
                "distance": float(cost[i, j]),
            }
            for column in [
                "f08_broad", "smv11_broad", "distance_kpc", "exposure_ks",
                "nh_hi4pi_cm2", "angular_radius_arcsec", "optical_tier",
                "morph_concordant",
            ]:
                row[f"case_{column}"] = case[column]
                row[f"control_{column}"] = control[column]
            pair_rows.append(row)

    pairs = pd.DataFrame(pair_rows)
    balance_rows = []
    all_cases = work[work[outcome].eq(1)]
    all_controls = work[work[outcome].eq(0)]
    for covariate in COVARIATES:
        before = smd(all_cases[covariate], all_controls[covariate])
        if pairs.empty:
            after = math.nan
        else:
            after = smd(
                pairs[f"case_{'nh_hi4pi_cm2' if covariate == 'log_nh' else 'distance_kpc' if covariate == 'log_distance' else 'exposure_ks' if covariate == 'log_exposure' else 'angular_radius_arcsec' if covariate == 'log_angular_radius' else 'optical_tier'}"].pipe(np.log10) if covariate != "optical_tier" else pairs["case_optical_tier"],
                pairs[f"control_{'nh_hi4pi_cm2' if covariate == 'log_nh' else 'distance_kpc' if covariate == 'log_distance' else 'exposure_ks' if covariate == 'log_exposure' else 'angular_radius_arcsec' if covariate == 'log_angular_radius' else 'optical_tier'}"].pipe(np.log10) if covariate != "optical_tier" else pairs["control_optical_tier"],
            )
        balance_rows.append(
            {
                "outcome": outcome,
                "match_design": "phase+optical_tier" if exact_optical_tier else "phase",
                "covariate": covariate,
                "smd_before": before,
                "smd_after": after,
                "abs_smd_after": abs(after),
                "balanced_abs_smd_lt_0.10": bool(abs(after) < 0.10) if np.isfinite(after) else False,
                "n_pairs": int(len(pairs)),
            }
        )
    return pairs, pd.DataFrame(balance_rows)


def paired_conditional_result(
    pairs: pd.DataFrame,
    morph_col: str,
    positive: str,
) -> dict:
    case = pairs[f"case_{morph_col}"].eq(positive)
    control = pairs[f"control_{morph_col}"].eq(positive)
    case_only = int((case & ~control).sum())
    control_only = int((~case & control).sum())
    both = int((case & control).sum())
    neither = int((~case & ~control).sum())
    discordant = case_only + control_only
    if discordant:
        pvalue = float(binomtest(case_only, discordant, p=0.5).pvalue)
        estimate = math.inf if control_only == 0 else case_only / control_only
        p_low = 0.0 if case_only == 0 else float(beta.ppf(0.025, case_only, control_only + 1))
        p_high = 1.0 if control_only == 0 else float(beta.ppf(0.975, case_only + 1, control_only))
        ci_low = p_low / (1 - p_low) if p_low < 1 else math.inf
        ci_high = p_high / (1 - p_high) if p_high < 1 else math.inf
    else:
        pvalue = math.nan
        estimate = math.nan
        ci_low = math.nan
        ci_high = math.nan
    return {
        "outcome": pairs["outcome"].iloc[0],
        "match_design": pairs["match_design"].iloc[0],
        "morphology": morph_col,
        "positive_class": positive,
        "n_pairs": int(len(pairs)),
        "case_positive_control_negative": case_only,
        "case_negative_control_positive": control_only,
        "both_positive": both,
        "both_negative": neither,
        "conditional_odds_ratio": estimate,
        "or_ci_low_exact": ci_low,
        "or_ci_high_exact": ci_high,
        "exact_conditional_p": pvalue,
    }


def cycle14_results(df: pd.DataFrame) -> list[dict]:
    subset = df[df["phase"].eq("Cycle14")]
    results = []
    for outcome in OUTCOMES:
        for morph_col, positive in [("f08_broad", "B"), ("smv11_broad", "B/M")]:
            result = contingency_result(subset, outcome, morph_col, positive)
            result["subset"] = "Cycle14_24"
            results.append(result)
    return results


def main() -> None:
    df = pd.read_csv(INPUT)
    contingency = []
    for outcome in OUTCOMES:
        for morph_col, positive in [("f08_broad", "B"), ("smv11_broad", "B/M")]:
            contingency.append(contingency_result(df, outcome, morph_col, positive))
    contingency.extend(cycle14_results(df))
    contingency_df = pd.DataFrame(contingency)

    all_pairs = []
    all_balance = []
    conditional = []
    for exact_optical in [False, True]:
        for outcome in OUTCOMES:
            pairs, balance = optimal_pairs(df, outcome, exact_optical_tier=exact_optical)
            all_pairs.append(pairs)
            all_balance.append(balance)
            if not pairs.empty:
                conditional.append(paired_conditional_result(pairs, "f08_broad", "B"))
                conditional.append(paired_conditional_result(pairs, "smv11_broad", "B/M"))

    pairs_df = pd.concat(all_pairs, ignore_index=True)
    balance_df = pd.concat(all_balance, ignore_index=True)
    conditional_df = pd.DataFrame(conditional)

    contingency_df.to_csv(ROOT / "contingency_tests.csv", index=False)
    pairs_df.to_csv(ROOT / "matched_pairs.csv", index=False)
    balance_df.to_csv(ROOT / "match_balance.csv", index=False)
    conditional_df.to_csv(ROOT / "conditional_logistic_results.csv", index=False)

    print("Unmatched Fisher/chi-square results")
    print(contingency_df[["subset", "outcome", "morphology", "table", "odds_ratio_conditional", "or_ci_low", "or_ci_high", "fisher_p", "chi2_p", "minimum_expected_count"]].to_string(index=False))
    print("\nMatched conditional results")
    print(conditional_df.to_string(index=False))
    print("\nBalance")
    print(balance_df.to_string(index=False))


if __name__ == "__main__":
    main()
