#!/usr/bin/env python3
"""Build the 59-object ChanPlaNS observed cohort from Papers I and II.

The object-level values are transcribed from Table 1 of Kastner et al. (2012)
and Table 1 of Freeman et al. (2014). Chandra exposures are summed per target
from Table 2 of the corresponding paper. The optical-image source is read from
the labelled panels in the published pipeline figures. Total Galactic H I
columns are queried from the official HEASARC nH interface using the HI4PI map;
they are line-of-sight matching covariates, not PN foreground absorption fits.
"""

from __future__ import annotations

import csv
import os
import html
import math
import re
import time
import urllib.parse
import urllib.request
from io import StringIO
from pathlib import Path

import pandas as pd


REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "outputs/pn/chanplans"
OUT.mkdir(parents=True, exist_ok=True)
HASH_PATH = Path(os.environ.get("PN_DATA_DIR", REPO / "data/pn")).expanduser() / "TruePNe.csv"


# Columns: name, png, F08 morphology, SMV11 morphology, distance (kpc),
# nebular radius (pc), age (kyr), H2 flag, X-ray status, phase, optical image.
RAW = r"""name|png|morph_f08|morph_smv11|distance_kpc|rneb_pc|age_kyr|h2|xray_status|phase|optical_image
NGC 650|130.9-10.5|Bas(h)|Bcbpa|1.20|0.40|10|Y|N|Cycle12|WIYN-Ha
NGC 1360|220.3-53.9|Efp|Ecs|0.38|0.31|9|N|P|Cycle12|WIYN-Ha
NGC 1514|165.5-15.2|Ems|Is|0.37|0.12|5||P|Cycle12|WIYN-Ha
NGC 2346|215.6+03.6|Bs|Bobsp|0.90|0.14|11|Y|N|Cycle12|HST-Ha
NGC 2371|189.1+19.8|Eps|Bcbspa|1.41|0.13|3|N|D,P|Cycle12|WIYN-Ha
NGC 2438|231.8+04.1|Emr(h)|Ecs|1.42|0.27|12||N|Cycle12|WIYN-Ha
NGC 3242|261.0+32.0|Em(h)|Ecspaih|1.00|0.10|4|N|D|Cycle12|HST-Ha
NGC 3587|148.4+57.0|Rfm:|Rspi|0.76|0.38|11|N|N|Cycle12|WIYN-Ha
NGC 6302|349.5+01.0|Bps|Btp|1.17|0.16||Y|N|Cycle12|DSS-R
NGC 6445|008.0+03.9|Bs|Mpi|1.39|0.14|3|Y|P|Cycle12|DSS-R
NGC 6720|063.1+13.9|Ebmr(h)|Ecsh|0.70|0.13|6|Y|N|Cycle12|HST-Ha
NGC 6772|033.1-06.3|Ep|E|1.20|0.22|19|Y|N|Cycle12|DSS-R
NGC 6781|041.8-02.9|Bam(h:)|Bth|0.95|0.32|26|Y|N|Cycle12|DSS-R
NGC 6804|045.7-04.5|Eam|Ms|1.47|0.19|7|Y|N|Cycle12|DSS-R
NGC 6853|060.8-03.6|Ebm(h)|Bbpih|0.38|0.37|11|Y|P|Cycle12|WIYN-Ha
NGC 7008|093.4+05.4|Efp|Bs|0.70|0.15|4||P|Cycle12|WIYN-Ha
NGC 7009|037.7-34.5|Emps(h)|Lbspa|1.45|0.09|3|N|D,P|Cycle12|HST-Ha
NGC 7094|066.7-28.2|Ras|Rs|1.39|0.34|8|N|P|Cycle12|DSS-R
NGC 7662|106.5-17.6|Emp(h)|Esah|1.26|0.09|3|N|D|Cycle12|HST-Ha
Abell 33|238.0+34.8|Ra|R|1.16|0.78|24||N|Cycle12|DSS-R
Lo 16|349.3-04.2|Eps|Ispa|0.84|0.17|||P?|Cycle12|Gemini-Ha
NGC 40|120.0+09.8|Eas(h)|Bbsh|1.02|0.11|4|N|D|Archive|INT-Ha
NGC 246|118.8-74.7|Ea|Es|0.50|0.29|8|N|P|Archive|WIYN-Ha
NGC 2392|197.8+17.3|Rm|Rsai|1.28|0.14|3|N|D,P|Archive|HST-Ha
NGC 3132|272.1+12.3|Er|Mtsp|0.81|0.13|6|Y|N|Archive|HST-Ha
NGC 4361|294.1+43.6|Es|Ebs|0.95|0.27|8|N|P|Archive|DSS-R
NGC 6543|096.4+29.9|Emps(h)|Mcspa|1.50|0.09|5|N|D,P|Archive|HST-Ha
NGC 6826|083.5+12.7|Emp(h)|Ecsah|1.30|0.08|5|N|D,P|Archive|HST-Ha
NGC 7027|084.9-03.4|Bs|Mctspih|0.89|0.03|1.4|Y|D|Archive|HST-Ha
NGC 7293|036.1-57.1|Bams(h)|Ltspir|0.22|0.46|21|Y|P|Archive|DSS-R
BD+30 3639|064.7+05.0|Er|Ecsarh|1.30|0.02|1|Y|D|Archive|HST-Ha
DS 1|283.9+09.7|Efp|Is|0.73|0.59|19||P|Archive|SSS-Ha
HFG 1|136.3+05.5|Ea(h:)|R|0.60|0.79|51||P|Archive|DSS-R
IC 418|215.2-24.2|Em(h:)|Ecspih|1.20|0.04|3|N|D|Archive|HST-Ha
LoTr 5|339.9+88.4|Eabf|Ss|0.50|0.64|20||P|Archive|DSS-R
Abell 65|017.3-21.9|Eafm:|Ls|1.17|0.30|17.5||N|Cycle14|DSS-R
HaWe 13|034.1-10.5|Efp?|Esip|1.01|0.18|||N|Cycle14|SHS-Ha
Hb 5|359.3-00.9|Bps|Bcbmph|1.70|0.13|1.5|Y|D|Cycle14|HST-Ha
HbDs 1|273.6+06.1|Er?|Is|0.80|0.29|||P|Cycle14|SHS-Ha
He 2-11|259.1+00.9|Ebps|Bcbsip|1.14|0.24|0.7||N|Cycle14|SHS-Ha
IC 1295|025.4-04.7|Efm:|Es(b/ti)|1.23|0.30|11||N|Cycle14|SHS-Ha
IC 2149|166.1+10.4|E|Bsh|1.52|0.04|2|N|N|Cycle14|WIYN-Ha
IC 4637|345.4+00.1|Eam|Estp|1.30|0.05|2||N|Cycle14|DSS-R
IC 5148/50|002.7-52.4|Rm|Rsiph|0.85|0.27|5||N|Cycle14|DSS-R
M 1-26|358.9-00.7|R|Mcbsih|1.20|0.02|1||N|Cycle14|HST-Ha
M 1-41|006.7-02.2|Bs|(I/B)|1.47|0.15||Y|N|Cycle14|DSS-R
NGC 1501|144.5+06.5|Es|Esph|0.72|0.09|2||D|Cycle14|HST-Ha
NGC 2899|277.1-03.8|Baps|Bosbp|1.37|0.37|14|Y|N|Cycle14|SHS-Ha
NGC 3918|294.6+04.7|Ems(h)|Lsbairh|1.84|0.08|3||D|Cycle14|HST-Ha
NGC 6026|341.6+13.7|Ef|Ish|1.31|0.16|6||N|Cycle14|DSS-R
NGC 6072|342.1+10.8|Ba|Mcot|1.39|0.23|23|Y|N|Cycle14|DSS-R
NGC 6153|341.8+05.4|Es|Esah|1.10|0.07|4|N|D|Cycle14|HST-Ha
NGC 6337|349.3-01.1|Epr|Rsarh|0.86|0.10|12||P|Cycle14|SHS-Ha
NGC 6369|002.4+05.8|Ebpr(h:)|Mcst|1.55|0.12|3|Y|D|Cycle14|HST-Ha
NGC 6894|069.4-02.6|Emr|Eh|1.31|0.17|4||N|Cycle14|WIYN-Ha
NGC 7076|101.8+08.7|Ea|Esh|1.47|0.20|5||N|Cycle14|WIYN-Ha
NGC 7354|107.8+02.3|Emp|Esaph|1.60|0.09|3|N|N|Cycle14|WIYN-Ha
Sh 2-71|035.9-01.1|Bs|Lsbp|1.14|0.30|14|N|N|Cycle14|SHS-Ha
Sp 1|329.0+01.9|Rr|Rsh|1.13|0.20|6||P|Cycle14|SHS-Ha
"""


EXPOSURES = {
    "Abell 33": ("12369", 29.67),
    "BD+30 3639": ("587;10821;9932", 95.88),
    "DS 1": ("9953", 24.15),
    "HFG 1": ("9954", 11.45),
    "IC 418": ("7440", 49.38),
    "Lo 16": ("12367", 30.00),
    "LoTr 5": ("3212", 27.74),
    "NGC 40": ("4481", 19.89),
    "NGC 246": ("2565", 40.95),
    "NGC 650": ("12371", 29.90),
    "NGC 1360": ("12362", 19.65),
    "NGC 1514": ("12361", 20.78),
    "NGC 2346": ("12379", 29.89),
    "NGC 2371": ("12376", 29.67),
    "NGC 2392": ("7421", 57.41),
    "NGC 2438": ("3765;12377", 79.42),
    "NGC 3132": ("4514", 23.97),
    "NGC 3242": ("12380", 29.26),
    "NGC 3587": ("12366", 19.24),
    "NGC 4361": ("3760", 29.38),
    "NGC 6302": ("14364;12370", 30.01),
    "NGC 6445": ("12375", 29.68),
    "NGC 6543": ("630;11999;10443", 93.12),
    "NGC 6720": ("12364", 19.80),
    "NGC 6772": ("12372", 29.37),
    "NGC 6781": ("12368", 28.25),
    "NGC 6804": ("12378", 29.58),
    "NGC 6826": ("8559;7439", 49.12),
    "NGC 6853": ("12363", 19.80),
    "NGC 7008": ("12365", 18.22),
    "NGC 7009": ("12381", 29.66),
    "NGC 7027": ("588", 18.22),
    "NGC 7094": ("12374", 29.67),
    "NGC 7293": ("631;1480", 48.15),
    "NGC 7662": ("12373", 27.61),
    "Abell 65": ("14583", 29.7),
    "HaWe 13": ("14578", 18.6),
    "Hb 5": ("14596", 29.1),
    "HbDs 1": ("14575", 19.5),
    "He 2-11": ("14581", 29.6),
    "IC 1295": ("14585", 29.7),
    "IC 2149": ("14593", 28.7),
    "IC 4637": ("14586", 29.6),
    "IC 5148/50": ("14576", 19.7),
    "M 1-26": ("14584", 29.6),
    "M 1-41": ("14591", 29.6),
    "NGC 1501": ("14574", 19.7),
    "NGC 2899": ("14589", 29.6),
    "NGC 3918": ("14597", 30.0),
    "NGC 6026": ("14588", 29.6),
    "NGC 6072": ("14590", 29.6),
    "NGC 6153": ("14579", 28.6),
    "NGC 6337": ("14577", 19.7),
    "NGC 6369": ("14594", 29.6),
    "NGC 6894": ("14587", 29.2),
    "NGC 7076": ("14592", 29.6),
    "NGC 7354": ("14595", 29.6),
    "Sh 2-71": ("14582", 29.6),
    "Sp 1": ("14580", 29.4),
}


def parse_png(png: str) -> tuple[float, float]:
    match = re.fullmatch(r"(\d{3}\.\d)([+-])(\d{2}\.\d)", png)
    if not match:
        raise ValueError(f"Bad PNG: {png}")
    glon = float(match.group(1))
    glat = float(match.group(3)) * (1 if match.group(2) == "+" else -1)
    return glon, glat


def optical_tier(label: str) -> tuple[int, str]:
    if label.startswith("HST"):
        return 3, "HST narrow-band"
    if label.startswith(("WIYN", "Gemini", "INT")):
        return 2, "targeted ground narrow-band"
    if label.startswith(("SHS", "SSS")):
        return 1, "H-alpha survey"
    return 0, "DSS broadband"


def broad_f08(code: str) -> str:
    return "B" if code.startswith("B") else "R/E"


def broad_smv11(code: str) -> str:
    cleaned = code.strip("()")
    return "B/M" if cleaned.startswith(("B", "M", "L")) else "R/E/I"


def heasarc_nh(glon: float, glat: float) -> float:
    params = urllib.parse.urlencode(
        {
            "Entry": f"{glon:.4f} {glat:.4f}",
            "CoordSys": "Galactic",
            "equinox": "2000",
            "radius": "0.1",
            "usemap": "0",
        }
    )
    url = f"https://heasarc.gsfc.nasa.gov/cgi-bin/Tools/w3nh/w3nh.pl?{params}"
    request = urllib.request.Request(url, headers={"User-Agent": "thesis-control-sample/1.0"})
    with urllib.request.urlopen(request, timeout=45) as response:
        text = response.read().decode("utf-8", errors="replace")
    text = html.unescape(text)
    match = re.search(r"Weighted average nH \(cm\*\*-2\)\s+([0-9.]+E[+-][0-9]+)", text)
    if not match:
        raise RuntimeError(f"HEASARC nH result not found for l={glon}, b={glat}")
    return float(match.group(1))


def load_or_query_nh(df: pd.DataFrame) -> pd.DataFrame:
    cache_path = OUT / "hi4pi_nh_cache.csv"
    if cache_path.exists():
        cache = pd.read_csv(cache_path)
    else:
        cache = pd.read_csv(REPO / "reference/pn/chanplans/hi4pi_nh_cache.csv")
    cached = dict(zip(cache["png"], cache["nh_hi4pi_cm2"]))
    rows = []
    for _, row in df.iterrows():
        value = cached.get(row["png"])
        if pd.isna(value) or value is None:
            value = heasarc_nh(row["glon_deg"], row["glat_deg"])
            cached[row["png"]] = value
            time.sleep(0.15)
        rows.append(float(value))
    updated = pd.DataFrame(
        sorted(cached.items()), columns=["png", "nh_hi4pi_cm2"]
    )
    updated.to_csv(cache_path, index=False)
    df["nh_hi4pi_cm2"] = rows
    df["log10_nh_hi4pi"] = df["nh_hi4pi_cm2"].map(math.log10)
    return df


def add_hash_fields(df: pd.DataFrame) -> pd.DataFrame:
    hash_df = pd.read_csv(HASH_PATH, low_memory=False)
    hash_df["PNG"] = hash_df["PNG"].astype(str).str.replace("−", "-", regex=False)
    keep = hash_df[["PNG", "Name", "MajDiam", "MinDiam", "mainClass", "subClass", "logFlux"]]
    keep = keep.sort_values("PNG").drop_duplicates("PNG")
    keep = keep.rename(
        columns={
            "PNG": "png",
            "Name": "hash_name",
            "MajDiam": "hash_majdiam_arcsec",
            "MinDiam": "hash_mindiam_arcsec",
            "mainClass": "hash_mainclass",
            "subClass": "hash_subclass",
            "logFlux": "hash_log_halpha_flux",
        }
    )
    merged = df.merge(keep, how="left", on="png", validate="one_to_one")
    # The supplied HASH export labels NGC 1501 as PNG 144.1+06.1 even though
    # its listed Galactic coordinates are l=144.56045, b=+6.55102 and the
    # ChanPlaNS/standard identifier is 144.5+06.5. Recover this single row by
    # exact object name while preserving the identifier discrepancy for audit.
    by_name = keep.set_index("hash_name")
    missing = merged["hash_name"].isna() & merged["name"].isin(by_name.index)
    fill_columns = [column for column in keep.columns if column != "png"]
    for index in merged.index[missing]:
        matched_name = merged.at[index, "name"]
        source = by_name.loc[matched_name]
        for column in fill_columns:
            merged.at[index, column] = matched_name if column == "hash_name" else source[column]
    merged["hash_match_method"] = "PNG"
    merged.loc[missing, "hash_match_method"] = "exact name; HASH PNG discrepancy"
    merged.loc[merged["hash_name"].isna(), "hash_match_method"] = "not present"
    return merged


def main() -> None:
    df = pd.read_csv(StringIO(RAW), sep="|", dtype={"png": str})
    numeric = ["distance_kpc", "rneb_pc", "age_kyr"]
    for column in numeric:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    coords = df["png"].map(parse_png)
    df["glon_deg"] = coords.map(lambda pair: pair[0])
    df["glat_deg"] = coords.map(lambda pair: pair[1])
    df["obsids"] = df["name"].map(lambda name: EXPOSURES[name][0])
    df["exposure_ks"] = df["name"].map(lambda name: EXPOSURES[name][1])
    df["detected_any"] = (~df["xray_status"].eq("N")).astype(int)
    df["detected_point"] = df["xray_status"].str.contains("P", regex=False).astype(int)
    df["detected_diffuse"] = df["xray_status"].str.contains("D", regex=False).astype(int)
    df["tentative_point"] = df["xray_status"].eq("P?").astype(int)
    df["f08_broad"] = df["morph_f08"].map(broad_f08)
    df["smv11_broad"] = df["morph_smv11"].map(broad_smv11)
    df["morph_concordant"] = (
        (df["f08_broad"].eq("B") & df["smv11_broad"].eq("B/M"))
        | (df["f08_broad"].eq("R/E") & df["smv11_broad"].eq("R/E/I"))
    ).astype(int)
    optical = df["optical_image"].map(optical_tier)
    df["optical_tier"] = optical.map(lambda value: value[0])
    df["optical_tier_label"] = optical.map(lambda value: value[1])
    df["angular_radius_arcsec"] = 206.265 * df["rneb_pc"] / df["distance_kpc"]
    df["angular_diameter_arcsec"] = 2.0 * df["angular_radius_arcsec"]
    df["xray_psf_fwhm_arcsec"] = 0.5
    df["radius_to_psf"] = df["angular_radius_arcsec"] / df["xray_psf_fwhm_arcsec"]
    df["distance_exposure_proxy"] = df["distance_kpc"] ** 2 / df["exposure_ks"]
    df["instrument"] = "Chandra ACIS-S3"
    df["xray_image_band"] = "0.3-2.0 keV"
    df["published_limit_note"] = (
        "Survey-scale limits at 1.5 kpc: diffuse/hard-point about 1e30/1e29 erg s-1; "
        "soft-point about 1e31 erg s-1; no object-specific local upper limit in Papers I-II"
    )
    df = load_or_query_nh(df)
    df = add_hash_fields(df)
    df["source_object_table"] = df["phase"].map(
        lambda phase: "Kastner et al. 2012 Table 1"
        if phase in {"Cycle12", "Archive"}
        else "Freeman et al. 2014 Table 1"
    )
    df["source_exposure_table"] = df["phase"].map(
        lambda phase: "Kastner et al. 2012 Table 2"
        if phase in {"Cycle12", "Archive"}
        else "Freeman et al. 2014 Table 2"
    )
    df["source_optical_image"] = df["phase"].map(
        lambda phase: "Kastner et al. 2012 Figure 2"
        if phase in {"Cycle12", "Archive"}
        else "Freeman et al. 2014 Figure 1"
    )
    df["source_nh"] = "HEASARC nH tool, HI4PI 0.1-deg weighted mean"

    preferred = [
        "name", "png", "phase", "instrument", "obsids", "exposure_ks",
        "xray_status", "detected_any", "detected_point", "detected_diffuse",
        "tentative_point", "morph_f08", "f08_broad", "morph_smv11",
        "smv11_broad", "morph_concordant", "distance_kpc", "rneb_pc",
        "angular_radius_arcsec", "angular_diameter_arcsec", "xray_psf_fwhm_arcsec",
        "radius_to_psf", "nh_hi4pi_cm2", "log10_nh_hi4pi",
        "distance_exposure_proxy", "optical_image", "optical_tier",
        "optical_tier_label", "age_kyr", "h2", "glon_deg", "glat_deg",
        "hash_name", "hash_match_method", "hash_majdiam_arcsec", "hash_mindiam_arcsec",
        "hash_mainclass", "hash_subclass", "hash_log_halpha_flux",
        "source_object_table", "source_exposure_table", "source_optical_image",
        "source_nh", "published_limit_note", "xray_image_band",
    ]
    df = df[preferred]

    assert len(df) == 59
    assert int(df["detected_any"].sum()) == 32
    assert int(df["detected_point"].sum()) == 21
    assert int(df["detected_diffuse"].sum()) == 16
    assert int((df["xray_status"] == "N").sum()) == 27
    assert df["exposure_ks"].notna().all()
    assert df["nh_hi4pi_cm2"].notna().all()

    df.to_csv(OUT / "chanplans_observed_cohort_59.csv", index=False)
    summary = (
        df.groupby(["phase", "f08_broad"])[
            ["detected_any", "detected_point", "detected_diffuse"]
        ]
        .agg(["count", "sum"])
    )
    summary.to_csv(OUT / "cohort_validation_summary.csv")
    print(df[["phase", "xray_status"]].value_counts().sort_index())
    print("\nTotals:", df[["detected_any", "detected_point", "detected_diffuse"]].sum().to_dict())
    print("HASH matches:", int(df["hash_name"].notna().sum()), "/ 59")


if __name__ == "__main__":
    main()
