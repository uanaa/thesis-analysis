"""Fixed-target sensitivity checks; requires SciPy >= 1.15 and the HASH snapshot."""
from pathlib import Path
import ast,json,os,numpy as np,pandas as pd
from scipy.optimize import linear_sum_assignment
from scipy.stats import fisher_exact,MonteCarloMethod
REPO=Path(__file__).resolve().parents[1]
D=Path(os.environ.get('PN_DATA_DIR',REPO/'data/pn')).expanduser()
O=REPO/'outputs/pn/matching_sensitivity'
O.mkdir(parents=True,exist_ok=True)
tree=ast.parse((REPO/'pn/matched_morphology.py').read_text()); ns=globals();exec(compile(ast.Module([n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.Import,ast.ImportFrom))],type_ignores=[]),'<functions>','exec'),ns)
p=pd.read_csv(D/'TruePNe.csv',low_memory=False);x=pd.read_csv(REPO/'reference/pn/xpn_morphology_41.csv');p['PNG_norm']=norm_png(p.PNG);x['PNG_norm']=norm_png(x.PNG);p=p.sort_values(['PNG_norm','idPNMain']).drop_duplicates('PNG_norm');x=x.merge(p[['PNG_norm','logFlux']],on='PNG_norm',how='left',validate='one_to_one');p=p[~p.PNG_norm.isin(x.PNG_norm)]
x=x[x.MajDiam.gt(0)&x.mainClass.notna()].copy().reset_index(drop=True);p=p[p.MajDiam.gt(0)&p.mainClass.notna()].copy()
for t in [x,p]:t['logMajDiam']=np.log10(t.MajDiam);t['absGlat']=t.Glat.abs()
fp=p[p.logFlux.notna()].copy();fx=x[x.logFlux.notna()].copy().reset_index(drop=True)
_,sub,orig=caliper_match_unique(fx,fp,['logMajDiam','absGlat','logFlux'],[.25,12,.5]);sub=sub.drop(columns=['match_set']).reset_index(drop=True)
classes=['E','B','R','S','I','A']; results=[]; selections={}
def result(name,t,c,resamples=200000,seed=20261030):
 tc=t.mainClass.value_counts().reindex(classes,fill_value=0);cc=c.mainClass.value_counts().reindex(classes,fill_value=0);tab=np.array([cc,tc]);tab=tab[:,tab.sum(0)>0]
 pp=fisher_exact(tab,method=MonteCarloMethod(n_resamples=resamples,rng=np.random.default_rng(seed))).pvalue
 m=pd.concat([t.assign(group=1),c.assign(group=0)]); each=[dict(cls=cl,**two_by_two(m.group,m.mainClass.eq(cl))) for cl in classes];adj=bh_adjust(pd.Series([a['fisher_p'] for a in each]));[a.update(fdr_p=float(q)) for a,q in zip(each,adj)]
 return dict(name=name,xpn=len(t),controls=len(c),overall_p=float(pp),xpn_counts=tc.tolist(),control_counts=cc.tolist(),class_tests=each)
for ratio in [1,2]:
 _,c=match_unique(x,p,['logMajDiam','absGlat'],ratio=ratio,weights=[1.5,1]);name=f'all41_two_covariates_1to{ratio}';results.append(result(name,x,c,seed=20260820 if ratio==2 else 20261030));selections[name]=c.PNG_norm.tolist()
for ratio in [1,2]:
 _,c=match_unique(sub,fp,['logMajDiam','absGlat'],ratio=ratio,weights=[1.5,1]);name=f'same31_flux_available_pool_two_covariates_1to{ratio}';results.append(result(name,sub,c));selections[name]=c.PNG_norm.tolist()
def calibrated(t,cp,cols,lim,ratio=1,rng=None):
 delta=np.abs(t[cols].to_numpy()[:,None,:]-cp[cols].to_numpy()[None,:,:])/lim;ok=(delta<=1).all(2);cost=delta.sum(2);slots=np.repeat(np.arange(len(t)),ratio);cost=cost[slots];ok=ok[slots]
 if rng is not None:cost=cost+rng.uniform(0,.25,size=cost.shape)
 r,c=linear_sum_assignment(np.where(ok,cost,1e8));keep=ok[r,c]
 return cp.iloc[c[keep]],np.unique(slots[r[keep]]),int(keep.sum())
for cols,lim,label in [(['logMajDiam','absGlat'],np.array([.25,12]),'two'),(['logMajDiam','absGlat','logFlux'],np.array([.25,12,.5]),'three')]:
 for ratio in [1,2]:
  c,ids,nn=calibrated(sub,fp,cols,lim,ratio)
  if nn!=len(sub)*ratio:print('incomplete',label,ratio,nn,flush=True);continue
  name=f'same31_{label}_calipers_1to{ratio}';results.append(result(name,sub,c,seed=20260821 if label=='three' and ratio==1 else 20261030));selections[name]=c.PNG_norm.tolist()
# Perturb cost only inside existing calipers; retain every target, each control unique.
rng=np.random.default_rng(20261030);rep=[]
for k in range(100):
 c,ids,nn=calibrated(sub,fp,['logMajDiam','absGlat','logFlux'],np.array([.25,12,.5]),1,rng)
 assert nn==31
 r=result(str(k),sub,c,10000,20261030+k);rep.append(dict(trial=k,overall_p=r['overall_p'],bipolar_controls=int((c.mainClass=='B').sum()),round_controls=int((c.mainClass=='R').sum()),bipolar_or=r['class_tests'][1]['odds_ratio_corrected'],round_or=r['class_tests'][2]['odds_ratio_corrected'],control_png=c.PNG_norm.tolist()))
summary={'classes':classes,'results':results,'alternative_matches':{'method':'100 independent additions Uniform(0,0.25) to the sum of scaled absolute distances, within original three calipers; 31 fixed targets, same control pool, 1:1 without replacement. Descriptive sensitivity, not a sampling distribution.','p_min_median_max':np.quantile([r['overall_p'] for r in rep],[0,.5,1]).tolist(),'unique_control_sets':len({tuple(sorted(r['control_png'])) for r in rep}),'replicates':rep},'selections':selections,'target31_png':sub.PNG_norm.tolist()}
(O/'matching_sensitivity.json').write_text(json.dumps(summary,indent=2));sub.to_csv(O/'matched_same31_targets.csv',index=False)
for r in results:print(r['name'],r['xpn'],r['controls'],r['overall_p'],r['control_counts'],flush=True)
print('alternative',summary['alternative_matches']['p_min_median_max'],summary['alternative_matches']['unique_control_sets'],flush=True)
