from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from scipy.stats import MonteCarloMethod, chi2_contingency, fisher_exact


REPO = Path(__file__).resolve().parents[1]
DATA = Path(os.environ.get("PN_DATA_DIR", REPO / "data/pn")).expanduser()
OUT = REPO / "outputs/pn/matched"
OUT.mkdir(parents=True, exist_ok=True)


def norm_png(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.replace("PN G", "", regex=False)


def parse_features(s: object) -> set[str]:
    if pd.isna(s):
        return set()
    return {x.strip().lower() for x in str(s).split(";") if x.strip()}


def standardized_mean_difference(a: pd.Series, b: pd.Series) -> float:
    va, vb = a.var(ddof=1), b.var(ddof=1)
    pooled = np.sqrt((va + vb) / 2)
    return float((a.mean() - b.mean()) / pooled) if pooled > 0 else 0.0


def match_unique(
    treated: pd.DataFrame,
    controls: pd.DataFrame,
    covariates: list[str],
    ratio: int = 3,
    weights: list[float] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Globally optimal 1:ratio matching without replacement.

    Distance is standardized Euclidean distance. Each treated row is repeated
    `ratio` times and assigned a unique control through the Hungarian algorithm.
    """
    combined = pd.concat([treated[covariates], controls[covariates]], ignore_index=True)
    weights_array = np.asarray(weights if weights is not None else [1.0] * len(covariates))
    means = combined.mean()
    sds = combined.std(ddof=1).replace(0, 1)
    tz = (treated[covariates] - means) / sds
    cz = (controls[covariates] - means) / sds
    slots = np.repeat(np.arange(len(treated)), ratio)
    costs = np.empty((len(slots), len(controls)))
    for i, ti in enumerate(slots):
        delta = cz.to_numpy() - tz.iloc[ti].to_numpy()
        costs[i, :] = np.sqrt(np.sum((delta * weights_array) ** 2, axis=1))
    rows, cols = linear_sum_assignment(costs)
    pairs = pd.DataFrame(
        {
            "match_set": slots[rows] + 1,
            "xpn_index": treated.index.to_numpy()[slots[rows]],
            "control_index": controls.index.to_numpy()[cols],
            "distance": costs[rows, cols],
        }
    ).sort_values(["match_set", "distance"])
    chosen = controls.loc[pairs["control_index"]].copy()
    chosen["match_set"] = pairs["match_set"].to_numpy()
    chosen["match_distance"] = pairs["distance"].to_numpy()
    return pairs, chosen


def caliper_match_unique(
    treated: pd.DataFrame,
    controls: pd.DataFrame,
    covariates: list[str],
    calipers: list[float],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Maximum-cardinality-like 1:1 assignment under fixed raw-scale calipers."""
    t = treated[covariates].to_numpy(float)
    c = controls[covariates].to_numpy(float)
    limits = np.asarray(calipers, dtype=float)
    scaled = np.abs(t[:, None, :] - c[None, :, :]) / limits
    eligible = np.all(scaled <= 1, axis=2)
    costs = scaled.sum(axis=2) + (~eligible) * 1e6
    rows, cols = linear_sum_assignment(costs)
    ok = eligible[rows, cols]
    rows, cols = rows[ok], cols[ok]
    pairs = pd.DataFrame(
        {
            "match_set": np.arange(1, len(rows) + 1),
            "xpn_index": treated.index.to_numpy()[rows],
            "control_index": controls.index.to_numpy()[cols],
            "distance": costs[rows, cols],
        }
    )
    kept_treated = treated.iloc[rows].copy()
    kept_controls = controls.iloc[cols].copy()
    kept_treated["match_set"] = np.arange(1, len(rows) + 1)
    kept_controls["match_set"] = np.arange(1, len(rows) + 1)
    kept_controls["match_distance"] = costs[rows, cols]
    return pairs, kept_treated, kept_controls


def two_by_two(group: pd.Series, outcome: pd.Series) -> dict[str, float | int]:
    tab = pd.crosstab(group, outcome).reindex(index=[0, 1], columns=[False, True], fill_value=0)
    # rows: controls, XPN; cols: absent, present
    odds, p = fisher_exact(tab.to_numpy(), alternative="two-sided")
    a, b = float(tab.loc[1, True]), float(tab.loc[1, False])
    c, d = float(tab.loc[0, True]), float(tab.loc[0, False])
    # Haldane-Anscombe correction supports finite OR/CI with zero cells.
    aa, bb, cc, dd = a + 0.5, b + 0.5, c + 0.5, d + 0.5
    log_or = np.log((aa * dd) / (bb * cc))
    se = np.sqrt(1 / aa + 1 / bb + 1 / cc + 1 / dd)
    return {
        "xpn_present": int(a),
        "xpn_total": int(a + b),
        "control_present": int(c),
        "control_total": int(c + d),
        "odds_ratio_raw": float(odds),
        "odds_ratio_corrected": float(np.exp(log_or)),
        "ci95_low": float(np.exp(log_or - 1.96 * se)),
        "ci95_high": float(np.exp(log_or + 1.96 * se)),
        "fisher_p": float(p),
    }


def bh_adjust(pvalues: pd.Series) -> np.ndarray:
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = ranked * len(p) / np.arange(1, len(p) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    out = np.empty_like(adjusted)
    out[order] = np.clip(adjusted, 0, 1)
    return out


parent = pd.read_csv(DATA / "TruePNe.csv", low_memory=False)
source_parent_rows = len(parent)
xpn = pd.read_csv(REPO / "reference/pn/xpn_morphology_41.csv", low_memory=False)
parent["PNG_norm"] = norm_png(parent["PNG"])
xpn["PNG_norm"] = norm_png(xpn["PNG"])

# Resolve duplicated HASH rows deterministically: retain first exact PNG record.
parent = parent.sort_values(["PNG_norm", "idPNMain"]).drop_duplicates("PNG_norm", keep="first").copy()
xpn_pngs = set(xpn["PNG_norm"])
joined = xpn.merge(
    parent[["PNG_norm", "idPNMain", "logFlux", "Catalogue"]],
    on="PNG_norm",
    how="left",
    validate="one_to_one",
)

analysis_xpn = joined[
    joined["MajDiam"].notna()
    & joined["MajDiam"].gt(0)
    & joined["mainClass"].notna()
].copy()
analysis_xpn["logMajDiam"] = np.log10(analysis_xpn["MajDiam"].astype(float))
analysis_xpn["absGlat"] = analysis_xpn["Glat"].abs()

pool = parent[
    ~parent["PNG_norm"].isin(xpn_pngs)
    & parent["MajDiam"].notna()
    & parent["MajDiam"].gt(0)
    & parent["mainClass"].notna()
].copy()
pool["logMajDiam"] = np.log10(pool["MajDiam"].astype(float))
pool["absGlat"] = pool["Glat"].abs()

pairs, controls = match_unique(
    analysis_xpn.reset_index(drop=True),
    pool,
    ["logMajDiam", "absGlat"],
    ratio=2,
    weights=[1.5, 1.0],
)
treated = analysis_xpn.reset_index(drop=True).copy()
treated["match_set"] = np.arange(1, len(treated) + 1)
treated["group"] = 1
controls["group"] = 0
matched = pd.concat([treated, controls], ignore_index=True, sort=False)

# Main morphology: matched overall chi-square plus category-wise Fisher tests.
main_classes = ["E", "B", "R", "S", "I", "A"]
main_table = pd.crosstab(matched["group"], matched["mainClass"]).reindex(
    index=[0, 1], columns=main_classes, fill_value=0
)
active_main_table = main_table.loc[:, main_table.sum(axis=0).gt(0)]
chi2, chi_p, chi_dof, expected = chi2_contingency(active_main_table.to_numpy())
overall_fisher = fisher_exact(
    active_main_table.to_numpy(),
    method=MonteCarloMethod(n_resamples=200_000, rng=np.random.default_rng(20260820)),
)
main_rows = []
for cls in main_classes:
    row = {"feature": cls, **two_by_two(matched["group"], matched["mainClass"].eq(cls))}
    main_rows.append(row)
main_results = pd.DataFrame(main_rows)
main_results["fdr_p"] = bh_adjust(main_results["fisher_p"])

# Secondary features: rematch within the subset with secondary annotations.
# This avoids comparing 38 XPN records against an opportunistic subset of the
# main-morphology controls whose secondary classifications happen to be present.
secondary_xpn = analysis_xpn[analysis_xpn["subClass"].notna()].copy().reset_index(drop=True)
secondary_pool = pool[pool["subClass"].notna()].copy()
_, secondary_controls = match_unique(
    secondary_xpn,
    secondary_pool,
    ["logMajDiam", "absGlat"],
    ratio=2,
    weights=[1.5, 1.0],
)
secondary_xpn["group"] = 1
secondary_controls["group"] = 0
secondary = pd.concat([secondary_xpn, secondary_controls], ignore_index=True, sort=False)
features = ["a", "m", "p", "r", "s"]
feature_sets = secondary["subClass"].map(parse_features)
secondary_rows = []
for feat in features:
    row = {"feature": feat, **two_by_two(secondary["group"], feature_sets.map(lambda s: feat in s))}
    secondary_rows.append(row)
secondary_results = pd.DataFrame(secondary_rows)
secondary_results["fdr_p"] = bh_adjust(secondary_results["fisher_p"])

# Sensitivity analysis: add H-alpha log flux, where available in both groups.
flux_xpn = analysis_xpn[analysis_xpn["logFlux"].notna()].copy().reset_index(drop=True)
flux_pool = pool[pool["logFlux"].notna()].copy()
if len(flux_xpn) >= 10:
    _, flux_xpn_kept, flux_controls = caliper_match_unique(
        flux_xpn,
        flux_pool,
        ["logMajDiam", "absGlat", "logFlux"],
        calipers=[0.25, 12.0, 0.5],
    )
    flux_xpn_kept["group"] = 1
    flux_controls["group"] = 0
    flux_matched = pd.concat([flux_xpn_kept, flux_controls], ignore_index=True, sort=False)
    flux_rows = []
    for cls in main_classes:
        flux_rows.append(
            {"feature": cls, **two_by_two(flux_matched["group"], flux_matched["mainClass"].eq(cls))}
        )
    flux_results = pd.DataFrame(flux_rows)
    flux_results["fdr_p"] = bh_adjust(flux_results["fisher_p"])
    flux_table = pd.crosstab(flux_matched["group"], flux_matched["mainClass"]).reindex(
        index=[0, 1], columns=main_classes, fill_value=0
    )
    flux_active_table = flux_table.loc[:, flux_table.sum(axis=0).gt(0)]
    flux_overall_fisher = fisher_exact(
        flux_active_table.to_numpy(),
        method=MonteCarloMethod(n_resamples=200_000, rng=np.random.default_rng(20260821)),
    )
else:
    flux_matched = pd.DataFrame()
    flux_results = pd.DataFrame()
    flux_table = pd.DataFrame()
    flux_overall_fisher = None

balance = []
for cov in ["logMajDiam", "absGlat"]:
    balance.append(
        {
            "covariate": cov,
            "xpn_mean": treated[cov].mean(),
            "full_pool_mean": pool[cov].mean(),
            "matched_control_mean": controls[cov].mean(),
            "smd_before": standardized_mean_difference(treated[cov], pool[cov]),
            "smd_after": standardized_mean_difference(treated[cov], controls[cov]),
        }
    )
balance = pd.DataFrame(balance)

secondary_balance = []
for cov in ["logMajDiam", "absGlat"]:
    secondary_balance.append(
        {
            "covariate": cov,
            "xpn_mean": secondary_xpn[cov].mean(),
            "matched_control_mean": secondary_controls[cov].mean(),
            "smd_after": standardized_mean_difference(secondary_xpn[cov], secondary_controls[cov]),
        }
    )
secondary_balance = pd.DataFrame(secondary_balance)

flux_balance = []
if not flux_matched.empty:
    for cov in ["logMajDiam", "absGlat", "logFlux"]:
        flux_balance.append(
            {
                "covariate": cov,
                "xpn_mean": flux_xpn_kept[cov].mean(),
                "matched_control_mean": flux_controls[cov].mean(),
                "smd_after": standardized_mean_difference(flux_xpn_kept[cov], flux_controls[cov]),
            }
        )
flux_balance = pd.DataFrame(flux_balance)

matched_export_cols = [
    "group", "match_set", "Name", "PNG", "idPNMain", "Glon", "Glat", "MajDiam",
    "logFlux", "mainClass", "subClass", "Catalogue", "match_distance",
]
for c in matched_export_cols:
    if c not in matched.columns:
        matched[c] = np.nan
matched[matched_export_cols].to_csv(OUT / "matched_sample.csv", index=False)
main_table.to_csv(OUT / "main_morphology_contingency.csv")
main_results.to_csv(OUT / "main_morphology_tests.csv", index=False)
secondary_results.to_csv(OUT / "secondary_feature_tests.csv", index=False)
balance.to_csv(OUT / "balance.csv", index=False)
secondary_balance.to_csv(OUT / "secondary_balance.csv", index=False)
if not flux_results.empty:
    flux_results.to_csv(OUT / "flux_sensitivity_tests.csv", index=False)
    flux_matched[matched_export_cols].to_csv(OUT / "flux_matched_sample.csv", index=False)
    flux_table.to_csv(OUT / "flux_main_morphology_contingency.csv")
    flux_balance.to_csv(OUT / "flux_balance.csv", index=False)

summary = {
    "source_parent_rows": int(source_parent_rows),
    "deduplicated_parent_rows": int(len(parent)),
    "xpn_total": int(len(xpn)),
    "xpn_matched_to_hash": int(joined["idPNMain"].notna().sum()),
    "primary_analysis_xpn": int(len(treated)),
    "primary_analysis_controls": int(len(controls)),
    "overall_chi_square": float(chi2),
    "overall_chi_square_p": float(chi_p),
    "overall_chi_square_dof": int(chi_dof),
    "minimum_expected_count": float(expected.min()),
    "overall_fisher_freeman_halton_p": float(overall_fisher.pvalue),
    "secondary_xpn_n": int((secondary["group"] == 1).sum()),
    "secondary_control_n": int((secondary["group"] == 0).sum()),
    "flux_sensitivity_xpn_n": int(len(flux_xpn_kept)) if len(flux_matched) else 0,
    "flux_sensitivity_control_n": int(len(flux_controls)) if len(flux_matched) else 0,
    "flux_sensitivity_excluded_xpn": sorted(set(flux_xpn["Name"]) - set(flux_xpn_kept["Name"])) if len(flux_matched) else [],
    "flux_overall_fisher_freeman_halton_p": float(flux_overall_fisher.pvalue) if flux_overall_fisher else None,
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2))

def records(df: pd.DataFrame) -> list[dict]:
    return json.loads(df.replace({np.nan: None, np.inf: None, -np.inf: None}).to_json(orient="records"))

workbook_payload = {
    "summary": summary,
    "balance": records(balance),
    "secondary_balance": records(secondary_balance),
    "main_contingency": records(main_table.reset_index()),
    "main_tests": records(main_results),
    "secondary_tests": records(secondary_results),
    "flux_contingency": records(flux_table.reset_index()) if not flux_table.empty else [],
    "flux_tests": records(flux_results),
    "flux_balance": records(flux_balance),
    "matched_sample": records(matched[matched_export_cols]),
    "flux_matched_sample": records(flux_matched[matched_export_cols]) if not flux_matched.empty else [],
    "raw_xpn": records(xpn),
}
(OUT / "workbook_data.json").write_text(json.dumps(workbook_payload))

print(json.dumps(summary, indent=2))
print("\nBALANCE\n", balance.to_string(index=False))
print("\nMAIN TABLE\n", main_table.to_string())
print("\nMAIN TESTS\n", main_results.to_string(index=False))
print("\nSECONDARY TESTS\n", secondary_results.to_string(index=False))
print("\nSECONDARY BALANCE\n", secondary_balance.to_string(index=False))
print("\nFLUX SENSITIVITY\n", flux_results.to_string(index=False))
print("\nFLUX BALANCE\n", flux_balance.to_string(index=False))
