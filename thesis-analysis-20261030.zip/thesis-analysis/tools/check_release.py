"""Check source syntax, packaged paths and selected numerical reference values.

Uses only the Python standard library. Mission-level data reduction is separate.
"""
from pathlib import Path
import ast
import csv
from collections import Counter
import hashlib
import json
import math
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def check():
    files = [p for p in ROOT.rglob('*') if p.is_file() and not any(
        part in {'.git', '.venv', '__pycache__', 'data', 'outputs'} for part in p.relative_to(ROOT).parts)]
    python_files = [p for p in files if p.suffix == '.py']
    shell_files = [p for p in files if p.suffix == '.sh']
    for p in python_files:
        ast.parse(p.read_text(), filename=str(p))
    for p in shell_files:
        subprocess.run(['bash', '-n', str(p)], check=True, capture_output=True)
    # Detect accidental workstation paths or recognizable credential formats.
    patterns = [r'/' + r'Users/[^/\s]+/', r'/' + r'home/(?!your-user\b)[^/\s]+/',
                r'gh[pousr]_[A-Za-z0-9]{20,}', r'github_pat_[A-Za-z0-9_]{20,}',
                r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
    for p in files:
        text = p.read_text(errors='replace')
        for pattern in patterns:
            if re.search(pattern, text):
                raise AssertionError(f'Publication check: inspect {p.relative_to(ROOT)}')
    manifest = json.loads((ROOT / 'docs/source_manifest.json').read_text())
    for row in manifest:
        p = ROOT / row['file']
        assert hashlib.sha256(p.read_bytes()).hexdigest() == row['released_sha256'], row['file']
    stats = json.loads((ROOT / 'reference/le01/unified_crab_statistics.json').read_text())
    for label, expected_on, expected_off, expected_sigma in [('old', 827, 6544, 7.43), ('new', 844, 7825, 3.42)]:
        row = stats['main'][label]
        assert (row['non'], row['noff']) == (expected_on, expected_off)
        alpha = row['alpha_exposure']
        total = expected_on + expected_off
        ll = expected_on * math.log((1 + alpha) * expected_on / (alpha * total))
        ll += expected_off * math.log((1 + alpha) * expected_off / total)
        sigma = math.copysign(math.sqrt(2 * ll), expected_on - alpha * expected_off)
        assert math.isclose(sigma, row['li_ma_sigma'], abs_tol=1e-9)
        assert round(sigma, 2) == expected_sigma
    with (ROOT / 'Chapter5_4XMM_reviewed_pairs_73_20261030.csv').open() as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 73
    assert len({r['SRCID'] for r in rows}) == 73
    assert len({r['HASH_id'] for r in rows}) == 67
    selected = [r for r in rows if r['soft_selected'] == 'True']
    assert len(selected) == 30
    assert Counter(r['review_class_20261030'] for r in selected) == {'K': 12, 'C': 4, 'S': 5, 'U': 9}
    fit = json.loads((ROOT / 'reference/ic1297/ic1297_sherpa_check.json').read_text())['fits'][0]
    assert fit['flux_bounds'][0] < fit['flux'] < fit['flux_bounds'][1]
    assert math.isclose(fit['statistic'], 22.4951545, abs_tol=1e-5)
    print(f'Passed: {len(python_files)} Python sources, {len(shell_files)} shell sources, '
          f'{len(manifest)} provenance hashes, and paired Crab reference calculations.')


if __name__ == '__main__':
    check()
