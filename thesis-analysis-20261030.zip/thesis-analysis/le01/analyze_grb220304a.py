#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.patches import Circle, Rectangle
import numpy as np
from astropy.io import fits
from scipy.optimize import brentq
from scipy.stats import norm


TARGET_RA = 245.0
TARGET_DEC = -35.7
VALID_GRADES = np.array([0, 2, 3, 4, 6])
COORD_BASE = 2048
BOX_HALF = 5.0
RIN = 8.0
ROUT = 20.0
ALPHA = 100.0 / (math.pi * (ROUT**2 - RIN**2))


def tangent_offsets(ra, dec, ref_ra=TARGET_RA, ref_dec=TARGET_DEC):
    dra = (np.asarray(ra) - ref_ra + 180.0) % 360.0 - 180.0
    return dra * math.cos(math.radians(ref_dec)) * 60.0, (np.asarray(dec) - ref_dec) * 60.0


def counts(dx, dy, cx=0.0, cy=0.0):
    x = dx - cx
    y = dy - cy
    r = np.hypot(x, y)
    non = int(np.sum((np.abs(x) < BOX_HALF) & (np.abs(y) < BOX_HALF)))
    noff = int(np.sum((r >= RIN) & (r < ROUT)))
    return non, noff


def li_ma(non, noff, alpha=ALPHA):
    if non + noff == 0:
        return 0.0
    net = non - alpha * noff
    term_on = 0 if non == 0 else non * math.log(((1 + alpha) / alpha) * non / (non + noff))
    term_off = 0 if noff == 0 else noff * math.log((1 + alpha) * noff / (non + noff))
    return math.copysign(math.sqrt(max(0.0, 2 * (term_on + term_off))), net)


def profile_loglike(non, noff, alpha, signal):
    tau = 1.0 / alpha
    coefficient = 1.0 + tau
    linear = coefficient * signal - non - noff
    background = (-linear + math.sqrt(linear * linear + 4 * coefficient * noff * signal)) / (2 * coefficient)
    on_mean = signal + background
    off_mean = tau * background
    value = 0.0
    if non:
        value += non * math.log(on_mean)
    value -= on_mean
    if noff:
        value += noff * math.log(off_mean)
    value -= off_mean
    return value, background


def profile_upper_limit(non, noff, alpha=ALPHA, confidence=0.997):
    signal_hat = max(0.0, non - alpha * noff)
    ll_hat, b_hat = profile_loglike(non, noff, alpha, signal_hat)
    target_q = norm.ppf(confidence) ** 2

    def objective(signal):
        ll, _ = profile_loglike(non, noff, alpha, signal)
        return -2 * (ll - ll_hat) - target_q

    upper = max(10.0, signal_hat + 10 * math.sqrt(max(non + alpha**2 * noff, 1)))
    while objective(upper) < 0:
        upper *= 2
    limit = brentq(objective, signal_hat + 1e-10, upper)
    return {
        "signal_mle_counts": signal_hat,
        "background_mle_on_counts": b_hat,
        "confidence": confidence,
        "profile_q": target_q,
        "signal_upper_counts": limit,
    }


def read_catalogue(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return {
            int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            for row in csv.DictReader(stream)
        }


def method_summary(dx, dy, exposure):
    non, noff = counts(dx, dy)
    net = non - ALPHA * noff
    uncertainty = math.sqrt(non + ALPHA**2 * noff)
    upper = profile_upper_limit(non, noff)
    controls = []
    for radius in (25.0, 35.0, 45.0):
        for angle_deg in range(0, 360, 30):
            angle = math.radians(angle_deg)
            cx, cy = radius * math.cos(angle), radius * math.sin(angle)
            control_non, control_noff = counts(dx, dy, cx, cy)
            controls.append(control_non - ALPHA * control_noff)
    controls = np.asarray(controls)
    return {
        "selected_events": int(len(dx)),
        "non": non,
        "noff": noff,
        "alpha": ALPHA,
        "net_counts": net,
        "net_uncertainty": uncertainty,
        "gaussian_ratio": net / uncertainty,
        "li_ma_sigma": li_ma(non, noff),
        **upper,
        "upper_count_rate_per_s": upper["signal_upper_counts"] / exposure,
        "matched_control_net_mean": float(np.mean(controls)),
        "matched_control_net_std": float(np.std(controls, ddof=1)),
        "matched_control_net_quantiles": [float(x) for x in np.quantile(controls, [0.025, 0.5, 0.975])],
        "matched_control_empirical_p_ge_target": float((1 + np.sum(controls >= net)) / (len(controls) + 1)),
        "control_apertures": int(len(controls)),
        "controls": controls,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fits", type=Path, required=True)
    parser.add_argument("--obs-info", type=Path, required=True)
    parser.add_argument("--catalogue", type=Path, required=True)
    parser.add_argument("--hotpixel-code-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(args.hotpixel_code_dir))
    from robust_hot_pixel_filter import DetectionConfig, detect_hot_pixels

    with fits.open(args.fits, memmap=False) as hdul:
        data = hdul[1].data
        header = hdul[1].header
        exposure = float(header.get("EXPOSURE", hdul[0].header.get("EXPOSURE", 706.0)))
        science = (
            np.isfinite(data["energy"])
            & (data["energy"] > 1.0)
            & (data["energy"] < 10.0)
            & np.isin(data["grade"], VALID_GRADES)
            & np.isfinite(data["ra"])
            & np.isfinite(data["dec"])
        )
        candidates, diagnostics = detect_hot_pixels(data, header, DetectionConfig())
        catalogue = read_catalogue(args.catalogue)
        final_codes = {
            int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            for row in candidates
            if int(row["chipx"]) * COORD_BASE + int(row["chipy"]) in catalogue
        }
        codes = np.asarray(data["chipx"], np.int64) * COORD_BASE + np.asarray(data["chipy"], np.int64)
        remove = np.isin(codes, np.fromiter(final_codes, dtype=np.int64)) if final_codes else np.zeros(len(data), bool)
        ra = np.asarray(data["ra"], float)
        dec = np.asarray(data["dec"], float)
        energy = np.asarray(data["energy"], float)

    with args.obs_info.open(newline="", encoding="utf-8") as stream:
        info = list(csv.DictReader(stream))
    pnt_ra = float(np.median([float(row["Ra(deg)"]) for row in info]))
    pnt_dec = float(np.median([float(row["Dec(deg)"]) for row in info]))
    pointing_offset = float(math.hypot((TARGET_RA - pnt_ra) * math.cos(math.radians(TARGET_DEC)) * 60, (TARGET_DEC - pnt_dec) * 60))

    selections = {"grade_energy": science, "replacement_screen": science & ~remove}
    result = {
        "configuration": {
            "obsid": "100968",
            "target_ra_deg": TARGET_RA,
            "target_dec_deg": TARGET_DEC,
            "median_pointing_ra_deg": pnt_ra,
            "median_pointing_dec_deg": pnt_dec,
            "target_pointing_offset_arcmin": pointing_offset,
            "exposure_s": exposure,
            "energy_keV": "1 < E < 10",
            "grades": VALID_GRADES.tolist(),
            "source_region": "10 x 10 arcmin square",
            "background_region": "8-20 arcmin annulus",
        },
        "hotpixel": {
            **diagnostics,
            "persistent_catalogue_candidates": len(final_codes),
            "all_events_removed": int(np.sum(remove)),
            "science_events_removed": int(np.sum(science & remove)),
        },
        "methods": {},
    }
    cached = {}
    for name, selection in selections.items():
        dx, dy = tangent_offsets(ra[selection], dec[selection])
        summary = method_summary(dx, dy, exposure)
        controls = summary.pop("controls")
        result["methods"][name] = summary
        cached[name] = (dx, dy, energy[selection], controls)

    (args.output_dir / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

    dx, dy, selected_energy, controls = cached["replacement_screen"]
    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.8), constrained_layout=True)
    bins = np.linspace(-65, 65, 131)
    hist, xe, ye = np.histogram2d(dx, dy, bins=[bins, bins])
    positive = hist[hist > 0]
    vmax = max(2.0, float(np.quantile(positive, 0.995))) if len(positive) else 2.0
    axes[0].pcolormesh(xe, ye, hist.T, cmap="magma", norm=LogNorm(vmin=1, vmax=vmax), shading="auto")
    axes[0].add_patch(Rectangle((-5, -5), 10, 10, fill=False, edgecolor="#62a0ea", linewidth=1.5))
    axes[0].add_patch(Circle((0, 0), RIN, fill=False, edgecolor="#33d17a", linewidth=1.0, linestyle="--"))
    axes[0].add_patch(Circle((0, 0), ROUT, fill=False, edgecolor="#33d17a", linewidth=1.0, linestyle="--"))
    axes[0].plot(0, 0, marker="+", color="white", markersize=8)
    axes[0].set(xlim=(-65, 65), ylim=(-65, 65), aspect="equal", xlabel=r"$\Delta$RA $\cos(\mathrm{Dec})$ (arcmin)", ylabel=r"$\Delta$Dec (arcmin)", title="(a) GRB 220304A field")
    axes[0].invert_xaxis()

    target_net = result["methods"]["replacement_screen"]["net_counts"]
    axes[1].hist(controls, bins=14, color="#98a2b3", edgecolor="white")
    axes[1].axvline(target_net, color="#d92d20", linestyle="--", linewidth=1.6, label="target")
    axes[1].set(xlabel="Control-aperture net counts", ylabel="Control apertures", title="(b) Matched spatial controls")
    axes[1].legend(fontsize=8)

    source = (np.abs(dx) < BOX_HALF) & (np.abs(dy) < BOX_HALF)
    radius = np.hypot(dx, dy)
    background = (radius >= RIN) & (radius < ROUT)
    energy_bins = np.linspace(1, 10, 28)
    axes[2].hist(selected_energy[source], bins=energy_bins, histtype="step", linewidth=1.6, label=f"source box (n={source.sum()})")
    axes[2].hist(selected_energy[background], bins=energy_bins, weights=np.full(background.sum(), ALPHA), histtype="step", linewidth=1.6, label="area-scaled annulus")
    axes[2].set(xlabel="Energy (project keV scale)", ylabel="Events per bin", title="(c) Event-energy comparison")
    axes[2].legend(fontsize=8)
    for ax in axes:
        ax.tick_params(direction="in", top=True, right=True, labelsize=8)
    fig.suptitle("ObsID 100968: reproducible GRB 220304A non-detection analysis", fontsize=11)
    fig.savefig(args.output_dir / "grb220304a_validation.pdf")
    plt.close(fig)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
