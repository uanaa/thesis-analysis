from pathlib import Path
from paths import DATA_ROOT as ROOT, OUTPUT as OUT
import pickle,json,sys,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm,Normalize
from matplotlib.patches import Circle,Rectangle
import figure_2_13_empirical_likelihood as oldmap
data=pickle.loads((OUT/'common_crab_data.pkl').read_bytes()); summary=json.loads((OUT/'unified_crab_statistics.json').read_text())
plt.rcParams.update({'font.size':13,'axes.titlesize':14,'axes.labelsize':12,'xtick.labelsize':11,'ytick.labelsize':11,'legend.fontsize':11,'pdf.fonttype':42})
fig=plt.figure(figsize=(10.8,9.0),constrained_layout=True)
gs=fig.add_gridspec(2,2,height_ratios=[1.3,.85])
axs=[fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[1,:])]
common_max=max(np.histogram2d(np.concatenate([o['dx'][o[m]] for o in data]),np.concatenate([o['dy'][o[m]] for o in data]),bins=120,range=[[-30,30],[-30,30]])[0].max() for m in ['old','new'])
for method,label,ax,letter in [('old','Old screen',axs[0],'a'),('new','New screen',axs[1],'b')]:
    dx=np.concatenate([o['dx'][o[method]] for o in data]);dy=np.concatenate([o['dy'][o[method]] for o in data])
    im=ax.hist2d(dx,dy,bins=120,range=[[-30,30],[-30,30]],norm=LogNorm(vmin=1,vmax=common_max),cmap='magma')
    ax.add_patch(Rectangle((-5,-5),10,10,fill=False,color='#24d18f',lw=1.5))
    for r in (8,20):ax.add_patch(Circle((0,0),r,fill=False,color='#62d6ff',lw=1.2,ls='--'))
    ax.scatter(0,0,marker='+',s=65,color='white');ax.set_xlim(30,-30);ax.set_ylim(-30,30);ax.set_aspect('equal')
    ax.set_xlabel(r'$\Delta$RA cos(Dec) (arcmin; east left)');ax.set_ylabel(r'$\Delta$Dec (arcmin)');ax.set_title(f'({letter}) {label}: 104 observations')
fig.colorbar(im[3],ax=axs[:2],location='right',label='Events per 0.5′ × 0.5′ cell',shrink=.8)
for method,label,color in [('old','Old screen','#667085'),('new','New screen','#1665d8')]:
    d=np.load(OUT/f'rotation_{method}_trials.npz');axs[2].hist(d['net'],bins=45,density=True,histtype='step',lw=1.6,color=color,label=label)
    axs[2].axvline(summary['rotation'][method]['observed']['net'],color=color,ls='--',lw=1.6)
axs[2].set_xlabel('Net counts');axs[2].set_ylabel('Probability density');axs[2].set_title('(c) Rotated controls: 92 observations');axs[2].legend(loc='upper left')
fig.savefig(OUT/'crab_paired_screens_rotation_20261023.pdf');fig.savefig(OUT/'crab_paired_screens_rotation_20261023.png',dpi=150);plt.close(fig)
print('paired rotation plot saved',flush=True)
# Repeat the original leave-one-observation-out template construction for both screens.
map_edges=np.arange(-60.5,61.5,1.);templ_edges=np.arange(-15.5,16.5,1.);centres=np.arange(-45,46);maps={};results={}
for method in ['old','new']:
    outfile=OUT/f'position_{method}_arrays.npz'
    if outfile.exists():
        maps[method]=dict(np.load(outfile));results[method]=json.loads((OUT/f'position_{method}_summary.json').read_text());continue
    train=np.zeros((31,31));noff=0;target=next(o for o in data if o['obsid']=='100018');tx=target['dx'][target[method]];ty=target['dy'][target[method]]
    for o in data:
        if o['obsid']=='100018':continue
        dx=o['dx'][o[method]];dy=o['dy'][o[method]];train+=np.histogram2d(dy,dx,bins=(templ_edges,templ_edges))[0];rr=np.hypot(dx,dy);noff+=int(((rr>=8)&(rr<20)).sum())
    b=noff/(math.pi*(20**2-8**2));template=np.maximum(train-b,0);template/=template.sum();targetmap=np.histogram2d(ty,tx,bins=(map_edges,map_edges))[0]
    ts=np.zeros((91,91));source=np.zeros_like(ts);bg=np.zeros_like(ts);successful=np.zeros_like(ts,dtype=bool)
    for iy,y in enumerate(centres):
        for ix,x in enumerate(centres):
            patch=targetmap[y+60-15:y+60+16,x+60-15:x+60+16];ts[iy,ix],source[iy,ix],bg[iy,ix],successful[iy,ix]=oldmap.template_likelihood(patch,template)
        if iy%20==0:print('map',method,iy,flush=True)
    loc=np.unravel_index(np.argmax(ts),ts.shape);control=np.hypot(*np.meshgrid(centres,centres))>=8
    result=dict(target_obsid='100018',method=method,training_observations=103,selected_events=len(tx),target_delta_c=float(ts[45,45]),target_fitted_template_counts=float(source[45,45]),map_maximum=dict(dx_arcmin=int(centres[loc[1]]),dy_arcmin=int(centres[loc[0]]),delta_c=float(ts[loc])),shifted_position_fraction_ge_target=float((1+(ts[control]>=ts[45,45]).sum())/(1+control.sum())),fit_success_fraction=float(successful.mean()),template_background_per_cell=float(b),no_smoothing=True)
    arrays=dict(ts=ts,source=source,background=bg,template=template,target_map=targetmap)
    np.savez_compressed(outfile,**arrays);(OUT/f'position_{method}_summary.json').write_text(json.dumps(result,indent=2));maps[method]=arrays;results[method]=result
fig,axs=plt.subplots(1,2,figsize=(11.5,5.5),constrained_layout=True);vmax=max(maps[m]['ts'].max() for m in ['old','new'])
for method,label,letter,ax in [('old','Old screen','a',axs[0]),('new','New screen','b',axs[1])]:
    r=results[method];im=ax.imshow(maps[method]['ts'],origin='lower',extent=(-45.5,45.5,-45.5,45.5),vmin=0,vmax=vmax,cmap='viridis',interpolation='nearest')
    ax.scatter(0,0,marker='+',s=140,lw=2,color='#18d6ad',label=f"Crab coordinate (ΔC={r['target_delta_c']:.2f})")
    ax.scatter(r['map_maximum']['dx_arcmin'],r['map_maximum']['dy_arcmin'],marker='X',s=100,facecolor='#ffcf33',edgecolor='#6b4500',label='Highest score in scan')
    ax.set_xlim(45.5,-45.5);ax.set_ylim(-45.5,45.5);ax.set_title(f'({letter}) {label}: ObsID 100018');ax.set_xlabel(r'$\Delta$RA cos(Dec) (arcmin)');ax.set_ylabel(r'$\Delta$Dec (arcmin)');ax.legend(loc='upper left',fontsize=9)
fig.colorbar(im,ax=axs,label=r'Poisson likelihood ratio, $\Delta C$',shrink=.8)
fig.savefig(OUT/'crab_paired_position_diagnostic_20261023.pdf');fig.savefig(OUT/'crab_paired_position_diagnostic_20261023.png',dpi=150);plt.close(fig)
(OUT/'paired_position_summary.json').write_text(json.dumps(results,indent=2));print(json.dumps(results),flush=True)
