#!/usr/bin/env python3
"""Reproducible LE01 detector hot-pixel screening.

The method identifies detector-fixed, temporally persistent, spatially isolated
count excesses.  It does not learn from the legacy filtered files.  Those files
may be used later only for descriptive comparison.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from astropy.io import fits
from scipy.ndimage import uniform_filter
from scipy.stats import poisson


COORD_SIZE = 1024
COORD_BASE = 2048


@dataclass(frozen=True)
class DetectionConfig:
    fdr_q: float = 1e-4
    annulus_outer_size: int = 11
    annulus_inner_size: int = 3
    core_size: int = 3
    min_isolation_fraction: float = 0.90
    min_time_span_fraction: float = 0.80
    time_bin_seconds: float = 32.0
    min_occupied_bins: int = 5
    normal_count_quantile: float = 0.90


def encode(chipx, chipy):
    return np.asarray(chipx, dtype=np.int64) * COORD_BASE + np.asarray(chipy, dtype=np.int64)


def decode(code):
    return int(code // COORD_BASE), int(code % COORD_BASE)


def square_sum(image, size):
    return uniform_filter(image.astype(float), size=size, mode="constant", cval=0.0) * (size * size)


def benjamini_hochberg(p_values, total_tests, q):
    p_values = np.asarray(p_values, dtype=float)
    order = np.argsort(p_values)
    ranked = p_values[order]
    limits = q * np.arange(1, len(ranked) + 1) / float(total_tests)
    passed = ranked <= limits
    selected = np.zeros(len(p_values), dtype=bool)
    if np.any(passed):
        last = np.flatnonzero(passed)[-1]
        selected[order[: last + 1]] = True
    return selected


def detect_hot_pixels(events, header, config=DetectionConfig()):
    chipx = np.asarray(events["chipx"], dtype=np.int64)
    chipy = np.asarray(events["chipy"], dtype=np.int64)
    times = np.asarray(events["time"], dtype=float)
    if np.any((chipx < 0) | (chipx >= COORD_SIZE) | (chipy < 0) | (chipy >= COORD_SIZE)):
        raise ValueError("chipx/chipy values fall outside the expected 0..1023 detector grid")

    codes = encode(chipx, chipy)
    unique_codes, inverse, counts = np.unique(codes, return_inverse=True, return_counts=True)
    xs = unique_codes // COORD_BASE
    ys = unique_codes % COORD_BASE

    tmin = np.full(len(unique_codes), np.inf)
    tmax = np.full(len(unique_codes), -np.inf)
    np.minimum.at(tmin, inverse, times)
    np.maximum.at(tmax, inverse, times)
    spans = tmax - tmin

    tstart = float(header.get("TSTART", np.nanmin(times)))
    tstop = float(header.get("TSTOP", np.nanmax(times)))
    observation_interval = max(tstop - tstart, 1.0)
    bin_index = np.floor((times - tstart) / config.time_bin_seconds).astype(np.int64)
    occupied_pairs = np.unique(np.column_stack((inverse, bin_index)), axis=0)
    occupied_bins = np.bincount(occupied_pairs[:, 0], minlength=len(unique_codes))

    count_image = np.zeros((COORD_SIZE, COORD_SIZE), dtype=float)
    count_image[ys, xs] = counts
    positive_counts = counts[counts > 0]
    clip_count = max(1.0, float(np.quantile(positive_counts, config.normal_count_quantile)))
    normal_image = np.minimum(count_image, clip_count)

    outer_sum = square_sum(normal_image, config.annulus_outer_size)
    inner_sum = square_sum(normal_image, config.annulus_inner_size)
    annulus_area = config.annulus_outer_size**2 - config.annulus_inner_size**2
    local_lambda_image = (outer_sum - inner_sum) / annulus_area
    global_lambda = float(np.sum(normal_image) / normal_image.size)
    expected = np.maximum(local_lambda_image[ys, xs], global_lambda)

    core_sum = square_sum(count_image, config.core_size)[ys, xs]
    neighbour_core = np.maximum(core_sum - counts, 0.0)
    isolation = counts / np.maximum(counts + neighbour_core, 1.0)
    p_values = poisson.sf(counts - 1, expected)
    statistically_excess = benjamini_hochberg(
        p_values, COORD_SIZE * COORD_SIZE, config.fdr_q
    )
    time_persistent = (
        (spans / observation_interval >= config.min_time_span_fraction)
        & (occupied_bins >= config.min_occupied_bins)
    )
    spatially_isolated = isolation >= config.min_isolation_fraction
    selected = statistically_excess & time_persistent & spatially_isolated

    rows = []
    for index in np.flatnonzero(selected):
        rows.append(
            {
                "chipx": int(xs[index]),
                "chipy": int(ys[index]),
                "event_count": int(counts[index]),
                "expected_count": float(expected[index]),
                "poisson_p": float(p_values[index]),
                "time_span_s": float(spans[index]),
                "time_span_fraction": float(spans[index] / observation_interval),
                "occupied_bins": int(occupied_bins[index]),
                "isolation_fraction": float(isolation[index]),
            }
        )
    diagnostics = {
        "raw_events": len(events),
        "observed_pixels": len(unique_codes),
        "candidate_pixels": len(rows),
        "candidate_events": int(np.sum(counts[selected])),
        "global_expected_count_per_pixel": global_lambda,
        "normal_count_clip": clip_count,
        "observation_interval": observation_interval,
    }
    return rows, diagnostics


def filter_events(events, candidates):
    masked = {(row["chipx"], row["chipy"]) for row in candidates}
    return np.fromiter(
        (
            (int(chipx), int(chipy)) not in masked
            for chipx, chipy in zip(events["chipx"], events["chipy"])
        ),
        dtype=bool,
        count=len(events),
    )


def write_candidates(path, candidates):
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "chipx",
        "chipy",
        "event_count",
        "expected_count",
        "poisson_p",
        "time_span_s",
        "time_span_fraction",
        "occupied_bins",
        "isolation_fraction",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(candidates)


def process_file(input_path, output_path=None, candidates_path=None, config=DetectionConfig()):
    with fits.open(input_path, memmap=False) as hdul:
        events = hdul[1].data
        candidates, diagnostics = detect_hot_pixels(events, hdul[1].header, config)
        keep = filter_events(events, candidates)
        diagnostics["retained_events"] = int(np.sum(keep))
        diagnostics["removed_events"] = int(np.sum(~keep))

        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            primary = hdul[0].copy()
            event_hdu = fits.BinTableHDU(data=events[keep], header=hdul[1].header, name=hdul[1].name)
            event_hdu.header.add_history("Hot pixels screened with robust_hot_pixel_filter.py.")
            event_hdu.header.add_history(
                f"Poisson BH FDR q={config.fdr_q}; isolation>={config.min_isolation_fraction}; "
                f"span fraction>={config.min_time_span_fraction}."
            )
            fits.HDUList([primary, event_hdu]).writeto(output_path, overwrite=True, checksum=True)
    if candidates_path:
        write_candidates(Path(candidates_path), candidates)
    return candidates, diagnostics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--candidates", type=Path)
    parser.add_argument("--fdr-q", type=float, default=DetectionConfig.fdr_q)
    parser.add_argument("--min-isolation", type=float, default=DetectionConfig.min_isolation_fraction)
    parser.add_argument("--min-span-fraction", type=float, default=DetectionConfig.min_time_span_fraction)
    parser.add_argument("--time-bin-seconds", type=float, default=DetectionConfig.time_bin_seconds)
    parser.add_argument("--min-occupied-bins", type=int, default=DetectionConfig.min_occupied_bins)
    args = parser.parse_args()
    config = DetectionConfig(
        fdr_q=args.fdr_q,
        min_isolation_fraction=args.min_isolation,
        min_time_span_fraction=args.min_span_fraction,
        time_bin_seconds=args.time_bin_seconds,
        min_occupied_bins=args.min_occupied_bins,
    )
    candidates, diagnostics = process_file(
        args.input, args.output, args.candidates, config
    )
    for key, value in diagnostics.items():
        print(f"{key}={value}")
    print(f"candidate_table_rows={len(candidates)}")


if __name__ == "__main__":
    main()
