"""Repeat common Crab counts with geometric-footprint ratios for every region.
Derivative audit only: source FITS and existing analysis scripts remain unchanged.
"""
from pathlib import Path
from paths import DATA_ROOT as ROOT, OUTPUT as OUT, MASK_DIR
import csv, json, math, pickle, sys
import numpy as np
from astropy.io import fits
import crab_end_to_end_validation as c
import advanced_crab_validation as a
RAW=ROOT/'hotpixel/Crab_evtlist copy 3'; OLD=ROOT/'hotpixel/Crab_htpix_evtlist'; ASP=ROOT/'nh1/Crab_files/Crab_aspect'; MASK=MASK_DIR
raws={p.name.split('_')[0]:p for p in RAW.glob('*_evt1file.fits')}; olds={p.name.split('_')[0]:p for p in OLD.glob('*_evt1_5file.fits')}; asps={p.stem.split('_')[1]:p for p in ASP.glob('aspect_*.fits')}
ids=sorted(raws.keys()&olds.keys()&asps.keys()); assert len(ids)==104
masks=c.read_final_codes(MASK/'initial_candidates.csv',MASK/'persistent_hot_pixel_catalog.csv')
outer=[14.,16.,18.,20.,22.,25.]
axis=np.arange(-24.75,25.,.5); gx,gy=np.meshgrid(axis,axis); xx=gx.ravel(); yy=gy.ravel(); rr=np.hypot(xx,yy)
src=(abs(xx)<5)&(abs(yy)<5); ann=[(rr>=8)&(rr<r) for r in outer]; vec=a.sky_vectors(xx,yy)
cache=OUT/'common_crab_data.pkl'
if cache.exists():
    data=pickle.loads(cache.read_bytes()); print('loaded cache',flush=True)
else:
    data=[]
    for num,oid in enumerate(ids,1):
        with fits.open(raws[oid],memmap=False) as h: ev=h[1].data.copy(); hdr=h[1].header.copy()
        with fits.open(olds[oid],memmap=False) as h: kept=np.unique(c.encode(h[1].data['chipx'],h[1].data['chipy']))
        with fits.open(asps[oid],memmap=False) as h: asp=h[1].data.copy()
        q=a.selected_science(ev); ev=ev[q]; codes=c.encode(ev['chipx'],ev['chipy'])
        times=np.asarray(asp['timeMJD'],float); lookup={float(t):i for i,t in enumerate(times)}; idx=np.array([lookup[float(t)] for t in ev['time']])
        ra,dec=c.transform_events_to_radec(ev['chipx'],ev['chipy'],asp['phi'][idx],asp['theta'][idx],asp['psi'][idx])
        dx,dy=c.tangent_offsets_arcmin(ra,dec,c.CRAB_RA_DEG,c.CRAB_DEC_DEG)
        px,py=c.tangent_offsets_arcmin(ra,dec,hdr['RA_PNT'],hdr['DEC_PNT'])
        tx,ty=c.tangent_offsets_arcmin(c.CRAB_RA_DEG,c.CRAB_DEC_DEG,hdr['RA_PNT'],hdr['DEC_PNT'])
        mats=a.rotation_matrices(asp['phi'],asp['theta'],asp['psi'])
        footprint=a.footprint_counts(vec,mats)*float(hdr['EXPOSURE'])/len(times)
        item=dict(obsid=oid,exposure=float(hdr['EXPOSURE']),ra_pnt=float(hdr['RA_PNT']),dec_pnt=float(hdr['DEC_PNT']),dx=dx,dy=dy,px=px,py=py,tx=float(tx),ty=float(ty),codes=codes,times=np.asarray(ev['time']),aspect_times=times,mats=mats,old=np.isin(codes,kept),new=~np.isin(codes,np.array(sorted(masks[oid]))),footprint=footprint)
        data.append(item)
        if num%10==0: print('footprints',num,flush=True)
    cache.write_bytes(pickle.dumps(data))

def measure(non,noff,alpha):
    return dict(non=int(non),noff=int(noff),alpha_exposure=float(alpha),net=float(non-alpha*noff),net_sigma=float(np.sqrt(non+alpha**2*noff)),li_ma_sigma=float(c.li_ma(non,noff,alpha)))
fp=sum(o['footprint'] for o in data); se=fp[src].sum()*.25
summary={'configuration':{'observations':104,'exposure_s':sum(o['exposure'] for o in data),'grid_arcmin':.5,'region':'10x10 arcmin box; inner annulus radius 8 arcmin','footprint':'all matched aspect records, scaled to each FITS header exposure; no vignetting, effective-area, dead-area or PSF correction'},'main':{},'annulus':{}}
for method in ['old','new']:
    dx=np.concatenate([o['dx'][o[method]] for o in data]); dy=np.concatenate([o['dy'][o[method]] for o in data]); rad=np.hypot(dx,dy)
    non=int(((abs(dx)<5)&(abs(dy)<5)).sum()); rows=[]
    for out,mask in zip(outer,ann):
        alpha=se/(fp[mask].sum()*.25); noff=((rad>=8)&(rad<out)).sum()
        rows.append({'outer_radius_arcmin':out,**measure(non,noff,alpha)})
    summary['annulus'][method]=rows; summary['main'][method]=rows[3]
(OUT/'unified_crab_statistics.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary),flush=True)
# Same 92 observations and 90,180,270 degree controls as the original test.
rotation_cache=OUT/'rotation_aperture_cache.pkl'
if rotation_cache.exists(): rot=pickle.loads(rotation_cache.read_bytes())
else:
    rot=[]
    # 0.5-arcmin centred grid spans the complete 20-arcmin background annulus.
    sel=(abs(xx)<20)&(abs(yy)<20); rx,ry=xx[sel],yy[sel]
    rsrc=(abs(rx)<5)&(abs(ry)<5); rann=(np.hypot(rx,ry)>=8)&(np.hypot(rx,ry)<20)
    for num,o in enumerate(data):
        offset=float(c.angular_separation_arcmin(np.array([o['ra_pnt']]),np.array([o['dec_pnt']]),c.CRAB_RA_DEG,c.CRAB_DEC_DEG)[0])
        if offset<10: continue
        row={'obsid':o['obsid'],'source_exp':[], 'background_exp':[], 'old':[],'new':[]}
        for angle in [0,math.pi/2,math.pi,3*math.pi/2]:
            cx=o['tx']*math.cos(angle)-o['ty']*math.sin(angle); cy=o['tx']*math.sin(angle)+o['ty']*math.cos(angle)
            if angle==0:
                # Preserve exact Crab-centred sky coordinates and original source count.
                f=o['footprint']; s_exp=f[src].sum()*.25; b_exp=f[ann[3]].sum()*.25
                xxev, yyev=o['dx'],o['dy']
            else:
                ra=o['ra_pnt']+(rx+cx)/(60*math.cos(math.radians(o['dec_pnt']))); dec=o['dec_pnt']+(ry+cy)/60
                rar=np.deg2rad(ra); decr=np.deg2rad(dec); v=np.column_stack((np.cos(decr)*np.cos(rar),np.cos(decr)*np.sin(rar),np.sin(decr)))
                f=a.footprint_counts(v,o['mats'])*o['exposure']/len(o['mats']); s_exp=f[rsrc].sum()*.25; b_exp=f[rann].sum()*.25
                xxev,yyev=o['px']-cx,o['py']-cy
            row['source_exp'].append(float(s_exp)); row['background_exp'].append(float(b_exp))
            for method in ['old','new']:
                row[method].append(c.region_counts(xxev[o[method]],yyev[o[method]]))
        rot.append(row)
        if len(rot)%10==0: print('rotation',len(rot),flush=True)
    rotation_cache.write_bytes(pickle.dumps(rot))
assert len(rot)==92
rng=np.random.default_rng(20260819); choices=rng.integers(1,4,size=(5000,len(rot))); obsindex=np.arange(len(rot))[None,:]
source_exp=np.array([r['source_exp'] for r in rot]); bg_exp=np.array([r['background_exp'] for r in rot]);
trialalpha=source_exp[obsindex,choices].sum(1)/bg_exp[obsindex,choices].sum(1)
obsalpha=source_exp[:,0].sum()/bg_exp[:,0].sum(); summary['rotation']={}
for method in ['old','new']:
    counts=np.array([r[method] for r in rot]); non=counts[:,:,0][obsindex,choices].sum(1); noff=counts[:,:,1][obsindex,choices].sum(1)
    net=non-trialalpha*noff; obs=measure(counts[:,0,0].sum(),counts[:,0,1].sum(),obsalpha)
    summary['rotation'][method]={'observations':92,'observed':obs,'trials':5000,'seed':20260819,'p_ge_observed_net':float((1+(net>=obs['net']).sum())/5001),'null_net_quantiles':np.quantile(net,[.025,.5,.975]).tolist(),'null_net_mean':float(net.mean()),'null_net_std':float(net.std(ddof=1)),'trial_alpha_min_median_max':np.quantile(trialalpha,[0,.5,1]).tolist()}
    np.savez_compressed(OUT/f'rotation_{method}_trials.npz',net=net,non=non,noff=noff,alpha=trialalpha)
(OUT/'unified_crab_statistics.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary['rotation']),flush=True)
