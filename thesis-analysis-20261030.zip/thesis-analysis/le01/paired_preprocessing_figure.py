from pathlib import Path
from paths import DATA_ROOT as ROOT, OUTPUT as OUT, MASK_DIR
import json,pickle,sys
import numpy as np
from astropy.io import fits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import crab_end_to_end_validation as c
with fits.open(ROOT/'hotpixel/Crab_evtlist copy 3/100018_evt1file.fits') as h: raw=h[1].data.copy();header=h[1].header.copy()
with fits.open(ROOT/'hotpixel/Crab_htpix_evtlist/100018_evt1_5file.fits') as h:oldcodes=np.unique(c.encode(h[1].data['chipx'],h[1].data['chipy']))
mask=c.read_final_codes(MASK_DIR/'initial_candidates.csv',MASK_DIR/'persistent_hot_pixel_catalog.csv')['100018']
q=np.isfinite(raw['energy'])&(raw['energy']>1)&(raw['energy']<10)&np.isin(raw['grade'],[0,2,3,4,6]);ev=raw[q];codes=c.encode(ev['chipx'],ev['chipy']);keep={'before':np.ones(len(ev),bool),'old':np.isin(codes,oldcodes),'new':~np.isin(codes,list(mask))}
t=np.asarray(ev['time'])-header['TSTART'];energy=np.asarray(ev['energy']);report={'obsid':'100018','raw_records':len(raw),'common_energy_grade_records':len(ev),'old_screen_records':int(keep['old'].sum()),'new_screen_records':int(keep['new'].sum()),'selection':'1 < numeric energy < 10; grades 0,2,3,4,6','header_exposure_s':float(header['EXPOSURE']),'elapsed_interval_s':float(header['TSTOP']-header['TSTART'])}
plt.rcParams.update({'font.size':13,'axes.titlesize':14,'axes.labelsize':13,'xtick.labelsize':11,'ytick.labelsize':11,'legend.fontsize':11,'pdf.fonttype':42})
fig,axs=plt.subplots(2,2,figsize=(10.8,7.9),constrained_layout=True)
for method,label,letter,ax in [('before','Before hot-pixel screening','a',axs[0,0]),('old','Old screen','b',axs[0,1]),('new','New screen','c',axs[1,0])]:
    k=keep[method];ax.scatter(t[k],energy[k],s=3,alpha=.5,color='#2265ad',rasterized=True);ax.set_title(f'({letter}) {label}: {k.sum():,} events');ax.set_xlabel('Time since observation start (s)');ax.set_ylabel('Energy (keV)');ax.set_xlim(0,report['elapsed_interval_s']);ax.set_ylim(1,10)
ax=axs[1,1]
for method,label,color in [('before','Before screening','#c67b2a'),('old','Old screen','#667085'),('new','New screen','#1665d8')]:ax.hist(energy[keep[method]],bins=np.linspace(1,10,46),histtype='step',lw=1.5,label=label,color=color)
ax.set_yscale('log');ax.set_xlabel('Energy (keV)');ax.set_ylabel('Events per 0.2 keV bin');ax.set_title('(d) Energy distributions');ax.legend()
fig.savefig(OUT/'crab_paired_preprocessing_20261023.pdf');fig.savefig(OUT/'crab_paired_preprocessing_20261023.png',dpi=150);plt.close(fig)
(OUT/'paired_preprocessing_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
