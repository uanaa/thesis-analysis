#!/usr/bin/env python3
"""End-to-end LE01 Crab, hot-pixel, and off-axis validation.

The analysis uses the 104 observations for which raw, legacy-screened, and
aspect products all exist. It compares raw, legacy, and independently defined
persistent hot-pixel screens under one grade/energy selection and one supplied
detector-to-sky transformation. All matched aspect records are used for that
transformation; no median--MAD aspect-record screening is applied.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
from matplotlib.colors import LogNorm
from matplotlib.patches import Circle, Rectangle


CRAB_RA_DEG = 83.63308333333333
CRAB_DEC_DEG = 22.0145
VALID_GRADES = np.array([0, 2, 3, 4, 6])
COORD_BASE = 2048
BOX_HALF_ARCMIN = 5.0
ANNULUS_IN_ARCMIN = 8.0
ANNULUS_OUT_ARCMIN = 20.0
ALPHA_GEOMETRIC = (2 * BOX_HALF_ARCMIN) ** 2 / (
    math.pi * (ANNULUS_OUT_ARCMIN**2 - ANNULUS_IN_ARCMIN**2)
)


def angular_separation_arcmin(ra, dec, ref_ra, ref_dec):
    ra_r = np.deg2rad(ra)
    dec_r = np.deg2rad(dec)
    ref_ra_r = np.deg2rad(ref_ra)
    ref_dec_r = np.deg2rad(ref_dec)
    cosine = (
        np.sin(dec_r) * np.sin(ref_dec_r)
        + np.cos(dec_r) * np.cos(ref_dec_r) * np.cos(ra_r - ref_ra_r)
    )
    return np.rad2deg(np.arccos(np.clip(cosine, -1.0, 1.0))) * 60.0


def transform_events_to_radec(chipx, chipy, phi_deg, theta_deg, psi_deg):
    tdetx_mm = (chipx - 512.0) / 1024.0 * 13.3
    tdety_mm = (512.0 - chipy) / 1024.0 * 13.3
    norm = np.sqrt(tdetx_mm**2 + tdety_mm**2 + 375.0**2)
    r0 = np.column_stack((tdetx_mm / norm, tdety_mm / norm, 375.0 / norm))

    phi = np.deg2rad(phi_deg)
    theta = np.deg2rad(theta_deg)
    psi = np.deg2rad(psi_deg)
    cp, sp = np.cos(phi), np.sin(phi)
    ct, st = np.cos(theta), np.sin(theta)
    cs, ss = np.cos(psi), np.sin(psi)
    rb_x = r0[:, 0] * (ct * cs - st * sp * ss) + r0[:, 1] * (-cp * ss) + r0[:, 2] * (
        st * cs + ct * sp * ss
    )
    rb_y = r0[:, 0] * (ct * ss + st * sp * cs) + r0[:, 1] * (cp * cs) + r0[:, 2] * (
        st * ss - ct * sp * cs
    )
    rb_z = r0[:, 0] * (-st * cp) + r0[:, 1] * sp + r0[:, 2] * (ct * cp)
    ra = np.rad2deg(np.arctan2(rb_y, rb_x)) % 360.0
    dec = np.rad2deg(np.arcsin(np.clip(rb_z, -1.0, 1.0)))
    return ra, dec


def tangent_offsets_arcmin(ra, dec, ref_ra, ref_dec):
    dra = (np.asarray(ra) - ref_ra + 180.0) % 360.0 - 180.0
    return dra * math.cos(math.radians(ref_dec)) * 60.0, (np.asarray(dec) - ref_dec) * 60.0


def region_counts(dx, dy, centre_x=0.0, centre_y=0.0):
    x = np.asarray(dx) - centre_x
    y = np.asarray(dy) - centre_y
    radius = np.hypot(x, y)
    non = int(np.sum((np.abs(x) < BOX_HALF_ARCMIN) & (np.abs(y) < BOX_HALF_ARCMIN)))
    noff = int(np.sum((radius >= ANNULUS_IN_ARCMIN) & (radius < ANNULUS_OUT_ARCMIN)))
    return non, noff


def li_ma(non, noff, alpha=ALPHA_GEOMETRIC):
    if non + noff == 0:
        return 0.0
    net = non - alpha * noff
    term_on = 0.0 if non == 0 else non * math.log(((1 + alpha) / alpha) * non / (non + noff))
    term_off = 0.0 if noff == 0 else noff * math.log((1 + alpha) * noff / (non + noff))
    return math.copysign(math.sqrt(max(0.0, 2.0 * (term_on + term_off))), net)


def encode(chipx, chipy):
    return np.asarray(chipx, dtype=np.int64) * COORD_BASE + np.asarray(chipy, dtype=np.int64)


def read_final_codes(initial_path, catalogue_path):
    with catalogue_path.open(newline="", encoding="utf-8") as stream:
        catalogue = {
            int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            for row in csv.DictReader(stream)
        }
    by_obs = defaultdict(set)
    with initial_path.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            code = int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            if code in catalogue:
                by_obs[row["obsid"]].add(code)
    return by_obs


def summarise_counts(rows, method, aspect):
    selected = [
        row
        for row in rows
        if row["method"] == method
        and row["aspect"] == aspect
    ]
    non = sum(row["non"] for row in selected)
    noff = sum(row["noff"] for row in selected)
    exposure = sum(row["exposure_s"] for row in selected)
    selected_events = sum(row["selected_events"] for row in selected)
    net = non - ALPHA_GEOMETRIC * noff
    net_sigma = math.sqrt(non + ALPHA_GEOMETRIC**2 * noff)
    return {
        "observations": len(selected),
        "exposure_s": exposure,
        "selected_events": selected_events,
        "non": non,
        "noff": noff,
        "alpha": ALPHA_GEOMETRIC,
        "net": net,
        "net_sigma": net_sigma,
        "net_rate_per_ks": net / exposure * 1000.0 if exposure else None,
        "net_rate_sigma_per_ks": net_sigma / exposure * 1000.0 if exposure else None,
        "li_ma_sigma": li_ma(non, noff),
    }


def concatenated_events(obs_data, method):
    dx = []
    dy = []
    for obs in obs_data:
        mask = obs["method_masks"][method]
        dx.append(obs["crab_dx"][mask])
        dy.append(obs["crab_dy"][mask])
    return np.concatenate(dx), np.concatenate(dy)


def annulus_sensitivity(obs_data, method):
    dx, dy = concatenated_events(obs_data, method)
    radius = np.hypot(dx, dy)
    non = int(np.sum((np.abs(dx) < BOX_HALF_ARCMIN) & (np.abs(dy) < BOX_HALF_ARCMIN)))
    output = []
    for outer in (14.0, 16.0, 18.0, 20.0, 22.0, 25.0):
        noff = int(np.sum((radius >= ANNULUS_IN_ARCMIN) & (radius < outer)))
        alpha = (2 * BOX_HALF_ARCMIN) ** 2 / (
            math.pi * (outer**2 - ANNULUS_IN_ARCMIN**2)
        )
        output.append(
            {
                "outer_radius_arcmin": outer,
                "non": non,
                "noff": noff,
                "alpha": alpha,
                "net": non - alpha * noff,
                "li_ma_sigma": li_ma(non, noff, alpha),
            }
        )
    return output


def matched_rotation_null(obs_data, method, trials=5000, seed=20260819):
    eligible = [obs for obs in obs_data if obs["commanded_offset_arcmin"] >= 10.0]
    observed_non = 0
    observed_noff = 0
    for obs in eligible:
        mask = obs["method_masks"][method]
        non, noff = region_counts(obs["crab_dx"][mask], obs["crab_dy"][mask])
        observed_non += non
        observed_noff += noff
    observed_net = observed_non - ALPHA_GEOMETRIC * observed_noff

    rng = np.random.default_rng(seed)
    null_net = np.empty(trials)
    null_non = np.empty(trials, dtype=int)
    rotations = np.array([math.pi / 2, math.pi, 3 * math.pi / 2])
    for trial in range(trials):
        total_non = 0
        total_noff = 0
        for obs in eligible:
            mask = obs["method_masks"][method]
            angle = rotations[rng.integers(0, len(rotations))]
            tx, ty = obs["target_from_pnt"]
            cx = tx * math.cos(angle) - ty * math.sin(angle)
            cy = tx * math.sin(angle) + ty * math.cos(angle)
            non, noff = region_counts(obs["pnt_dx"][mask], obs["pnt_dy"][mask], cx, cy)
            total_non += non
            total_noff += noff
        null_non[trial] = total_non
        null_net[trial] = total_non - ALPHA_GEOMETRIC * total_noff
    return {
        "observations": len(eligible),
        "observed_non": observed_non,
        "observed_noff": observed_noff,
        "observed_net": observed_net,
        "observed_li_ma_sigma": li_ma(observed_non, observed_noff),
        "null_net_mean": float(np.mean(null_net)),
        "null_net_std": float(np.std(null_net, ddof=1)),
        "null_net_quantiles": [float(x) for x in np.quantile(null_net, [0.025, 0.5, 0.975])],
        "empirical_p_ge_observed_net": float((1 + np.sum(null_net >= observed_net)) / (trials + 1)),
        "null_non_mean": float(np.mean(null_non)),
        "trials": trials,
        "null_net": null_net,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--legacy-dir", type=Path, required=True)
    parser.add_argument("--aspect-dir", type=Path, required=True)
    parser.add_argument("--initial-candidates", type=Path, required=True)
    parser.add_argument("--catalogue", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    final_codes = read_final_codes(args.initial_candidates, args.catalogue)
    raw_paths = {path.name.split("_")[0]: path for path in args.raw_dir.glob("*_evt1file.fits")}
    legacy_paths = {path.name.split("_")[0]: path for path in args.legacy_dir.glob("*_evt1_5file.fits")}
    aspect_paths = {path.stem.split("_")[1]: path for path in args.aspect_dir.glob("aspect_*.fits")}
    obsids = sorted(set(raw_paths) & set(legacy_paths) & set(aspect_paths))
    if len(obsids) != 104:
        raise RuntimeError(f"Expected 104 matched raw/legacy/aspect observations, found {len(obsids)}")

    rows = []
    obs_data = []
    hotpixel_audit = defaultdict(int)
    for number, obsid in enumerate(obsids, 1):
        with fits.open(aspect_paths[obsid], memmap=True) as hdul:
            aspect = hdul[1].data
            times = np.asarray(aspect["timeMJD"], dtype=float)
            phi = np.asarray(aspect["phi"], dtype=float)
            theta = np.asarray(aspect["theta"], dtype=float)
            psi = np.asarray(aspect["psi"], dtype=float)
        time_index = {float(time): index for index, time in enumerate(times)}

        with fits.open(raw_paths[obsid], memmap=False) as hdul:
            events = hdul[1].data
            header = hdul[1].header
            pnt_ra = float(header["RA_PNT"])
            pnt_dec = float(header["DEC_PNT"])
            exposure = float(header.get("EXPOSURE", header.get("ONTIME", len(times))))
            event_codes = encode(events["chipx"], events["chipy"])
            science = (
                np.isfinite(events["energy"])
                & (events["energy"] > 1.0)
                & (events["energy"] < 10.0)
                & np.isin(events["grade"], VALID_GRADES)
            )
            selected_codes = event_codes[science]
            selected_times = np.asarray(events["time"][science], dtype=float)
            selected_chipx = np.asarray(events["chipx"][science], dtype=float)
            selected_chipy = np.asarray(events["chipy"][science], dtype=float)

        with fits.open(legacy_paths[obsid], memmap=True) as hdul:
            kept_codes = np.unique(encode(hdul[1].data["chipx"], hdul[1].data["chipy"]))

        indices = np.array([time_index[float(time)] for time in selected_times], dtype=int)
        event_ra, event_dec = transform_events_to_radec(
            selected_chipx, selected_chipy, phi[indices], theta[indices], psi[indices]
        )
        crab_dx, crab_dy = tangent_offsets_arcmin(
            event_ra, event_dec, CRAB_RA_DEG, CRAB_DEC_DEG
        )
        pnt_dx, pnt_dy = tangent_offsets_arcmin(event_ra, event_dec, pnt_ra, pnt_dec)
        target_x, target_y = tangent_offsets_arcmin(
            np.array([CRAB_RA_DEG]), np.array([CRAB_DEC_DEG]), pnt_ra, pnt_dec
        )
        method_masks = {
            "raw": np.ones(len(selected_codes), dtype=bool),
            "legacy": np.isin(selected_codes, kept_codes),
            "new": ~np.isin(
                selected_codes,
                np.fromiter(final_codes.get(obsid, set()), dtype=np.int64),
            )
            if final_codes.get(obsid)
            else np.ones(len(selected_codes), dtype=bool),
        }
        commanded_offset = float(
            angular_separation_arcmin(
                np.array([pnt_ra]), np.array([pnt_dec]), CRAB_RA_DEG, CRAB_DEC_DEG
            )[0]
        )
        raw_source = (np.abs(crab_dx) < BOX_HALF_ARCMIN) & (np.abs(crab_dy) < BOX_HALF_ARCMIN)
        hotpixel_audit["science_events_raw"] += len(selected_codes)
        hotpixel_audit["science_source_events_raw"] += int(np.sum(raw_source))
        for method in ("legacy", "new"):
            removed = ~method_masks[method]
            hotpixel_audit[f"science_events_removed_{method}"] += int(np.sum(removed))
            hotpixel_audit[f"science_source_events_removed_{method}"] += int(np.sum(removed & raw_source))
            hotpixel_audit[f"science_source_events_retained_{method}"] += int(np.sum(method_masks[method] & raw_source))

        for method, method_mask in method_masks.items():
            selection = method_mask
            non, noff = region_counts(crab_dx[selection], crab_dy[selection])
            rows.append(
                {
                    "obsid": obsid,
                    "method": method,
                    "aspect": "all",
                    "commanded_offset_arcmin": commanded_offset,
                    "exposure_s": exposure,
                    "selected_events": int(np.sum(selection)),
                    "non": non,
                    "noff": noff,
                    "net": non - ALPHA_GEOMETRIC * noff,
                    "li_ma_sigma": li_ma(non, noff),
                }
            )

        obs_data.append(
            {
                "obsid": obsid,
                "commanded_offset_arcmin": commanded_offset,
                "crab_dx": crab_dx,
                "crab_dy": crab_dy,
                "pnt_dx": pnt_dx,
                "pnt_dy": pnt_dy,
                "target_from_pnt": (float(target_x[0]), float(target_y[0])),
                "method_masks": method_masks,
            }
        )
        if number % 20 == 0 or number == len(obsids):
            print(f"loaded {number}/{len(obsids)}", flush=True)

    with (args.output_dir / "per_observation.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    aggregate = {}
    for method in ("raw", "legacy", "new"):
        aggregate[method] = {}
        aggregate[method]["all"] = {
            "all_offsets": summarise_counts(rows, method, "all"),
        }
    rotation_results = {}
    rotation_arrays = {}
    for method in ("legacy", "new"):
        result = matched_rotation_null(obs_data, method)
        rotation_arrays[method] = result.pop("null_net")
        rotation_results[method] = result

    annulus_results = {
        method: annulus_sensitivity(obs_data, method)
        for method in ("legacy", "new")
    }

    for method in ("legacy", "new"):
        hotpixel_audit[f"science_removed_fraction_{method}"] = (
            hotpixel_audit[f"science_events_removed_{method}"] / hotpixel_audit["science_events_raw"]
        )
        hotpixel_audit[f"source_removed_fraction_{method}"] = (
            hotpixel_audit[f"science_source_events_removed_{method}"]
            / hotpixel_audit["science_source_events_raw"]
            if hotpixel_audit["science_source_events_raw"]
            else None
        )

    summary = {
        "configuration": {
            "observations": len(obsids),
            "energy_keV": "1 < E < 10",
            "grades": VALID_GRADES.tolist(),
            "source_region": "10 x 10 arcmin square centred on Crab",
            "background_region": "8-20 arcmin annulus centred on Crab",
            "alpha_geometric": ALPHA_GEOMETRIC,
            "aspect_selection": "none; all matched aspect records are used for coordinate transformation",
            "matched_null": "per-observation 90/180/270-degree rotations of the target offset about RA_PNT/DEC_PNT",
        },
        "hotpixel_end_to_end_audit": dict(hotpixel_audit),
        "aggregate": aggregate,
        "matched_rotation_null": rotation_results,
        "annulus_outer_radius_sensitivity": annulus_results,
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    plt.rcParams.update(
        {
            "font.size": 13.5,
            "axes.titlesize": 15.0,
            "axes.labelsize": 13.0,
            "xtick.labelsize": 11.5,
            "ytick.labelsize": 11.5,
            "legend.fontsize": 10.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.65), constrained_layout=True)

    new_dx, new_dy = concatenated_events(obs_data, "new")
    central = (np.abs(new_dx) <= 30.0) & (np.abs(new_dy) <= 30.0)
    axes[0].hist2d(
        new_dx[central],
        new_dy[central],
        bins=120,
        range=[[-30, 30], [-30, 30]],
        norm=LogNorm(vmin=1),
        cmap="magma",
    )
    axes[0].add_patch(Rectangle((-5, -5), 10, 10, fill=False, color="#24d18f", linewidth=1.5))
    for radius in (8, 20):
        axes[0].add_patch(Circle((0, 0), radius, fill=False, color="#62d6ff", linewidth=1.2, linestyle="--"))
    axes[0].scatter([0], [0], marker="+", s=70, linewidth=1.3, color="white")
    axes[0].set_xlim(30, -30)
    axes[0].set_ylim(-30, 30)
    axes[0].set_aspect("equal")
    axes[0].set_xlabel(r"$\Delta$RA cos(Dec) (arcmin; east left)")
    axes[0].set_ylabel(r"$\Delta$Dec (arcmin)")
    axes[0].set_title("(a) Replacement-screened Crab stack")

    for method, label, color in (
        ("legacy", "archived-screen controls", "#667085"),
        ("new", "replacement-screen controls", "#1665d8"),
    ):
        values = rotation_arrays[method]
        axes[1].hist(values, bins=45, density=True, histtype="step", linewidth=1.6, color=color, label=label)
        axes[1].axvline(rotation_results[method]["observed_net"], color=color, linestyle="--", linewidth=1.5)
    axes[1].set_xlabel("Rotated-control net counts")
    axes[1].set_ylabel("Probability density")
    axes[1].set_title("(b) Rotated detector-position controls")
    axes[1].legend()
    fig.savefig(args.output_dir / "crab_source_rotation_validation.pdf")
    plt.close(fig)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
