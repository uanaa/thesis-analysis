#!/usr/bin/env python3
"""Build and audit a cross-observation LE01 persistent hot-pixel catalogue."""

from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path

import numpy as np
from astropy.io import fits
from scipy.stats import binom

from robust_hot_pixel_filter import (
    COORD_BASE,
    COORD_SIZE,
    DetectionConfig,
    benjamini_hochberg,
    detect_hot_pixels,
    encode,
)


def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("raw_directory", type=Path)
    parser.add_argument("--legacy-directory", type=Path)
    parser.add_argument("--output-directory", type=Path, required=True)
    parser.add_argument("--catalog-fdr-q", type=float, default=0.01)
    parser.add_argument("--min-recurrence", type=int, default=20)
    parser.add_argument("--write-filtered-fits", action="store_true")
    args = parser.parse_args()

    args.output_directory.mkdir(parents=True, exist_ok=True)
    raw_paths = sorted(args.raw_directory.glob("*_evt1file.fits"))
    config = DetectionConfig()
    candidate_frequency = Counter()
    candidate_details = {}
    candidate_rows = []
    diagnostics = {}

    for number, raw_path in enumerate(raw_paths, start=1):
        obsid = raw_path.name.replace("_evt1file.fits", "")
        with fits.open(raw_path, memmap=True) as hdul:
            candidates, diag = detect_hot_pixels(hdul[1].data, hdul[1].header, config)
        candidate_details[obsid] = candidates
        diagnostics[obsid] = diag
        for row in candidates:
            code = int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            candidate_frequency[code] += 1
            candidate_rows.append({"obsid": obsid, **row})
        if number % 20 == 0 or number == len(raw_paths):
            print(f"candidate pass {number}/{len(raw_paths)}", flush=True)

    n_observations = len(raw_paths)
    total_tests = n_observations * COORD_SIZE * COORD_SIZE
    total_candidates = sum(candidate_frequency.values())
    null_probability = total_candidates / total_tests
    codes = np.asarray(sorted(candidate_frequency), dtype=np.int64)
    recurrence = np.asarray([candidate_frequency[int(code)] for code in codes], dtype=int)
    p_values = binom.sf(recurrence - 1, n_observations, null_probability)
    significant = benjamini_hochberg(p_values, COORD_SIZE * COORD_SIZE, args.catalog_fdr_q)
    selected = significant & (recurrence >= args.min_recurrence)
    catalogue_codes = set(int(code) for code in codes[selected])

    catalog_rows = []
    for code, count, p_value in zip(codes[selected], recurrence[selected], p_values[selected]):
        catalog_rows.append(
            {
                "chipx": int(code // COORD_BASE),
                "chipy": int(code % COORD_BASE),
                "candidate_observations": int(count),
                "candidate_fraction": float(count / n_observations),
                "binomial_p": float(p_value),
            }
        )
    write_csv(
        args.output_directory / "persistent_hot_pixel_catalog.csv",
        catalog_rows,
        ["chipx", "chipy", "candidate_observations", "candidate_fraction", "binomial_p"],
    )
    write_csv(
        args.output_directory / "initial_candidates.csv",
        candidate_rows,
        list(candidate_rows[0]),
    )

    audit_rows = []
    total_new_pixels = 0
    total_new_events = 0
    total_legacy_pixels = 0
    total_overlap_pixels = 0
    total_new_only_pixels = 0
    total_legacy_only_pixels = 0
    total_overlap_events = 0
    total_new_only_events = 0
    total_legacy_only_events = 0

    for number, raw_path in enumerate(raw_paths, start=1):
        obsid = raw_path.name.replace("_evt1file.fits", "")
        candidates = candidate_details[obsid]
        final_codes = {
            int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            for row in candidates
            if int(row["chipx"]) * COORD_BASE + int(row["chipy"]) in catalogue_codes
        }
        with fits.open(raw_path, memmap=False) as hdul:
            events = hdul[1].data
            event_codes = encode(events["chipx"], events["chipy"])
            remove = np.isin(event_codes, np.fromiter(final_codes, dtype=np.int64)) if final_codes else np.zeros(len(events), dtype=bool)
            new_events = int(np.sum(remove))
            if args.write_filtered_fits:
                output_path = args.output_directory / "filtered_fits" / raw_path.name.replace("_evt1file", "_new_hotpixels")
                output_path.parent.mkdir(parents=True, exist_ok=True)
                primary = hdul[0].copy()
                event_hdu = fits.BinTableHDU(data=events[~remove], header=hdul[1].header, name=hdul[1].name)
                event_hdu.header.add_history("Cross-observation persistent hot-pixel catalogue applied.")
                fits.HDUList([primary, event_hdu]).writeto(output_path, overwrite=True, checksum=True)

            legacy_codes = set()
            legacy_remove = np.zeros(len(events), dtype=bool)
            legacy_path = None
            if args.legacy_directory:
                legacy_path = args.legacy_directory / f"{obsid}_evt1_5file.fits"
            if legacy_path and legacy_path.exists():
                with fits.open(legacy_path, memmap=True) as legacy_hdul:
                    kept_codes = set(
                        encode(legacy_hdul[1].data["chipx"], legacy_hdul[1].data["chipy"]).tolist()
                    )
                raw_codes = set(np.unique(event_codes).tolist())
                legacy_codes = raw_codes - kept_codes
                legacy_remove = np.isin(event_codes, np.fromiter(legacy_codes, dtype=np.int64))

            overlap = len(final_codes & legacy_codes)
            new_only = len(final_codes - legacy_codes)
            legacy_only = len(legacy_codes - final_codes)
            total_new_pixels += len(final_codes)
            total_new_events += new_events
            total_legacy_pixels += len(legacy_codes)
            total_overlap_pixels += overlap
            total_new_only_pixels += new_only
            total_legacy_only_pixels += legacy_only
            total_overlap_events += int(np.sum(remove & legacy_remove))
            total_new_only_events += int(np.sum(remove & ~legacy_remove))
            total_legacy_only_events += int(np.sum(~remove & legacy_remove))
            audit_rows.append(
                {
                    "obsid": obsid,
                    "raw_events": len(events),
                    "initial_candidates": len(candidates),
                    "new_mask_pixels": len(final_codes),
                    "new_removed_events": new_events,
                    "legacy_mask_pixels": len(legacy_codes),
                    "overlap_pixels": overlap,
                    "new_only_pixels": new_only,
                    "legacy_only_pixels": legacy_only,
                }
            )
        if number % 20 == 0 or number == len(raw_paths):
            print(f"audit pass {number}/{len(raw_paths)}", flush=True)

    write_csv(
        args.output_directory / "per_observation_audit.csv",
        audit_rows,
        list(audit_rows[0]),
    )
    print("\nCATALOGUE")
    print(f"observations={n_observations}")
    print(f"initial candidate flags={total_candidates}")
    print(f"empirical per-test candidate probability={null_probability:.8g}")
    print(f"persistent catalogue pixels={len(catalogue_codes)}")
    print(f"final pixel-observation masks={total_new_pixels}")
    print(f"final removed events={total_new_events}")
    if args.legacy_directory:
        print("\nDESCRIPTIVE LEGACY COMPARISON (legacy is not ground truth)")
        print(f"legacy pixel-observation masks={total_legacy_pixels}")
        print(f"overlap={total_overlap_pixels}")
        print(f"new only={total_new_only_pixels}")
        print(f"legacy only={total_legacy_only_pixels}")
        print(f"event overlap={total_overlap_events}")
        print(f"new-only removed events={total_new_only_events}")
        print(f"legacy-only removed events={total_legacy_only_events}")
        precision = total_overlap_pixels / total_new_pixels if total_new_pixels else np.nan
        legacy_coverage = total_overlap_pixels / total_legacy_pixels if total_legacy_pixels else np.nan
        print(f"new-mask legacy overlap fraction={precision:.4f}")
        print(f"legacy-mask covered by new method={legacy_coverage:.4f}")


if __name__ == "__main__":
    main()
