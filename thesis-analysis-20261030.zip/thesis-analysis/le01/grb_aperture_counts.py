"""Reproduce Chapter 3's fixed-calibration GRB aperture equations.

Inputs are the counts and fractions printed in the thesis. This calculator
does not read mission data or estimate an instrumental photon-flux response.
"""
from math import log, sqrt
import json
from scipy.optimize import brentq
from scipy.stats import norm


def grb220408a():
    source, background = 135, 1205
    ratio, fs, fb = 8.33, 0.534, 0.103
    net = (ratio * source - background) / (ratio * fs - fb)
    uncertainty = sqrt(ratio**2 * source + background) / (ratio * fs - fb)

    def profile_nll(mu):
        def derivative(b):
            return source / (b + fs * mu) + ratio * background / (ratio * b + fb * mu) - (1 + ratio)
        lower = 1e-12
        b = 0.0 if derivative(lower) <= 0 else brentq(derivative, lower, source + background + 1.0)
        means = (b + fs * mu, ratio * b + fb * mu)
        return sum(mean - count * log(mean) for count, mean in zip((source, background), means))

    # The unconstrained net estimate is negative, so the constrained MLE is zero.
    assert net < 0
    null = profile_nll(0.0)
    threshold = norm.ppf(0.997)**2
    upper = brentq(lambda mu: 2 * (profile_nll(mu) - null) - threshold, 0.0, 1000.0)
    return dict(source_counts=source, background_counts=background, r=ratio, fs=fs, fb=fb,
                net_counts=net, propagated_sigma=uncertainty,
                asymptotic_one_sided_confidence=0.997, upper_counts=upper,
                upper_counts_per_second=upper / 1004)


def grb220714b():
    source = 52.89 + 54 - 5
    background, ratio = 313, 25 / 9
    fs, fb = 378909 / 708992, 24827 / 708992
    net = (ratio * source - background) / (ratio * fs - fb)
    return dict(source_quantity=source, background_quantity=background, r=ratio, fs=fs, fb=fb,
                net_estimate=net,
                interpretation="Fractional recorded quantities; no Poisson upper bound is calculated.")


if __name__ == '__main__':
    print(json.dumps({'GRB220408A': grb220408a(), 'GRB220714B': grb220714b()}, indent=2))
