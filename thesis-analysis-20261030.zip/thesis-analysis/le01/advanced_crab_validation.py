#!/usr/bin/env python3
"""Advanced reproducibility checks for the LE01 Crab/hot-pixel analysis.

This script adds four deliberately bounded checks that do not require an ARF:
geometric footprint exposure, leave-one-observation-out and chronological
hot-pixel validation, detector-mask retention of an empirical source-excess
injection, and background/exposure-matched off-axis inference.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
from scipy.stats import binom, norm

from crab_end_to_end_validation import (
    ANNULUS_IN_ARCMIN,
    ANNULUS_OUT_ARCMIN,
    BOX_HALF_ARCMIN,
    COORD_BASE,
    CRAB_DEC_DEG,
    CRAB_RA_DEG,
    VALID_GRADES,
    angular_separation_arcmin,
    encode,
    li_ma,
    tangent_offsets_arcmin,
    transform_events_to_radec,
)

DETECTOR_SIZE = 1024
DETECTOR_MM = 13.3
FOCAL_MM = 375.0
TOTAL_TESTS = DETECTOR_SIZE**2


def rotation_matrices(phi_deg, theta_deg, psi_deg):
    """Return M for row-vector forward transform rb = r0 @ M."""
    phi = np.deg2rad(phi_deg)
    theta = np.deg2rad(theta_deg)
    psi = np.deg2rad(psi_deg)
    cp, sp = np.cos(phi), np.sin(phi)
    ct, st = np.cos(theta), np.sin(theta)
    cs, ss = np.cos(psi), np.sin(psi)
    out = np.empty((len(np.atleast_1d(phi)), 3, 3), dtype=float)
    out[:, 0, 0] = ct * cs - st * sp * ss
    out[:, 1, 0] = -cp * ss
    out[:, 2, 0] = st * cs + ct * sp * ss
    out[:, 0, 1] = ct * ss + st * sp * cs
    out[:, 1, 1] = cp * cs
    out[:, 2, 1] = st * ss - ct * sp * cs
    out[:, 0, 2] = -st * cp
    out[:, 1, 2] = sp
    out[:, 2, 2] = ct * cp
    return out


def sky_vectors(dx_arcmin, dy_arcmin):
    ra = CRAB_RA_DEG + np.asarray(dx_arcmin) / (60.0 * math.cos(math.radians(CRAB_DEC_DEG)))
    dec = CRAB_DEC_DEG + np.asarray(dy_arcmin) / 60.0
    ra = np.deg2rad(ra)
    dec = np.deg2rad(dec)
    return np.column_stack((np.cos(dec) * np.cos(ra), np.cos(dec) * np.sin(ra), np.sin(dec)))


def inverse_to_chip(vectors, matrices):
    """Map matched sky vectors/matrices to detector coordinates."""
    r0 = np.einsum("ij,ikj->ik", vectors, matrices)
    valid = r0[:, 2] > 0
    tx = np.full(len(r0), np.nan)
    ty = np.full(len(r0), np.nan)
    tx[valid] = FOCAL_MM * r0[valid, 0] / r0[valid, 2]
    ty[valid] = FOCAL_MM * r0[valid, 1] / r0[valid, 2]
    chipx = 512.0 + tx / DETECTOR_MM * DETECTOR_SIZE
    chipy = 512.0 - ty / DETECTOR_MM * DETECTOR_SIZE
    valid &= (chipx >= 0) & (chipx < DETECTOR_SIZE) & (chipy >= 0) & (chipy < DETECTOR_SIZE)
    return chipx, chipy, valid


def footprint_counts(vectors, matrices, batch=48):
    result = np.zeros(len(vectors), dtype=np.int64)
    for start in range(0, len(matrices), batch):
        mats = matrices[start : start + batch]
        r0 = np.einsum("pj,bkj->bpk", vectors, mats)
        positive = r0[:, :, 2] > 0
        tx = FOCAL_MM * r0[:, :, 0] / np.where(positive, r0[:, :, 2], 1.0)
        ty = FOCAL_MM * r0[:, :, 1] / np.where(positive, r0[:, :, 2], 1.0)
        chipx = 512.0 + tx / DETECTOR_MM * DETECTOR_SIZE
        chipy = 512.0 - ty / DETECTOR_MM * DETECTOR_SIZE
        inside = positive & (chipx >= 0) & (chipx < DETECTOR_SIZE) & (chipy >= 0) & (chipy < DETECTOR_SIZE)
        result += np.sum(inside, axis=0)
    return result


def bh_catalogue(obs_candidates, training_obs, min_recurrence):
    recurrence = defaultdict(int)
    total_flags = 0
    for obsid in training_obs:
        total_flags += len(obs_candidates[obsid])
        for code in obs_candidates[obsid]:
            recurrence[code] += 1
    nobs = len(training_obs)
    p0 = total_flags / (nobs * TOTAL_TESTS)
    codes = np.fromiter(recurrence, dtype=np.int64)
    counts = np.array([recurrence[int(code)] for code in codes], dtype=int)
    pvals = binom.sf(counts - 1, nobs, p0)
    order = np.argsort(pvals)
    passed = pvals[order] <= 0.01 * np.arange(1, len(order) + 1) / TOTAL_TESTS
    selected = np.zeros(len(codes), dtype=bool)
    if np.any(passed):
        selected[order[: np.flatnonzero(passed)[-1] + 1]] = True
    selected &= counts >= min_recurrence
    return set(codes[selected].tolist()), p0


def selected_science(events):
    return (
        np.isfinite(events["energy"])
        & (events["energy"] > 1.0)
        & (events["energy"] < 10.0)
        & np.isin(events["grade"], VALID_GRADES)
    )


def weighted_regression(x, y, variance):
    weights = 1.0 / np.maximum(variance, 1e-6)
    xtwx_inv = np.linalg.pinv(x.T @ (weights[:, None] * x))
    beta = xtwx_inv @ (x.T @ (weights * y))
    residual = y - x @ beta
    hat = np.sum((x @ xtwx_inv) * (weights[:, None] * x), axis=1)
    meat = x.T @ (((weights * residual / np.maximum(1.0 - hat, 1e-3)) ** 2)[:, None] * x)
    cov_hc3 = xtwx_inv @ meat @ xtwx_inv
    return beta, np.sqrt(np.maximum(np.diag(cov_hc3), 0.0)), residual


def aggregate_onoff(rows):
    non = sum(r["non"] for r in rows)
    noff = sum(r["noff"] for r in rows)
    src_exp = sum(r["source_exposure_area"] for r in rows)
    off_exp = sum(r["annulus_exposure_area"] for r in rows)
    live = sum(r["exposure_s"] for r in rows)
    alpha = src_exp / off_exp
    net = non - alpha * noff
    sigma = math.sqrt(non + alpha * alpha * noff)
    return {
        "observations": len(rows), "non": non, "noff": noff, "alpha_exposure": alpha,
        "net": net, "net_sigma": sigma, "exposure_s": live,
        "net_rate_per_ks": net / live * 1000.0, "net_rate_sigma_per_ks": sigma / live * 1000.0,
        "li_ma_sigma": li_ma(non, noff, alpha),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--legacy-dir", type=Path, required=True)
    parser.add_argument("--aspect-dir", type=Path, required=True)
    parser.add_argument("--initial-candidates", type=Path, required=True)
    parser.add_argument("--catalogue", type=Path, required=True)
    parser.add_argument("--grb-file", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    raw_paths = {p.name.split("_")[0]: p for p in args.raw_dir.glob("*_evt1file.fits")}
    legacy_paths = {p.name.split("_")[0]: p for p in args.legacy_dir.glob("*_evt1_5file.fits")}
    aspect_paths = {p.stem.split("_")[1]: p for p in args.aspect_dir.glob("aspect_*.fits")}
    obsids = sorted(set(raw_paths) & set(legacy_paths) & set(aspect_paths))
    if len(obsids) != 104:
        raise RuntimeError(f"Expected 104 matched observations; got {len(obsids)}")

    obs_candidates = defaultdict(set)
    with args.initial_candidates.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            obs_candidates[row["obsid"]].add(int(row["chipx"]) * COORD_BASE + int(row["chipy"]))
    global_catalogue = set()
    with args.catalogue.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            global_catalogue.add(int(row["chipx"]) * COORD_BASE + int(row["chipy"]))
    global_masks = {obsid: obs_candidates[obsid] & global_catalogue for obsid in obsids}

    # Exact leave-one-observation-out catalogue training.
    loo_catalogues = {}
    loo_masks = {}
    loo_jaccard = []
    for i, heldout in enumerate(obsids):
        training = [x for x in obsids if x != heldout]
        cat, _ = bh_catalogue(obs_candidates, training, min_recurrence=20)
        loo_catalogues[heldout] = cat
        loo_masks[heldout] = obs_candidates[heldout] & cat
        union = global_catalogue | cat
        loo_jaccard.append(len(global_catalogue & cat) / len(union))

    # Chronological split; recurrence threshold is scaled from 20/104 to 10/52.
    dates = {}
    for obsid in obsids:
        with fits.open(raw_paths[obsid], memmap=True) as hdul:
            dates[obsid] = datetime.fromisoformat(str(hdul[1].header["DATE-OBS"]).replace("Z", ""))
    chronological = sorted(obsids, key=lambda x: dates[x])
    early, late = chronological[:52], chronological[52:]
    early_cat, early_p0 = bh_catalogue(obs_candidates, early, min_recurrence=10)
    late_cat, late_p0 = bh_catalogue(obs_candidates, late, min_recurrence=10)
    split_jaccard = len(early_cat & late_cat) / len(early_cat | late_cat)
    cross_masks = {obsid: obs_candidates[obsid] & (late_cat if obsid in early else early_cat) for obsid in obsids}

    # Cell centres for a 0.5 arcmin grid spanning [-25, 25); this makes the
    # 10x10 arcmin source box exactly 20x20 equal-area cells.
    grid_axis = np.arange(-24.75, 25.0, 0.5)
    gx, gy = np.meshgrid(grid_axis, grid_axis)
    grid_vectors = sky_vectors(gx.ravel(), gy.ravel())
    grid_source = (np.abs(gx.ravel()) < BOX_HALF_ARCMIN) & (np.abs(gy.ravel()) < BOX_HALF_ARCMIN)
    grid_radius = np.hypot(gx.ravel(), gy.ravel())
    grid_annulus = (grid_radius >= ANNULUS_IN_ARCMIN) & (grid_radius < ANNULUS_OUT_ARCMIN)
    cell_area = (grid_axis[1] - grid_axis[0]) ** 2
    total_exposure_map = np.zeros(len(grid_vectors), dtype=float)
    rows = []
    injection_inputs = []
    removal_audit = {k: {"all": 0, "science": 0, "source": 0} for k in ("global", "loo", "cross_split")}
    source_stack_x, source_stack_y = [], []

    for number, obsid in enumerate(obsids, 1):
        with fits.open(aspect_paths[obsid], memmap=True) as hdul:
            aspect = hdul[1].data
            atime = np.asarray(aspect["timeMJD"], dtype=float)
            phi = np.asarray(aspect["phi"], dtype=float)
            theta = np.asarray(aspect["theta"], dtype=float)
            psi = np.asarray(aspect["psi"], dtype=float)
        matrices_all = rotation_matrices(phi, theta, psi)
        with fits.open(raw_paths[obsid], memmap=False) as hdul:
            events = hdul[1].data
            hdr = hdul[1].header
            exposure = float(hdr.get("EXPOSURE", hdr.get("ONTIME", len(atime))))
            pnt_ra = float(hdr["RA_PNT"])
            pnt_dec = float(hdr["DEC_PNT"])
            science = selected_science(events)
            codes_all = encode(events["chipx"], events["chipy"])
            codes = codes_all[science]
            times = np.asarray(events["time"][science], dtype=float)
            chipx = np.asarray(events["chipx"][science], dtype=float)
            chipy = np.asarray(events["chipy"][science], dtype=float)
        time_index = {float(t): i for i, t in enumerate(atime)}
        indices = np.array([time_index[float(t)] for t in times], dtype=int)
        ra, dec = transform_events_to_radec(chipx, chipy, phi[indices], theta[indices], psi[indices])
        dx, dy = tangent_offsets_arcmin(ra, dec, CRAB_RA_DEG, CRAB_DEC_DEG)
        source = (np.abs(dx) < BOX_HALF_ARCMIN) & (np.abs(dy) < BOX_HALF_ARCMIN)
        annulus = (np.hypot(dx, dy) >= ANNULUS_IN_ARCMIN) & (np.hypot(dx, dy) < ANNULUS_OUT_ARCMIN)
        replacement = ~np.isin(codes, np.fromiter(global_masks[obsid], dtype=np.int64))
        stack = replacement & (np.abs(dx) < 15) & (np.abs(dy) < 15)
        source_stack_x.append(dx[stack]); source_stack_y.append(dy[stack])

        scale = exposure / len(atime)
        footprint = footprint_counts(grid_vectors, matrices_all).astype(float) * scale
        total_exposure_map += footprint
        src_exp_area = float(np.sum(footprint[grid_source]) * cell_area)
        off_exp_area = float(np.sum(footprint[grid_annulus]) * cell_area)
        alpha = src_exp_area / off_exp_area
        keep = replacement
        non = int(np.sum(keep & source)); noff = int(np.sum(keep & annulus))
        commanded = float(angular_separation_arcmin(np.array([pnt_ra]), np.array([pnt_dec]), CRAB_RA_DEG, CRAB_DEC_DEG)[0])
        rows.append({
            "obsid": obsid, "date_obs": dates[obsid].isoformat(), "commanded_offset_arcmin": commanded,
            "exposure_s": exposure, "aspect_records_used": len(atime),
            "source_exposure_area": src_exp_area, "annulus_exposure_area": off_exp_area,
            "alpha_exposure": alpha, "non": non, "noff": noff, "net": non - alpha * noff,
            "net_variance": non + alpha * alpha * noff,
        })

        for name, mask_codes in (("global", global_masks[obsid]), ("loo", loo_masks[obsid]), ("cross_split", cross_masks[obsid])):
            removed_all = np.isin(codes_all, np.fromiter(mask_codes, dtype=np.int64))
            removal_audit[name]["all"] += int(np.sum(removed_all))
            removed = np.isin(codes, np.fromiter(mask_codes, dtype=np.int64))
            removal_audit[name]["science"] += int(np.sum(removed))
            removal_audit[name]["source"] += int(np.sum(removed & source))
        injection_inputs.append((obsid, matrices_all, commanded))
        if number % 20 == 0 or number == len(obsids):
            print(f"processed {number}/{len(obsids)}", flush=True)

    # Empirical positive-excess morphology on a 1 arcmin grid, then detector-mask injection.
    sx = np.concatenate(source_stack_x); sy = np.concatenate(source_stack_y)
    hist, yedges, xedges = np.histogram2d(sy, sx, bins=30, range=[[-15, 15], [-15, 15]])
    combined = aggregate_onoff(rows)
    background_per_cell = combined["noff"] / (math.pi * (ANNULUS_OUT_ARCMIN**2 - ANNULUS_IN_ARCMIN**2))
    excess = np.maximum(hist - background_per_cell, 0.0)
    if not np.any(excess):
        raise RuntimeError("No positive empirical excess cells available for injection")
    probabilities = excess.ravel() / np.sum(excess)
    rng = np.random.default_rng(20260820)
    injection_rows = []
    for obsid, matrices, commanded in injection_inputs:
        n = 5000
        chosen = rng.choice(len(probabilities), n, p=probabilities)
        iy, ix = np.unravel_index(chosen, excess.shape)
        dx = xedges[ix] + rng.random(n) * np.diff(xedges)[ix]
        dy = yedges[iy] + rng.random(n) * np.diff(yedges)[iy]
        aspect_choice = rng.integers(0, len(matrices), n)
        chipx, chipy, visible = inverse_to_chip(sky_vectors(dx, dy), matrices[aspect_choice])
        rounded_x = np.clip(np.rint(chipx[visible]).astype(int), 0, 1023)
        rounded_y = np.clip(np.rint(chipy[visible]).astype(int), 0, 1023)
        codes = encode(rounded_x, rounded_y)
        global_removed = np.isin(codes, np.fromiter(global_masks[obsid], dtype=np.int64))
        loo_removed = np.isin(codes, np.fromiter(loo_masks[obsid], dtype=np.int64))
        injection_rows.append({
            "obsid": obsid, "commanded_offset_arcmin": commanded, "injected": n,
            "visible": int(np.sum(visible)), "visibility_fraction": float(np.mean(visible)),
            "global_retention": float(1.0 - np.mean(global_removed)) if len(codes) else None,
            "loo_retention": float(1.0 - np.mean(loo_removed)) if len(codes) else None,
        })

    # Exposure/background adjusted WLS and a nearest-neighbour matched comparison.
    offsets = np.array([r["commanded_offset_arcmin"] for r in rows])
    live = np.array([r["exposure_s"] for r in rows])
    net = np.array([r["net"] for r in rows])
    variance = np.array([r["net_variance"] for r in rows])
    y = net / live * 1000.0
    yvar = variance / live**2 * 1e6
    bkg = np.array([r["noff"] / r["annulus_exposure_area"] * 1000.0 for r in rows])
    epoch = np.array([(dates[r["obsid"]] - dates[chronological[0]]).days for r in rows], dtype=float)
    bkg_z = (bkg - np.mean(bkg)) / np.std(bkg)
    epoch_z = (epoch - np.mean(epoch)) / np.std(epoch)
    x = np.column_stack((np.ones(len(rows)), offsets / 10.0, bkg_z, epoch_z))
    beta, se, _ = weighted_regression(x, y, yvar)
    slope_z = beta[1] / se[1]
    regression = {
        "offset_slope_counts_per_ks_per_10_arcmin": float(beta[1]),
        "offset_slope_hc3_se": float(se[1]), "offset_slope_z": float(slope_z),
        "offset_slope_two_sided_p": float(2 * norm.sf(abs(slope_z))),
        "covariates": ["intercept", "offset/10 arcmin", "standardised annular background", "standardised epoch"],
    }
    on_idx = np.flatnonzero(offsets < 10.0)
    far_idx = list(np.flatnonzero(offsets >= 42.0))
    feature = np.column_stack((np.log(np.maximum(live, 1.0)), np.log(np.maximum(bkg, 1e-12))))
    feature = (feature - feature.mean(axis=0)) / feature.std(axis=0)
    pairs = []
    for oi in on_idx:
        available = np.array(far_idx, dtype=int)
        distance = np.sum((feature[available] - feature[oi]) ** 2, axis=1)
        fi = int(available[np.argmin(distance)])
        far_idx.remove(fi)
        pairs.append((int(oi), fi))
    paired_diff = np.array([y[f] - y[o] for o, f in pairs])
    boot = np.array([np.mean(paired_diff[rng.integers(0, len(paired_diff), len(paired_diff))]) for _ in range(20000)])
    signs = rng.choice((-1.0, 1.0), size=(50000, len(paired_diff)))
    permutation = np.mean(np.abs(np.mean(signs * paired_diff, axis=1)) >= abs(np.mean(paired_diff)))
    matching = {
        "pairs": len(pairs), "matching_variables": ["log exposure", "log annular background density"],
        "far_minus_on_mean_rate_per_ks": float(np.mean(paired_diff)),
        "bootstrap_ci95": [float(np.quantile(boot, 0.025)), float(np.quantile(boot, 0.975))],
        "paired_sign_permutation_two_sided_p": float(permutation),
    }

    groups = {
        "on_axis": aggregate_onoff([r for r in rows if r["commanded_offset_arcmin"] < 10]),
        "intermediate": aggregate_onoff([r for r in rows if 10 <= r["commanded_offset_arcmin"] < 42]),
        "far_off_axis": aggregate_onoff([r for r in rows if r["commanded_offset_arcmin"] >= 42]),
        "all": combined,
    }
    all_injected_visible = sum(r["visible"] for r in injection_rows)
    weighted_global_retention = sum(r["visible"] * r["global_retention"] for r in injection_rows) / all_injected_visible
    weighted_loo_retention = sum(r["visible"] * r["loo_retention"] for r in injection_rows) / all_injected_visible
    loo_summary = {
        "global_catalogue_pixels": len(global_catalogue),
        "loo_catalogue_pixels_range": [min(map(len, loo_catalogues.values())), max(map(len, loo_catalogues.values()))],
        "loo_catalogue_jaccard_median": float(np.median(loo_jaccard)),
        "loo_catalogue_jaccard_min": float(np.min(loo_jaccard)),
        "early_catalogue_pixels": len(early_cat), "late_catalogue_pixels": len(late_cat),
        "early_late_jaccard": split_jaccard, "early_null_probability": early_p0, "late_null_probability": late_p0,
        "removal_audit": removal_audit,
    }
    grb_transfer = {}
    with fits.open(args.grb_file, memmap=True) as hdul:
        events = hdul[1].data
        sci = selected_science(events)
        codes = encode(events["chipx"], events["chipy"])
        grb_transfer = {
            "file": str(args.grb_file), "rows": len(events), "science_rows": int(np.sum(sci)),
            "science_rows_on_global_catalogue": int(np.sum(sci & np.isin(codes, np.fromiter(global_catalogue, dtype=np.int64)))),
            "limitation": "processed non-Crab observation; transfer check only, not independent catalogue construction",
        }
    summary = {
        "configuration": {
            "observations": len(obsids), "grid_arcmin": [-25, 25, float(grid_axis[1] - grid_axis[0])],
            "aspect_selection": "none; all matched aspect records are used",
            "exposure_definition": "event-file EXPOSURE",
            "exposure_map": "detector geometric footprint only; no vignetting/effective-area correction",
            "chronological_split": [early[0], early[-1], late[0], late[-1]],
        },
        "exposure_weighted_onoff": groups,
        "hotpixel_leave_one_out_and_split": loo_summary,
        "empirical_excess_injection": {
            "description": "positive background-subtracted 1-arcmin cells in the replacement-screened Crab stack, projected through all matched attitudes",
            "visible_injections": all_injected_visible, "global_mask_retention": weighted_global_retention,
            "loo_mask_retention": weighted_loo_retention,
        },
        "offaxis_adjusted_regression": regression,
        "offaxis_matched_pairs": matching,
        "noncrab_transfer": grb_transfer,
        "response_limitation": "No machine-readable ARF/RMF/RSP was found; response-aware flux or spectral fitting is not supported by the supplied files.",
    }
    with (args.output_dir / "advanced_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    with (args.output_dir / "advanced_per_observation.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    with (args.output_dir / "injection_per_observation.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(injection_rows[0])); w.writeheader(); w.writerows(injection_rows)

    plt.rcParams.update(
        {
            "font.size": 13.5,
            "axes.titlesize": 15.0,
            "axes.labelsize": 12.5,
            "xtick.labelsize": 11.5,
            "ytick.labelsize": 11.5,
            "legend.fontsize": 10.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 9.6), constrained_layout=True)
    ax = axes[0, 0]
    im = ax.imshow(total_exposure_map.reshape(gx.shape), origin="lower", extent=[-25, 25, -25, 25], cmap="viridis")
    ax.add_patch(plt.Rectangle((-5, -5), 10, 10, fill=False, color="white", lw=1.3))
    for radius in (8, 20): ax.add_patch(plt.Circle((0, 0), radius, fill=False, color="white", ls="--", lw=1.0))
    ax.set_title("Geometric footprint exposure"); ax.set_xlabel(r"$\Delta$RA cos(Dec) (arcmin)"); ax.set_ylabel(r"$\Delta$Dec (arcmin)")
    fig.colorbar(im, ax=ax, label="geometric exposure time (s)")

    ax = axes[0, 1]
    ax.hist(loo_jaccard, bins=16, color="#2166ac", alpha=0.85)
    ax.axvline(split_jaccard, color="#b2182b", ls="--", label=f"early/late = {split_jaccard:.3f}")
    ax.set_xlabel("Catalogue Jaccard index"); ax.set_ylabel("Held-out observations")
    ax.set_title("Hot-pixel catalogue stability"); ax.legend()

    ax = axes[1, 0]
    inj_offset = np.array([r["commanded_offset_arcmin"] for r in injection_rows])
    inj_ret = np.array([r["loo_retention"] for r in injection_rows]) * 100
    ax.scatter(inj_offset, inj_ret, s=18, alpha=0.72, color="#1b9e77")
    ax.axhline(weighted_loo_retention * 100, color="black", ls="--", label=f"weighted {weighted_loo_retention*100:.3f}%")
    ax.set_xlabel("Commanded offset (arcmin)"); ax.set_ylabel("Injected photons retained (%)")
    ax.set_title("Empirical-excess detector-mask injection"); ax.legend()

    ax = axes[1, 1]
    ax.errorbar(offsets, y, yerr=np.sqrt(yvar), fmt="o", ms=3.7, alpha=0.52, color="#4d4d4d")
    reference_bkg = 0.0; reference_epoch = 0.0
    line_x = np.linspace(0, max(offsets), 150)
    line_y = beta[0] + beta[1] * line_x / 10 + beta[2] * reference_bkg + beta[3] * reference_epoch
    ax.plot(line_x, line_y, color="#d73027", lw=1.8, label=f"adjusted slope {beta[1]:.2f}±{se[1]:.2f} /10'")
    ax.axhline(0, color="black", lw=0.7); ax.set_xlabel("Commanded offset (arcmin)"); ax.set_ylabel("Exposure-weighted net rate (counts ks$^{-1}$)")
    ax.set_title("Off-axis adjusted regression"); ax.legend()
    fig.savefig(args.output_dir / "advanced_crab_validation.pdf")
    plt.close(fig)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
