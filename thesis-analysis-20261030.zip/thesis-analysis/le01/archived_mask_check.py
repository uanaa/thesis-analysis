"""Integrate fixed archived masks; load only your locally generated cache."""
from pathlib import Path
import sys,pickle,json,math,numpy as np
from astropy.io import fits
from paths import DATA_ROOT as R, OUTPUT as O
import advanced_crab_validation as a
import crab_end_to_end_validation as c
D=pickle.loads((O/'common_crab_data.pkl').read_bytes());rng=np.random.default_rng(20261030); masks={}
for o in D:
 oid=o['obsid']
 with fits.open(R/f'hotpixel/Crab_evtlist copy 3/{oid}_evt1file.fits',memmap=False) as h:raw=np.unique(c.encode(h[1].data['chipx'],h[1].data['chipy']))
 with fits.open(R/f'hotpixel/Crab_htpix_evtlist/{oid}_evt1_5file.fits',memmap=False) as h:kept=np.unique(c.encode(h[1].data['chipx'],h[1].data['chipy']))
 masks[oid]=np.setdiff1d(raw,kept)
# Monte Carlo integration over recorded attitudes and sky region. Fixed masks, not mask selection.
N=100000; sums={k:0. for k in ['src_geom','src_live']};shapes={str(f):dict(weighted_on=0.,weighted_kept=0.,trials=0,lost=0) for f in [5,10,20]};rad_edges=[8,14,16,18,20,22,25];bg=[dict(inner=8,outer=r,geom=0.,live=0.) for r in rad_edges[1:]];shell=[dict(inner=l,outer=r,geom=0.,live=0.) for l,r in zip(rad_edges[:-1],rad_edges[1:])]
def keep(o,dx,dy):
 ii=rng.integers(0,len(o['mats']),len(dx));cx,cy,v=a.inverse_to_chip(a.sky_vectors(dx,dy),o['mats'][ii]);codes=np.full(len(dx),-1,dtype=int);codes[v]=np.clip(np.rint(cx[v]),0,1023).astype(int)*2048+np.clip(np.rint(cy[v]),0,1023).astype(int);live=v&~np.isin(codes,masks[o['obsid']]);return v,live
for j,o in enumerate(D):
 ex=o['exposure'];dx=rng.uniform(-5,5,N);dy=rng.uniform(-5,5,N);v,l=keep(o,dx,dy);sums['src_geom']+=100*ex*v.mean();sums['src_live']+=100*ex*l.mean()
 # uniform disk annulus from 8 to 25 arcmin
 rr=np.sqrt(rng.uniform(8**2,25**2,N));ph=rng.uniform(0,2*np.pi,N);v,l=keep(o,rr*np.cos(ph),rr*np.sin(ph));area=np.pi*(25**2-8**2)
 for row in bg+shell:
  m=(rr>=row['inner'])&(rr<row['outer']);row['geom']+=area*ex*(v&m).mean();row['live']+=area*ex*(l&m).mean()
 for f,row in shapes.items():
  n=30000;s=float(f)/2.354820045;dx=rng.normal(0,s,n);dy=rng.normal(0,s,n);v,l=keep(o,dx,dy);row['weighted_on']+=ex*v.mean();row['weighted_kept']+=ex*l.mean();row['trials']+=int(v.sum());row['lost']+=int((v&~l).sum())
 if (j+1)%20==0:print('mask/area integration',j+1,flush=True)
dx=np.concatenate([o['dx'][o['old']] for o in D]);dy=np.concatenate([o['dy'][o['old']] for o in D]);rr=np.hypot(dx,dy);non=int(((abs(dx)<5)&(abs(dy)<5)).sum())
for row in bg+shell:
 row['counts']=int(((rr>=row['inner'])&(rr<row['outer'])).sum());row['live_fraction']=row['live']/row['geom'];row['surface_count_rate']=row['counts']/row['live']
for row in bg:
 alpha=sums['src_live']/row['live'];row['alpha_mask_corrected']=alpha;row['net']=non-alpha*row['counts'];row['li_ma']=float(c.li_ma(non,row['counts'],alpha))
for row in shapes.values():row['conditional_retention']=row['weighted_kept']/row['weighted_on']
res=dict(method='Fixed archived masks from complete raw/screened coordinate sets; uniform draws from all recorded attitudes weighted by observation exposure. Gaussian profiles are illustrative angular source shapes, not calibrated PSFs. No vignetting/response correction.',rng_seed=20261030,samples_per_obs_region=N,source=sums,source_live_fraction=sums['src_live']/sums['src_geom'],gaussian_fwhm_arcmin=shapes,annuli=bg,radial_shells=shell)
(O/'crab_archived_mask_check.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
