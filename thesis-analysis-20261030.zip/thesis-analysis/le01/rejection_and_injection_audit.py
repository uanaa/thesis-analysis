"""Detector-event audit and injected-event re-screening, using original raw data.
No source FITS modified. Injected events test screening losses, not detection efficiency.
"""
from pathlib import Path
from paths import DATA_ROOT as ROOT, OUTPUT as OUT, MASK_DIR
from collections import Counter,defaultdict
import pickle,json,csv,sys,math
import numpy as np
from astropy.io import fits
import robust_hot_pixel_filter as detector
import advanced_crab_validation as a
import crab_end_to_end_validation as c
D=pickle.loads((OUT/'common_crab_data.pkl').read_bytes()); ids=[o['obsid'] for o in D]; byid={o['obsid']:o for o in D}
RAW=ROOT/'hotpixel/Crab_evtlist copy 3'; MASK=MASK_DIR
# Archive the actual pixel/time concentration of rejected quality-selected events.
perobs=[]; aggregate={m:Counter() for m in ['old','new']}; rankcounts={m:np.zeros(4,dtype=int) for m in ['old','new']}; rejectn={m:0 for m in ['old','new']}; topbins={m:0 for m in ['old','new']}; allbins={m:0 for m in ['old','new']}
for o in D:
    target=np.repeat(a.sky_vectors([0],[0]),len(o['mats']),axis=0); cx,cy,vis=a.inverse_to_chip(target,o['mats'])
    for method in ['old','new']:
        rejected=~o[method];codes,count=np.unique(o['codes'][rejected],return_counts=True);aggregate[method].update(dict(zip(codes.tolist(),count.tolist())));sort=np.sort(count)[::-1];cum=sort.cumsum();n=int(count.sum());rejectn[method]+=n
        times=o['times'][rejected]; totalspan=o['aspect_times'].max()-o['aspect_times'].min();binidx=np.floor((times-o['aspect_times'].min())/32).astype(int);_,bc=np.unique(binidx,return_counts=True)
        min_dist=np.array([np.hypot(cx[vis]-code//2048,cy[vis]-code%2048).min() for code in codes])
        weightedtrack=[int(count[min_dist<r].sum()) for r in [1,3,5,10]]
        rankcounts[method]+=weightedtrack
        perobs.append(dict(obsid=o['obsid'],screen=method,rejected_events=n,rejected_pixels=len(codes),pixels_for_50_percent=int(np.searchsorted(cum,n*.5)+1),pixels_for_90_percent=int(np.searchsorted(cum,n*.9)+1),largest_pixel_count=int(sort[0]),max_32s_bin_fraction=float(bc.max()/n),occupied_32s_bins=len(bc),source_track_span_pixels=float(np.hypot(np.ptp(cx[vis]),np.ptp(cy[vis]))),**{f'rejected_events_in_pixels_ever_within_{r}px_of_track':v for r,v in zip([1,3,5,10],weightedtrack)}))
with (OUT/'rejected_event_pixel_audit.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=perobs[0]);w.writeheader();w.writerows(perobs)
report={}
for method in ['old','new']:
    counts=np.array(sorted(aggregate[method].values(),reverse=True));rows=[r for r in perobs if r['screen']==method]
    report[method]=dict(rejected_science_events=rejectn[method],unique_rejected_coordinates=len(counts),top_10_coordinate_fraction=float(counts[:10].sum()/counts.sum()),top_100_coordinate_fraction=float(counts[:100].sum()/counts.sum()),coordinates_for_90_percent=int(np.searchsorted(counts.cumsum(),counts.sum()*.9)+1),median_rejected_pixels_per_observation=float(np.median([r['rejected_pixels'] for r in rows])),median_pixels_for_90_percent_per_observation=float(np.median([r['pixels_for_90_percent'] for r in rows])),median_largest_32s_bin_fraction=float(np.median([r['max_32s_bin_fraction'] for r in rows])),median_target_track_span_pixels=float(np.median([r['source_track_span_pixels'] for r in rows])),events_in_pixels_ever_near_target_track={str(r):int(v) for r,v in zip([1,3,5,10],rankcounts[method])})
(OUT/'rejected_event_pixel_audit.json').write_text(json.dumps(report,indent=2));print('pixel audit',json.dumps(report),flush=True)
# Exact baseline reproduction before injection.
initial=defaultdict(set)
with (MASK/'initial_candidates.csv').open() as f:
    for row in csv.DictReader(f):initial[row['obsid']].add(int(row['chipx'])*2048+int(row['chipy']))
raws={};headers={};baseline={};basic_dtype=[('chipx','i4'),('chipy','i4'),('time','f8')]
for num,oid in enumerate(ids,1):
    with fits.open(RAW/f'{oid}_evt1file.fits',memmap=False) as h:
        raw=h[1].data;headers[oid]=h[1].header.copy();simple=np.empty(len(raw),dtype=basic_dtype)
        for field in simple.dtype.names:simple[field]=raw[field]
    raws[oid]=simple
    candidates,diag=detector.detect_hot_pixels(simple,headers[oid]);codes={r['chipx']*2048+r['chipy'] for r in candidates}
    assert codes==initial[oid],(oid,len(codes),len(initial[oid]));baseline[oid]=codes
    if num%20==0:print('baseline reproduced',num,flush=True)
basecat,_=a.bh_catalogue(baseline,ids,20);assert len(basecat)==1348,len(basecat)
# Empirical source templates are built separately for each screen on 1-arcmin cells.
templates={}
for method in ['old','new']:
    dx=np.concatenate([o['dx'][o[method]] for o in D]);dy=np.concatenate([o['dy'][o[method]] for o in D]);r=np.hypot(dx,dy)
    hist,yedge,xedge=np.histogram2d(dy,dx,bins=30,range=[[-15,15],[-15,15]]);b=((r>=8)&(r<20)).sum()/(math.pi*(20**2-8**2));excess=np.maximum(hist-b,0);templates[method]=(excess.ravel()/excess.sum(),xedge,yedge)
rng=np.random.default_rng(20261023);rows=[];trials=5;sumexp=sum(o['exposure'] for o in D)
for shape in ['old','new']:
    probabilities,xe,ye=templates[shape]
    for expected_total in [100,300]:
        for trial in range(trials):
            candidates={k:v.copy() for k,v in baseline.items()};injected={};drawn=0;visible_total=0
            for oid in ids:
                o=byid[oid];n=int(rng.poisson(expected_total*o['exposure']/sumexp));drawn+=n
                if n==0:continue
                chosen=rng.choice(900,n,p=probabilities);iy,ix=np.unravel_index(chosen,(30,30));dx=xe[ix]+rng.random(n);dy=ye[iy]+rng.random(n);aspect_idx=rng.integers(0,len(o['mats']),n)
                cx,cy,vis=a.inverse_to_chip(a.sky_vectors(dx,dy),o['mats'][aspect_idx]);cx=np.clip(np.rint(cx[vis]),0,1023).astype(int);cy=np.clip(np.rint(cy[vis]),0,1023).astype(int)
                inj=np.empty(len(cx),dtype=basic_dtype);inj['chipx']=cx;inj['chipy']=cy;inj['time']=o['aspect_times'][aspect_idx[vis]];visible_total+=len(cx)
                if len(cx)==0:continue
                raw=np.concatenate((raws[oid],inj));detected,_=detector.detect_hot_pixels(raw,headers[oid]);candidates[oid]={r['chipx']*2048+r['chipy'] for r in detected};injected[oid]=detector.encode(cx,cy)
            cat,_=a.bh_catalogue(candidates,ids,20);fixed_removed=0;rerun_removed=0
            for oid,codes in injected.items():
                fixed_removed+=int(np.isin(codes,list(baseline[oid]&basecat)).sum());rerun_removed+=int(np.isin(codes,list(candidates[oid]&cat)).sum())
            changed=sum(len((baseline[oid]&basecat)^(candidates[oid]&cat)) for oid in ids)
            row=dict(template_screen=shape,expected_total=expected_total,trial=trial,drawn=drawn,landed_on_detector=visible_total,new_fixed_mask_removed=fixed_removed,new_rerun_removed=rerun_removed,new_rerun_retained=visible_total-rerun_removed,catalogue_pixels=len(cat),changed_mask_pixel_observations=changed);rows.append(row);print('injection',json.dumps(row),flush=True)
            with (OUT/'injection_rescreen_trials.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
summary={'baseline_reproduced_all_104_observations':True,'baseline_catalogue_pixels':1348,'seed':20261023,'replicates_per_shape_and_strength':trials,'method':'Poisson numbers across 104 observations weighted by header exposure; sample empirical 30x30 arcmin template; project using a uniformly drawn recorded aspect time; append event positions and times to original raw detector tables; rerun pixel candidate detection and global recurrence+BH catalogue; count injected events surviving the resulting masks. Injected events represent the common energy/grade-selected population.','scope':'Retention of synthetic events under empirical source shapes, not probability of detecting a source or calibrated PSF completeness. Old screening algorithm is unavailable; only the new screening algorithm can be rerun.','groups':[]}
for shape in ['old','new']:
    for strength in [100,300]:
        selected=[r for r in rows if r['template_screen']==shape and r['expected_total']==strength];land=sum(r['landed_on_detector'] for r in selected);removed=sum(r['new_rerun_removed'] for r in selected)
        summary['groups'].append(dict(template_screen=shape,expected_total=strength,drawn=sum(r['drawn'] for r in selected),landed=land,rerun_removed=removed,retention=1-removed/land,fixed_mask_removed=sum(r['new_fixed_mask_removed'] for r in selected),changed_mask_pixel_observations=sum(r['changed_mask_pixel_observations'] for r in selected)))
(OUT/'injection_rescreen_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
