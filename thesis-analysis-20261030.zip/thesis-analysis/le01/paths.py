"""Paths shared by the adopted paired-screen scripts."""
import os
from pathlib import Path
REPO = Path(__file__).resolve().parents[1]
DATA_ROOT = Path(os.environ.get("LE01_DATA_ROOT", REPO / "data/le01")).expanduser().resolve()
OUTPUT = Path(os.environ.get("LE01_OUTPUT_DIR", REPO / "outputs/le01")).expanduser().resolve()
OUTPUT.mkdir(parents=True, exist_ok=True)
MASK_DIR = Path(os.environ.get("LE01_MASK_DIR", OUTPUT / "mask")).expanduser().resolve()
