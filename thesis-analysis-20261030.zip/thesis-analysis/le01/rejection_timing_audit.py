from pathlib import Path
from collections import Counter
import pickle,json
import numpy as np
from paths import OUTPUT as P
D=pickle.loads((P/'common_crab_data.pkl').read_bytes());out={}
for method in ['old','new']:
 total=0;wide=0;sources=Counter();pixel_recurrence=Counter();spans=[];weights=[]
 for o in D:
  rejected=~o[method];code=o['codes'][rejected];times=o['times'][rejected];uni,inv,cnt=np.unique(code,return_inverse=True,return_counts=True)
  tmin=np.full(len(uni),np.inf);tmax=np.full(len(uni),-np.inf);np.minimum.at(tmin,inv,times);np.maximum.at(tmax,inv,times)
  span=(tmax-tmin)/(o['aspect_times'].max()-o['aspect_times'].min());total+=int(cnt.sum());wide+=int(cnt[span>=.8].sum());spans.extend(span);weights.extend(cnt)
  pixel_recurrence.update(uni.tolist())
  src=(abs(o['dx'])<5)&(abs(o['dy'])<5)&rejected;u,n=np.unique(o['codes'][src],return_counts=True);sources.update(dict(zip(u.tolist(),n.tolist())))
 top=sources.most_common(10);sc=sum(sources.values());counts=np.array(sorted(sources.values(),reverse=True));allweights=np.array(weights);allspans=np.array(spans);idx=np.argsort(allspans);median=allspans[idx[np.searchsorted(allweights[idx].cumsum(),allweights.sum()/2)]]
 out[method]={'fraction_rejected_events_at_pixels_spanning_at_least_80percent_observation':wide/total,'event_weighted_median_pixel_activity_span_fraction':float(median),'source_box_rejected_events':sc,'source_box_rejected_detector_coordinates':len(sources),'source_box_top_10_coordinate_fraction':sum(v for _,v in top)/sc,'source_box_coordinates_for_90percent':int(np.searchsorted(counts.cumsum(),sc*.9)+1),'top_source_box_coordinates':[{'chipx':int(k//2048),'chipy':int(k%2048),'rejected_source_box_events':v,'observations_flagged_with_science_events':pixel_recurrence[k]} for k,v in top]}
(P/'rejection_timing_audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
