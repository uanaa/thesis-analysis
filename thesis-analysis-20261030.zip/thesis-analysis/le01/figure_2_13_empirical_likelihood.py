#!/usr/bin/env python3
"""Build a bounded, event-level source-position diagnostic for LE01 ObsID 100018.

The plotted source template is constructed from the other 103 Crab observations
after the common energy, grade, and replacement hot-pixel selections. All
aspect records are used to transform detector coordinates to sky coordinates;
no median--MAD aspect-record screening is applied.
It is an empirical morphology for a diagnostic likelihood map, not a calibrated
position- or energy-dependent PSF and not a blind-source detection calibration.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
from matplotlib.colors import BoundaryNorm
from scipy.ndimage import gaussian_filter
from scipy.optimize import minimize


CRAB_RA_DEG = 83.63308333333333
CRAB_DEC_DEG = 22.0145
VALID_GRADES = np.array([0, 2, 3, 4, 6])
COORD_BASE = 2048
TARGET_OBSID = "100018"
COUNT_FIELD_HALF_ARCMIN = 60
TEMPLATE_HALF_ARCMIN = 15
SCAN_HALF_ARCMIN = COUNT_FIELD_HALF_ARCMIN - TEMPLATE_HALF_ARCMIN


def transform_events_to_radec(chipx, chipy, phi_deg, theta_deg, psi_deg):
    tdetx_mm = (chipx - 512.0) / 1024.0 * 13.3
    tdety_mm = (512.0 - chipy) / 1024.0 * 13.3
    norm = np.sqrt(tdetx_mm**2 + tdety_mm**2 + 375.0**2)
    r0 = np.column_stack((tdetx_mm / norm, tdety_mm / norm, 375.0 / norm))
    phi = np.deg2rad(phi_deg)
    theta = np.deg2rad(theta_deg)
    psi = np.deg2rad(psi_deg)
    cp, sp = np.cos(phi), np.sin(phi)
    ct, st = np.cos(theta), np.sin(theta)
    cs, ss = np.cos(psi), np.sin(psi)
    rb_x = r0[:, 0] * (ct * cs - st * sp * ss) + r0[:, 1] * (-cp * ss) + r0[:, 2] * (
        st * cs + ct * sp * ss
    )
    rb_y = r0[:, 0] * (ct * ss + st * sp * cs) + r0[:, 1] * (cp * cs) + r0[:, 2] * (
        st * ss - ct * sp * cs
    )
    rb_z = r0[:, 0] * (-st * cp) + r0[:, 1] * sp + r0[:, 2] * (ct * cp)
    ra = np.rad2deg(np.arctan2(rb_y, rb_x)) % 360.0
    dec = np.rad2deg(np.arcsin(np.clip(rb_z, -1.0, 1.0)))
    return ra, dec


def tangent_offsets_arcmin(ra, dec):
    dra = (np.asarray(ra) - CRAB_RA_DEG + 180.0) % 360.0 - 180.0
    dx = dra * math.cos(math.radians(CRAB_DEC_DEG)) * 60.0
    dy = (np.asarray(dec) - CRAB_DEC_DEG) * 60.0
    return dx, dy


def encode(chipx, chipy):
    return np.asarray(chipx, dtype=np.int64) * COORD_BASE + np.asarray(
        chipy, dtype=np.int64
    )


def read_replacement_codes(initial_path, catalogue_path):
    with catalogue_path.open(newline="", encoding="utf-8") as stream:
        catalogue = {
            int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            for row in csv.DictReader(stream)
        }
    by_obs = defaultdict(set)
    with initial_path.open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            code = int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            if code in catalogue:
                by_obs[row["obsid"]].add(code)
    return by_obs


def load_selected_offsets(raw_path, aspect_path, rejected_codes):
    with fits.open(aspect_path, memmap=True) as hdul:
        aspect = hdul[1].data
        times = np.asarray(aspect["timeMJD"], dtype=float)
        phi = np.asarray(aspect["phi"], dtype=float)
        theta = np.asarray(aspect["theta"], dtype=float)
        psi = np.asarray(aspect["psi"], dtype=float)
    time_index = {float(time): index for index, time in enumerate(times)}

    with fits.open(raw_path, memmap=False) as hdul:
        events = hdul[1].data
        science = (
            np.isfinite(events["energy"])
            & (events["energy"] > 1.0)
            & (events["energy"] < 10.0)
            & np.isin(events["grade"], VALID_GRADES)
        )
        selected_times = np.asarray(events["time"][science], dtype=float)
        chipx = np.asarray(events["chipx"][science], dtype=float)
        chipy = np.asarray(events["chipy"][science], dtype=float)
        codes = encode(chipx, chipy)

    indices = np.array([time_index[float(time)] for time in selected_times], dtype=int)
    keep = np.ones(len(indices), dtype=bool)
    if rejected_codes:
        keep &= ~np.isin(codes, np.fromiter(rejected_codes, dtype=np.int64))
    ra, dec = transform_events_to_radec(
        chipx[keep], chipy[keep], phi[indices[keep]], theta[indices[keep]], psi[indices[keep]]
    )
    return tangent_offsets_arcmin(ra, dec), len(times)


def loglike_poisson(data, model):
    model = np.maximum(model, 1.0e-12)
    return float(np.sum(data * np.log(model) - model))


def template_likelihood(patch, template):
    data = np.asarray(patch, dtype=float).ravel()
    shape = np.asarray(template, dtype=float).ravel()
    background0 = max(float(np.mean(data)), 1.0e-6)
    null_loglike = loglike_poisson(data, np.full_like(data, background0))

    low_template = shape <= np.quantile(shape, 0.60)
    background_start = max(float(np.mean(data[low_template])), 1.0e-4)
    source_start = max(float(np.sum(data) - background_start * len(data)), 0.5)

    def objective(parameters):
        background, source_counts = parameters
        return -loglike_poisson(data, background + source_counts * shape)

    fit = minimize(
        objective,
        x0=np.array([background_start, source_start]),
        method="L-BFGS-B",
        bounds=((1.0e-9, None), (0.0, None)),
    )
    background, source_counts = fit.x
    alternative_loglike = -float(fit.fun)
    ts = max(0.0, 2.0 * (alternative_loglike - null_loglike))
    return ts, float(source_counts), float(background), bool(fit.success)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--aspect-dir", type=Path, required=True)
    parser.add_argument("--initial-candidates", type=Path, required=True)
    parser.add_argument("--catalogue", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--template-sigma", type=float, default=0.0)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    rejected = read_replacement_codes(args.initial_candidates, args.catalogue)
    raw_paths = {p.name.split("_")[0]: p for p in args.raw_dir.glob("*_evt1file.fits")}
    aspect_paths = {p.stem.split("_")[1]: p for p in args.aspect_dir.glob("aspect_*.fits")}
    obsids = sorted(set(raw_paths) & set(aspect_paths))
    if TARGET_OBSID not in obsids or len(obsids) != 104:
        raise RuntimeError(f"Expected the common 104-observation sample; found {len(obsids)}")

    map_edges = np.arange(
        -COUNT_FIELD_HALF_ARCMIN - 0.5,
        COUNT_FIELD_HALF_ARCMIN + 1.5,
        1.0,
    )
    template_edges = np.arange(
        -TEMPLATE_HALF_ARCMIN - 0.5,
        TEMPLATE_HALF_ARCMIN + 1.5,
        1.0,
    )
    template_size = 2 * TEMPLATE_HALF_ARCMIN + 1
    training_counts = np.zeros((template_size, template_size), dtype=float)
    training_annulus_counts = 0
    target_dx = target_dy = None
    target_aspect_rows = None
    audit = []

    for number, obsid in enumerate(obsids, 1):
        (dx, dy), n_aspect = load_selected_offsets(
            raw_paths[obsid], aspect_paths[obsid], rejected.get(obsid, set())
        )
        audit.append(
            {
                "obsid": obsid,
                "selected_events": len(dx),
                "aspect_rows_used": n_aspect,
                "aspect_selection": "none",
            }
        )
        if obsid == TARGET_OBSID:
            target_dx, target_dy = dx, dy
            target_aspect_rows = n_aspect
        else:
            training_counts += np.histogram2d(dy, dx, bins=(template_edges, template_edges))[0]
            radius = np.hypot(dx, dy)
            training_annulus_counts += int(np.sum((radius >= 8.0) & (radius < 20.0)))
        if number % 20 == 0 or number == len(obsids):
            print(f"loaded {number}/{len(obsids)}", flush=True)

    annulus_area = math.pi * (20.0**2 - 8.0**2)
    background_per_cell = training_annulus_counts / annulus_area
    excess = np.maximum(training_counts - background_per_cell, 0.0)
    template = gaussian_filter(excess, sigma=args.template_sigma, mode="constant")
    if not np.any(template > 0):
        raise RuntimeError("The empirical template has no positive cells")
    template /= np.sum(template)

    target_map = np.histogram2d(target_dy, target_dx, bins=(map_edges, map_edges))[0]
    scan_centres = np.arange(-SCAN_HALF_ARCMIN, SCAN_HALF_ARCMIN + 1, dtype=int)
    scan_size = len(scan_centres)
    ts_map = np.zeros((scan_size, scan_size), dtype=float)
    source_map = np.zeros_like(ts_map)
    background_map = np.zeros_like(ts_map)
    successful = np.zeros_like(ts_map, dtype=bool)
    half = TEMPLATE_HALF_ARCMIN
    for iy, centre_y in enumerate(scan_centres):
        cy = centre_y + COUNT_FIELD_HALF_ARCMIN
        for ix, centre_x in enumerate(scan_centres):
            cx = centre_x + COUNT_FIELD_HALF_ARCMIN
            patch = target_map[cy - half : cy + half + 1, cx - half : cx + half + 1]
            ts, source_counts, background, success = template_likelihood(patch, template)
            ts_map[iy, ix] = ts
            source_map[iy, ix] = source_counts
            background_map[iy, ix] = background
            successful[iy, ix] = success

    target_index = int(np.where(scan_centres == 0)[0][0])
    target_ts = float(ts_map[target_index, target_index])
    target_source = float(source_map[target_index, target_index])
    target_background = float(background_map[target_index, target_index])
    control_mask = np.hypot(*np.meshgrid(scan_centres, scan_centres)) >= 8.0
    control_ts = ts_map[control_mask]
    empirical_rank = float((1 + np.sum(control_ts >= target_ts)) / (1 + len(control_ts)))
    maximum_location = np.unravel_index(np.argmax(ts_map), ts_map.shape)
    maximum_x = int(scan_centres[maximum_location[1]])
    maximum_y = int(scan_centres[maximum_location[0]])

    plt.rcParams.update(
        {
            "font.size": 18.0,
            "axes.titlesize": 18.0,
            "axes.labelsize": 17.0,
            "xtick.labelsize": 15.0,
            "ytick.labelsize": 15.0,
            "legend.fontsize": 14.5,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig, ax = plt.subplots(1, 1, figsize=(7.8, 6.6), constrained_layout=True)
    smoothing_title = (
        "no spatial smoothing"
        if args.template_sigma == 0
        else rf"Gaussian smoothing $\sigma={args.template_sigma:g}'$"
    )
    im = ax.imshow(
        ts_map,
        origin="lower",
        extent=(
            -SCAN_HALF_ARCMIN - 0.5,
            SCAN_HALF_ARCMIN + 0.5,
            -SCAN_HALF_ARCMIN - 0.5,
            SCAN_HALF_ARCMIN + 0.5,
        ),
        cmap="viridis",
        interpolation="nearest",
        aspect="equal",
    )
    ax.scatter(
        0,
        0,
        marker="+",
        s=190,
        linewidth=2.6,
        color="#18d6ad",
        label=rf"Crab coordinate ($\Delta C={target_ts:.2f}$)",
        zorder=5,
    )
    ax.scatter(
        maximum_x,
        maximum_y,
        marker="X",
        s=145,
        linewidth=0.9,
        facecolor="#ffcf33",
        edgecolor="#6b4500",
        label="Highest-score candidate",
        zorder=6,
    )
    ax.set_title(
        rf"Empirical-template $\Delta C$ map ({smoothing_title}; $1'$ trial grid)"
    )
    ax.set_xlabel(r"Trial-position $\Delta$RA cos(Dec) (arcmin)")
    ax.set_ylabel(r"Trial-position $\Delta$Dec (arcmin)")
    ax.set_xlim(SCAN_HALF_ARCMIN + 0.5, -SCAN_HALF_ARCMIN - 0.5)
    ax.set_ylim(-SCAN_HALF_ARCMIN - 0.5, SCAN_HALF_ARCMIN + 0.5)
    ax.legend(loc="upper left", frameon=True, framealpha=0.92)
    fig.colorbar(im, ax=ax, label=r"Poisson likelihood ratio, $\Delta C$", shrink=0.92)

    figure_pdf = args.output_dir / "Figure_2_13_empirical_likelihood.pdf"
    figure_png = args.output_dir / "Figure_2_13_empirical_likelihood.png"
    fig.savefig(figure_pdf, bbox_inches="tight")
    fig.savefig(figure_png, dpi=220, bbox_inches="tight")
    plt.close(fig)

    np.savez_compressed(
        args.output_dir / "figure_2_13_arrays.npz",
        map_edges=map_edges,
        target_count_map=target_map,
        template_edges=template_edges,
        empirical_template=template,
        scan_centres_arcmin=scan_centres,
        delta_c_map=ts_map,
        fitted_source_count_map=source_map,
        fitted_background_per_cell_map=background_map,
    )

    with (args.output_dir / "figure_2_13_observation_audit.csv").open(
        "w", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(audit[0]))
        writer.writeheader()
        writer.writerows(audit)

    summary = {
        "target_obsid": TARGET_OBSID,
        "sample_observations": len(obsids),
        "template_training_observations": len(obsids) - 1,
        "selection": {"energy_keV": "1 < E < 10", "grades": VALID_GRADES.tolist()},
        "target_selected_events_full_field": len(target_dx),
        "target_aspect_rows_used": target_aspect_rows,
        "aspect_selection": "none; all matched aspect records are used for coordinate transformation",
        "target_counts_within_60_arcmin_square": int(np.sum(target_map)),
        "count_field": "1 arcmin cells over +/-60 arcmin",
        "trial_position_grid": "1 arcmin centres over +/-45 arcmin",
        "template_grid": "1 arcmin cells over +/-15 arcmin",
        "template_gaussian_sigma_cell": args.template_sigma,
        "template_background_counts_8_20_arcmin": training_annulus_counts,
        "template_background_per_1arcmin_cell": background_per_cell,
        "target_delta_c": target_ts,
        "target_fitted_template_counts": target_source,
        "target_fitted_background_per_cell": target_background,
        "shifted_position_fraction_ge_target": empirical_rank,
        "shifted_position_count": int(len(control_ts)),
        "map_maximum": {"dx_arcmin": maximum_x, "dy_arcmin": maximum_y, "delta_c": float(np.max(ts_map))},
        "fit_success_fraction": float(np.mean(successful)),
        "interpretation": (
            "The leave-one-observation-out template is target-derived and lacks calibrated exposure, "
            "vignetting, and position-dependent PSF corrections. Delta C and the shifted-position rank "
            "are diagnostic quantities, not a calibrated blind-search significance or false-alarm probability."
        ),
    }
    (args.output_dir / "figure_2_13_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
