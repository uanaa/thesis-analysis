from pathlib import Path
import numpy as np,sys,json
from scipy.optimize import minimize_scalar
from paths import OUTPUT as P
import figure_2_13_empirical_likelihood as m
arrays=dict(np.load(P/'position_old_arrays.npz'));template=arrays['template'];target=arrays['target_map'];failed=[]
for iy,y in enumerate(range(-45,46)):
 for ix,x in enumerate(range(-45,46)):
  patch=target[y+45:y+76,x+45:x+76];score,source,bg,success=m.template_likelihood(patch,template)
  if not success:
   data=patch.ravel();shape=template.ravel();N=data.sum();K=len(data)
   objective=lambda f:-m.loglike_poisson(data,N*((1-f)/K+f*shape))
   fit=minimize_scalar(objective,bounds=(0,1),method='bounded',options={'xatol':1e-12})
   choices=[(0.,objective(0.)),(1.,objective(1.)),(float(fit.x),float(fit.fun))];fraction,value=min(choices,key=lambda t:t[1]);ts=max(0.,2*(-value-m.loglike_poisson(data,np.full(K,N/K))))
   failed.append(dict(dx_arcmin=x,dy_arcmin=y,original_delta_c=score,retried_delta_c=ts,source_fraction=fraction,success=bool(fit.success)))
   arrays['ts'][iy,ix]=ts;arrays['source'][iy,ix]=N*fraction;arrays['background'][iy,ix]=N*(1-fraction)/K
 if failed:break
assert len(failed)==1
np.savez_compressed(P/'position_old_arrays.npz',**arrays)
r=json.loads((P/'position_old_summary.json').read_text());r['fit_success_fraction']=1.0;r['optimizer_retry']=failed;(P/'position_old_summary.json').write_text(json.dumps(r,indent=2));(P/'position_optimizer_retry.json').write_text(json.dumps(failed,indent=2));print(failed)
