#!/usr/bin/env python3
"""Apply the conservative persistent hot-pixel catalogue to one LE01 event file."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
from astropy.io import fits

from robust_hot_pixel_filter import COORD_BASE, DetectionConfig, detect_hot_pixels, encode


def read_catalog(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return {
            int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            for row in csv.DictReader(handle)
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("catalog", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    catalog = read_catalog(args.catalog)
    with fits.open(args.input, memmap=False) as hdul:
        events = hdul[1].data
        candidates, diagnostics = detect_hot_pixels(events, hdul[1].header, DetectionConfig())
        candidate_codes = {
            int(row["chipx"]) * COORD_BASE + int(row["chipy"])
            for row in candidates
        }
        final_codes = candidate_codes & catalog
        event_codes = encode(events["chipx"], events["chipy"])
        remove = np.isin(event_codes, np.fromiter(final_codes, dtype=np.int64)) if final_codes else np.zeros(len(events), dtype=bool)

        args.output.parent.mkdir(parents=True, exist_ok=True)
        primary = hdul[0].copy()
        event_hdu = fits.BinTableHDU(data=events[~remove], header=hdul[1].header, name=hdul[1].name)
        event_hdu.header.add_history("Persistent hot-pixel catalogue and per-observation test applied.")
        event_hdu.header.add_history(
            "Poisson BH q=1e-4; isolation>=0.90; span fraction>=0.80; occupied 32-s bins>=5."
        )
        fits.HDUList([primary, event_hdu]).writeto(args.output, overwrite=True, checksum=True)

    print(f"raw_events={len(events)}")
    print(f"per_observation_candidates={len(candidate_codes)}")
    print(f"catalogue_candidates_in_observation={len(final_codes)}")
    print(f"removed_events={int(np.sum(remove))}")
    print(f"retained_events={int(np.sum(~remove))}")
    print(f"output={args.output}")


if __name__ == "__main__":
    main()
